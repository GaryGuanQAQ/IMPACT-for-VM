# radiology-qc

Quality control for radiological DICOM datasets. It audits de-identification,
file integrity, metadata, and image quality, then writes per-study reports and a
prioritised batch review queue.

- `light` (default): metadata and model-free pixel checks; no container or GPU.
- `full`: light checks plus container-backed TotalSegmentator inference.

## Quick start

```bash
poetry install
poetry run python -m radiology_qc.qc_pipeline config.json
```

The minimum configuration is:

```json
{"root_directory": "/path/to/dicom", "qc_mode": "light"}
```

Reports are written beside the data unless `output_directory` is set.

For a release-bound dataset, run two stages, after pixel-based redaction has
already been applied to the source:

```text
pixel redaction (upstream) > radiology-qc (internal) > deidentify > radiology-qc (release)
```

QC runs twice because the two positions answer different questions. Before
de-identification (`qc_scope: "internal"`) the data is expected to hold
identifiers, so they are reported as an inventory of what will be stripped
rather than as a defect, and cross-study checks that need real dates and a
patient identifier — such as same-patient, same-modality, same-day duplicates —
are available. Internal reports may name patient identifiers and stay in the
source security zone. After de-identification (`qc_scope: "release"`, the
default) residual identifiers are a release blocker, and the temporal checks are
skipped because the writer anchors every study's dates independently, so all
studies share one date and every same-patient pair would look same-day.

`deidentify` performs both metadata passes itself: the source UIDs and dates
that linkage and longitudinal tables need go to `linkage_directory` in the
source security zone, and a pseudonymous cache describing the export is written
beside it for QC to read. QC then runs over the de-identified copy. The source
tree is treated as read-only throughout.

`extract_metadata` remains a standalone module for QC over data that is not
being exported.

## Checks

Files are grouped by `StudyInstanceUID`; series-level values use the most common
value across their instances.

| Area | Checks |
| --- | --- |
| De-identification | Patient, personnel, institution, free-text, and workflow-ID values; un-remapped UIDs; un-normalised dates; possible NHS numbers; accession-number reuse; printable and opaque private-tag values. Reports only — see [deidentify/README.md](deidentify/README.md). |
| Integrity | MD5, DICOM parsing, duplicate `SOPInstanceUID`, instance counts, and `InstanceNumber` continuity assessed against the series' ordering shape. |
| Metadata | Required populated tags, laterality, mammography view, scanner details, and acquisition parameters. |
| Standardisation | Geometry-derived plane, description mismatch, MRI sequence classification, and protocol completeness. |
| Image quality | Pixel decoding, low signal, suspected noise, non-volume/blank series, CJV cohort outliers, foreground coverage, and FOV clipping. |
| Full mode | CT body-envelope and organ clipping from TotalSegmentator. |

Important interpretation notes:

- CJV is compared within modality/sequence cohorts, not against an absolute
  scanner-independent limit.
- Oblique planes and large slice gaps are reported but are not findings because
  they can be valid acquisitions.
- Breast MRI uses model-free clipping. The available TotalSegmentator MR body
  model is abdominal-trained and is not suitable for this anatomy.
- Mammography and ultrasound profiles do not use generic body-face clipping.
- A gap in `InstanceNumber` only means a lost image where `InstanceNumber` is
  the sampling axis, so `instance_ordering` classifies each series and only a
  positioned stack raises HIGH. Modality is not consulted: a position-tracked
  ultrasound sweep is judged exactly like a volume, whereas a gallery of stills
  or cine loops report at LOW, since deleting an image at the console is normal.
  A freehand sweep exported as untracked stills has no `ImagePositionPatient`
  and is indistinguishable from a gallery, so it also reports at LOW.
- Continuity spans the `InstanceNumber`s actually present, as DICOM does not
  require a series to start at 1. Losses from either end leave no gap, so only
  `NumberOfSeriesRelatedInstances` can catch them, via `SLICE_COUNT_MISMATCH`.

## Outputs

Each `{study}_qc_report.json` contains:

- study protocol, device, software/model provenance, de-identification audit,
  and unreadable files;
- series metadata, acquisition parameters, integrity, image quality, and any
  segmentation result;
- instance filename, checksum, and duplicate status.

Full mode can save reliable NIfTI masks under
`segmentation_masks/{study}/...` by setting `RADQC_SAVE_MASKS=true`.

`batch_qc_summary.json` ranks every study that needs review. A study's tier is
its worst issue; its weighted score breaks ties. `review_queue.csv` contains the
same queue in spreadsheet form.

| Tier | Typical findings |
| --- | --- |
| CRITICAL | Residual identifying data (release scope), unreadable files, pixel decode failure, or missing slices. |
| HIGH | Incomplete protocol, missing required tags, unknown slice ordering, or broken continuity in a positioned stack. |
| MEDIUM | Clipping, low signal/noise, distortion, duplicates, or a CJV outlier. |
| LOW | Classification/label mismatch, blank series, non-volume series, broken continuity outside a positioned stack, or identifiers awaiting de-identification (internal scope). |

The batch summary also groups issue counts by modality, manufacturer, and
scanner to expose systematic problems. In internal scope it adds
`possible_duplicate_studies`: groups of studies sharing a patient, modality and
study date, which usually mean a re-scan, a duplicated import, or one study
split across two accessions. `duplicate_study_check` states why the check was
skipped when it does not run.

## Configuration

Deployment settings belong in `config.json` or environment variables:

| Key | Environment variable | Description |
| --- | --- | --- |
| `root_directory` | `RADQC_ROOT_DIR` | DICOM scan root. `study_directory` remains as a deprecated alias. |
| `output_directory` | `RADQC_OUTPUT_DIR` | Optional report root. Input paths are mirrored to avoid name collisions. |
| `qc_mode` | `RADQC_MODE` | `light` or `full`. |
| `qc_scope` | `RADQC_SCOPE` | `internal` (pre-de-identification) or `release` (default). Decides whether identifiers are an inventory or a release blocker, and whether cross-study duplicate detection runs. |
| `use_extracted_metadata` | `RADQC_USE_EXTRACTED_METADATA` | Use a nearby metadata cache when available. Pixels still come from DICOM. |
| `metadata_filename` | `RADQC_METADATA_FILENAME` | Cache filename; default `dicom_metadata.json`. |

QC policy and metric definitions live in `radiology_qc/settings.py`:

- `QCSettings`: discovery, thresholds, severity weights, and metric definitions.
- `DEFAULT_PROTOCOL_REQUIREMENTS`: required sequences or planes by modality.
- `DEFAULT_ANATOMY_PROFILES`: clipping rules by modality/body part.
- `DEFAULT_SEGMENTATION_*`: full-mode runtime defaults.

Metric definitions are embedded in every report because changing them makes
results from different runs non-comparable.

| `QCSettings` field | Default | Meaning |
| --- | --- | --- |
| `file_patterns` | `*.dcm`, `*.DCM` | Intended DICOM files; parse failures are reported. |
| `scan_extensionless` | `true` | Also include extensionless files with DICM magic. |
| `min_volume_slices` | `5` | Minimum slices for volume classification and volume metrics. |
| `iqm_sample_slices` | `15` | Slices sampled for CJV and clipping. |
| `blank_slice_rel_threshold` | `0.2` | Blank below this fraction of median tissue. |
| `mostly_blank_fraction` | `0.9` | Fraction that flags a mostly blank series. |
| `low_signal_max_foreground` | `0.02` | Maximum foreground for a low-signal finding. |
| `min_spatial_structure` | `0.5` | Minimum lag-1 autocorrelation before noise is suspected. |
| `cohort_outlier_z` | `3.5` | Robust CJV outlier threshold. |
| `min_cohort_size` | `5` | Minimum cohort size for CJV outliers. |
| `mandatory_tags` | `StudyDate`, `Modality` | Tags that must be populated. |
| `severity_weights` | 100 / 40 / 15 / 5 | CRITICAL / HIGH / MEDIUM / LOW weights. |

Invalid or internally inconsistent settings fail at startup instead of being
silently adjusted.

## Full mode and model image

The application always runs in the host Poetry environment. Only inference runs
in the model image:

```text
radiology_qc on host ── full-mode inference ──> TotalSegmentator container
```

The image contains TotalSegmentator, its dependencies, and the `body_fast` and
`total_fast` weights. Its source is
[`PharosKCL/pharos-analysis-containers`](https://github.com/PharosKCL/pharos-analysis-containers/tree/main/radiology/totalsegmentator_2-15-0).
Those tasks use Apache-2.0 code and weights; the pipeline does not invoke
separately licensed tasks.

Example connected Docker run:

```bash
docker pull --platform linux/amd64 \
  ghcr.io/pharoskcl/totalsegmentator_2-15-0:latest
poetry install --sync --only main

RADQC_ROOT_DIR=/path/to/dicom \
RADQC_OUTPUT_DIR=/path/to/qc_out \
RADQC_MODE=full \
RADQC_TOTALSEG_RUNTIME=docker \
RADQC_TOTALSEG_IMAGE=ghcr.io/pharoskcl/totalsegmentator_2-15-0:latest \
poetry run python -m radiology_qc.qc_pipeline config.json
```

Prefer an immutable image digest for reproducible deployments. Set
`TOTALSEG_PULL=true` only where registry access is intended.

### Job launchers

Copy the relevant `env.example` to `env` and fill in its paths. One env file
drives all three launchers:

| Stage | Launcher | Poetry equivalent |
| --- | --- | --- |
| Metadata cache | `./jobs/run_extract_metadata.sh [DATA_DIR] [METADATA_DIR]` | `poetry run python -m extract_metadata.extract_metadata extract_metadata/config.json` |
| De-identification | `./jobs/run_deidentify.sh` | `poetry run python -m deidentify.deidentify deidentify/config.json` |
| NIfTI conversion | — | `poetry run python -m nifti_conversion.convert nifti_conversion/config.json` |
| QC | `./jobs/run_qc.sh [config.json]` | `poetry run python -m radiology_qc.qc_pipeline config.json` |

Each launcher reads `QC_ENV_FILE` (default `jobs/env`) and generates the module
config from it; the Poetry form takes a config file you maintain yourself. The
de-identification launcher additionally requires `DEID_DIR` and `LINKAGE_DIR`,
and optionally `PARTICIPANT_ID_MAP`, `CENTRE` and `TISSUE_SOURCE_SITE`. Nothing is written
into `DATA_DIR`, and the linkage tree is refused inside either the source tree
or the export.

| Environment | Command | Model runtime |
| --- | --- | --- |
| Barts SDE | `QC_ENV_FILE=jobs/barts_sde/env ./jobs/run_qc.sh` | Docker image imported through the airlock. |
| KCL CREATE | `submit_job jobs/kcl_tre/qc_slurm.sh` | GHCR image cached as a Singularity SIF. |
| QMUL Apocrita light | `sbatch jobs/qmul_hpc/apocrita_light.sh` | None. |
| QMUL Apocrita full | `sbatch jobs/qmul_hpc/apocrita_full.sh` | Transferred archive or Apptainer SIF. |

KCL full mode caches `TOTALSEG_SOURCE` at `TOTALSEG_IMAGE`. Private registry
credentials must be supplied through the job environment, never stored in the
repository.

For a walled environment, export the published image on a connected machine:

```bash
./jobs/export_model_image.sh
# Set TOTALSEG_FORMAT=sif or both if required.
```

Verify the generated checksum, then load the archive with Docker or convert it:

```bash
sha256sum -c totalsegmentator_2-15-0.tar.gz.sha256
docker load -i totalsegmentator_2-15-0.tar.gz

apptainer build totalsegmentator_2-15-0.sif \
  docker-archive:totalsegmentator_2-15-0.tar.gz
```

## Supporting tools

### Metadata cache

```bash
poetry run python -m extract_metadata.extract_metadata extract_metadata/config.json
```

This writes one tiered `dicom_metadata.json` per study, beside each study unless
`output_directory` is set — which it must be for a read-only source tree, and
input paths are then mirrored. Constant values are kept at study or series
level; varying values remain per instance. Public and private top-level tags are
retained, while sequences and pixel data are omitted.

The cache is as sensitive as the source DICOM because it may contain identifying
private-tag text. Protect it as source data; it is not a de-identified export.
When used by the QC pipeline, only header parsing is cached. Pixel checks still
read the DICOM files. Sequence-based fallbacks, such as ultrasound
`ViewCodeSequence`, are unavailable and use their text fallback instead.

### PharosID generation

PharosIDs have this form:

```text
PH_<centre>_<participant_id>_<tissue_source_site>_IM<modality>_<hash>
```

Participant and site fields come from the registry, not patient DICOM tags. The
eight-character hash is derived from participant ID, modality, and
`StudyInstanceUID`.

```python
from id_generation.generate_pharos_id import generate_pharos_id

generate_pharos_id("123456", "01", "01", "study/series/image.dcm")
generate_pharos_id("123456", "01", "01", "study", use_extracted_metadata=True)
```

### De-identification writer

```bash
poetry run python -m deidentify.deidentify deidentify/config.json
```

Writes a de-identified copy of a DICOM tree: fixed-profile tag removal, one
study-level date offset, and random UID pseudonymisation, with the export
verified by rereading it. Source files are never modified.

Each study is exported to its own folder named by its identifier, and the
source metadata and UID mapping that relink it go to a separate
`linkage_directory` in the restricted zone. Pixel-based redaction must have run
upstream — see [the prerequisite](deidentify/README.md#prerequisite-pixel-redaction-must-already-have-run).

See [deidentify/README.md](deidentify/README.md) for the configuration keys, the
profile's four actions, date/time handling, UID scheme, linkage, and its
[limitations](deidentify/README.md#limitations).

## Limitations

- Physics QC such as resolution, SNR, uniformity, and geometric accuracy is out
  of scope. CJV is a proxy, not a phantom measurement.
- Default thresholds were tuned on TCGA data and require local validation.
- Multi-frame/enhanced DICOM is unsupported; colour frames become luminance.
- Breast MRI clipping is model-free only.
- Metadata processing does not prove that identifying text is absent from pixel
  data or other opaque binary payloads; those require separate pixel/content
  review before release.
- De-identification carries further limitations of its own; see
  [deidentify/README.md](deidentify/README.md#limitations).
