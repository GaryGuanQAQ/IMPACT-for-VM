# De-identification writer

Writes a de-identified copy of a DICOM tree: fixed-profile tag removal, one
study-level date offset, and UID pseudonymisation. Unlike the read-only
[QC audit](../README.md#checks), this command writes files.

## Prerequisite: pixel redaction must already have run

This writer treats Pixel Data as immutable. It never reads, decodes, or alters
pixels, and the identifier naming each exported study is a SHA-256 digest of the
stored pixel bytes of every instance in that study. Two consequences follow, and
both are load-bearing:

- **Pixel-based de-identification belongs upstream of this stage.** Burned-in
  annotation, patient banners, and any other identifying content rendered into
  the image must already be removed, because nothing here will remove them and
  the QC audit reports metadata only.
- **Redacting pixels after an export changes that study's identifier.** The
  digest is taken over pixel content, so re-running redaction, re-compressing,
  or otherwise rewriting pixels produces a different identifier for the same
  study. So does changing the study's composition — adding a late series,
  pruning a duplicate, or excluding an unreadable instance — since the digest
  covers every instance present.

Run the pixel redaction pipeline to completion first, and treat its output as
frozen from that point on.

## First-time setup

Three directories are the only requirement — `input_directory`,
`output_directory` and `linkage_directory`. There is no key to provision and no
key ID to choose: UID replacement needs no secret, and is on by default.

Participant attribution is optional. Without it, studies are named by their hash
segment alone; the run says so at startup rather than failing.

### Setup errors

Every one of these aborts before any file is written. Identifiers for *all*
studies are resolved in a preflight pass before the first export is written, so
a study that cannot be named — mixed modality, no Pixel Data, no mapped
participant, or a pixel digest already claimed — stops the run at the start
rather than partway through, and every such study is reported together:

```text
ERROR: 1 of 2 study(ies) cannot be named; refusing to write a partial export:
  /data/raw/PATIENT_X/study-1: Study spans modalities ['MG', 'US']; the
  identifier carries exactly one, so this study needs a per-modality split
```

| Message | Cause |
| --- | --- |
| `'output_directory' must be absent or empty; …` | The export path already holds files — including a metadata cache, which must not live beside the export. Use a fresh directory. |
| `'input_directory' and 'output_directory' must be separate, non-nested directories` | One path contains the other; the writer never writes inside its source. |
| `Set 'input_directory' in <path> …` | The config being read isn't the one you meant; with no argument the writer reads `deidentify/config.json` beside the module. |
| `DICOM grouping parsed N of M discovered file(s)` | A discovered file could not be parsed or grouped; the writer refuses a partial export rather than silently dropping it. |
| `The fixed de-identification profile requires 'replace_uids' to be true` | `replace_uids` is `false` while `strip_phi` is `true`; source UIDs would survive into the export. |
| `Set 'linkage_directory': …` | Missing. Without it an export cannot be relinked, so it is required rather than defaulted. |
| `'linkage_directory' must be outside 'output_directory'` | The mapping would be released with the export it unlocks. |
| `'linkage_directory' must be absent or empty` | A stale mapping would not describe this export; UIDs are random per run. |
| `No 'participant_id_map' entry covers '<dir>'` | A study has no mapped participant. Add an entry for it or a parent directory. |
| `identifier Z is already taken by study …` | Two studies have byte-identical pixel content, so they cannot be told apart in the export. |
| `Study spans modalities [...]` | The identifier carries exactly one `IM<modality>`; a mixed study must be split. |
| `Cannot derive a pixel digest: no instance … carries Pixel Data` | The study has no pixels to name it by — see the prerequisite above. |
| `'nifti_directory' is set but 'write_nifti' is false` | The directory would never be written to; enable the flag or drop the key. |
| `'nifti_directory' must be outside 'input_directory'` | The source tree is read-only. |

## Running it

The writer performs both metadata passes itself — the source-side one before
anything is replaced, the export-side one over what it wrote — so the release
flow is two stages after upstream pixel redaction:

```text
pixel redaction (upstream) > radiology-qc (internal) > deidentify > radiology-qc (release)
```

The internal QC pass is optional but is the only place cross-study checks that
need real dates and a patient identifier can run — see
[qc_scope](../README.md#configuration). `extract_metadata` remains a standalone
module for QC over data that is not being exported; it is no longer a stage
here.

`jobs/run_deidentify.sh` generates the config from one env file:

```bash
QC_ENV_FILE=jobs/<environment>/env ./jobs/run_deidentify.sh
```

Or drive it directly with Poetry and your own config files:

```bash
poetry run python -m deidentify.deidentify deidentify/config.json
poetry run python -m radiology_qc.qc_pipeline config.json
```

The launcher needs `DATA_DIR`, `DEID_DIR`, and `LINKAGE_DIR` in the env file,
and optionally `PARTICIPANT_ID_MAP`, `CENTRE` and `TISSUE_SOURCE_SITE`.
`DATA_DIR` is treated as read-only, so the source-side cache
needs a writable location outside it; the launcher also refuses to place that
cache inside the export, where the before/after pair would be a linkage record.
`FORCE_EXTRACT=true` rebuilds an existing source cache.

`output_directory` must be separate from `input_directory` and absent or empty;
source files are never modified and existing exports are never overwritten. UID
replacement is unconditional. If any
discovered DICOM cannot be parsed or grouped, the run refuses to write a partial
export or a success manifest.

## Configuration

All three directories are required. Every other key is optional and overrides
its `DEFAULT_*` counterpart in `settings.py` for that run. Nothing else in that
module is configurable: the tag policy, UID root, UID entropy, and Part-10
output rules are fixed invariants.

Participant attribution is all-or-nothing: supply `participant_id_map`, `centre`
and `tissue_source_site` together for full PharosIDs, or none of them for bare
hash identifiers. A partial set is treated as none and logged at startup. These
three accept an empty string as "unset", so a config template can ship them
present-but-blank without failing.

| Key | Default (`settings.py`) | Example | What it does |
| --- | --- | --- | --- |
| `input_directory` | required | `"/data/raw/study-export"` | Root scanned recursively for `*.dcm` / `*.DCM`; may hold many studies. |
| `output_directory` | required | `"/data/deid/study-export"` | Where the export is written, one folder per study named by its identifier. Must be separate from the input and absent or empty. |
| `linkage_directory` | required | `"/restricted/linkage/2026-08"` | Restricted-zone root receiving `source_metadata.json`, `uid_mapping.json` and `run_record.json`. Must sit outside both other roots and be absent or empty. |
| `participant_id_map` | optional | `"/restricted/participants.json"` | JSON mapping a directory relative to `input_directory` to a participant ID. Deepest matching entry wins; an unmapped study fails the run. |
| `centre` | optional | `"01"` | PharosID centre field. Letters, digits and `-` only. |
| `tissue_source_site` | optional | `"01"` | PharosID tissue source site field. Same character rule. |
| `write_nifti` | `false` | `true` | Also write one NIfTI per series, converted from the export rather than the source. See [nifti_conversion](../nifti_conversion/README.md). |
| `nifti_directory` | `""` | `"/data/nifti/study-export"` | Root for NIfTI output, one folder per study identifier. Empty writes them into the export folder beside the DICOMs. Requires `write_nifti`. |
| `replace_uids` | `true` (`DEFAULT_REPLACE_UIDS`) | `true` | Replace entity UIDs with random ones. Must stay `true` while `strip_phi` is `true`; `false` keeps source UIDs, which makes the export directly linkable and is logged as a warning. |
| `strip_phi` | `true` (`DEFAULT_STRIP_PHI`) | `true` | Apply the fixed profile and blank supplementary audit findings. `false` writes UID/date changes only. |
| `normalise_dates` | `true` (`DEFAULT_NORMALISE_DATES`) | `true` | Shift DA/DT by one per-study offset and keep the policy's TM values. `false` removes every timestamp instead. |
| `anchor_date` | `"2020-01-01"` (`DEFAULT_ANCHOR_DATE`) | `"2000-01-01"` | `YYYY-MM-DD` the study's earliest surviving date moves to. |
| `strip_private_tag_text` | `true` (`DEFAULT_STRIP_PRIVATE_TAG_TEXT`) | `true` | Also blank private tags holding printable text, and deferred private values too large to inspect safely. |
| `allowed_tags` | `[]` (`DEFAULT_DEID_ALLOWED_TAGS`) | `["0032,1031"]` | Tags exempt from *supplementary* stripping, as `GGGG,EEEE` hex. Fixed removals ignore this; DICOM keywords are rejected. |

## The profile

`radqc-default-v1` covers 291 concrete tags. Each takes exactly one action, and
the five sets are validated as a disjoint partition at import. The fixed profile
always wins: `allowed_tags` can never retain a tag it removes.

- **Retained** (11) — the examination descriptions and contrast/protocol fields
  that name what was imaged rather than who: `StudyDescription`,
  `SeriesDescription`, `ProtocolName`, `AcquisitionDeviceProcessingDescription`,
  `AcquisitionProtocolDescription`, `RequestedProcedureDescription`,
  `ScheduledProcedureStepDescription`, `PerformedProcedureStepDescription`,
  `ContrastBolusAgent`, `RequestedContrastAgent`, and `DataPathID`. Typed
  clinical narrative such as `ReasonForStudy`, `AdmittingDiagnosesDescription`,
  and every `*Comments` field is removed instead.
- **Replaced with the study identifier** (1) — `PatientID`. Overwritten rather
  than deleted, so downstream tools that key on a patient identifier keep
  working while the value carries no source identity. The writer rereads its
  output and fails the run if the written value is not the identifier.
- **UID-replaced** (3) — Study, Series, and SOP Instance UIDs, plus every
  surviving reference to them.
- **Normalised** (43) — 24 shifted DA/DT and 19 retained TM.
- **Removed** (233) — grouped by what the value identifies: `patient`,
  `personnel`, `institution`, `workflow_ids`, `free_text`, and
  `embedded_content` for opaque content deleted whole. Includes the overlay
  repeaters `60xx,3000` and `60xx,4000` (32 tags) and `DigitalSignatureUID` with
  the related MAC structures, whose signatures any modification voids.

The tag list was supplemented by the Barts Health PACS team default
anonymisation profile, reviewed 2026-08-09. A pinned third-party `deid` recipe
adds supplementary findings on top; its load failure or field drift aborts the
writer. Two local precedence rules keep that recipe from taking acquisition
data: its `Time` selectors are limited to TM wall-clock values, so echo,
repetition, inversion, frame, and exposure times survive, and its `ID` selectors
skip binary integers, so an index such as `DisplaySubsystemID` or
`GraphicGroupID` survives while text equipment identifiers such as `DeviceID`
and `XRaySourceID` are still removed as site linkage.

Supplementary findings are blanked to a VR-appropriate empty value; profile
removals are deleted. Each output records `PatientIdentityRemoved` = `YES` and
appends the profile id to `DeidentificationMethod`, keeping any method the
source already declared.

## Dates and times

Normalisation runs before stripping. One whole-day offset per study moves that
study's earliest surviving date onto `anchor_date` and shifts every populated
DA/DT value recursively, preserving intervals within the study and the time
component of DT values. Intervals *between* studies are not preserved, since
each study is anchored independently.

A whole-day offset leaves standalone TM values unchanged, so the times in
`DEFAULT_DEID_RETAINED_TIME_TAGS` survive; other wall-clock TM values are
removed. Every retained TM keeps its date context: it either has a DA partner in
the shifted set, so a study running across midnight still carries two distinct
shifted dates, or it is an acquisition time DICOM defines without any date —
contrast bolus, radiopharmaceutical, and intervention drug start/stop times,
which stay available for enhancement and dose calculations.

A surviving DA/DT value that cannot be shifted aborts the run before anything is
written. With normalisation disabled, or if no offset can be computed, every
DA/DT field and policy timestamp is removed.

## UID replacement

A UID becomes a fresh 128-bit random value written as `2.25.<decimal>`, drawn
from `secrets` rather than derived from anything. Within one run a source UID
seen more than once maps to a single replacement wherever it survives — Study,
Series, SOP Instance, Frame of Reference, device, acquisition, private UI,
file-meta, and nested references — preserving study/series equivalence classes.
Across runs it does not: re-exporting the same study produces entirely new UIDs,
because there is nothing to derive them from. Registered constants and
structural UIDs such as SOP classes, transfer syntaxes, and well-known instances
stay unchanged. The profile removes the Source Image, Referenced Image,
Referenced Study, Referenced Patient, and Referenced Performed Procedure Step
sequences, so those derivation links are not retained.

Nothing in the output is computable from the source. That is the point of the
scheme: there is no key whose custody, rotation, backup, or destruction has to
be managed, and no value an adversary holding source metadata can recompute to
confirm a guess. The cost is that relinking is possible **only** through the
exported mapping, and re-exports are not stable — see [linkage](#linkage).

A generated UID that is already in use is retried and, failing that, aborts the
run; at 128 bits of entropy this does not occur in practice. Outputs are reread
after writing to verify every UID, the three hierarchy fields, nested
references, and file-meta consistency. The writer replaces source File Meta
Information with a minimal Part-10 header, zeroes the preamble, and drops source
AE titles, implementation strings, and file-meta private information.

## What a run writes

Two trees, in two security zones. Nothing crosses between them.

```text
output_directory/                     released
  PH_01_123456_01_IMMG_7F3A9C21/      one folder per study, named by identifier
    <de-identified .dcm files>        series subdirectories preserved
    <series>.nii.gz                   only when write_nifti is on and
                                      nifti_directory is empty
    dicom_metadata.json               pseudonymous; QC reads it as its cache
  deidentification_manifest.json

linkage_directory/                    restricted zone, never released
  PH_01_123456_01_IMMG_7F3A9C21/
    source_metadata.json              raw UIDs, dates and private-tag values
    uid_mapping.json                  every source UID with its pseudonym
  run_record.json                     timestamp, config, profile id, digests
```

The study identifier is the full PharosID when participant attribution is
configured and the bare hash segment otherwise. The bare form is exactly the
suffix the full PharosID would end with, so an unattributed export can be
renamed later without recomputing anything.

`deidentification_manifest.json` records the UID generation scheme,
pseudonymous study UIDs, object counts, and profile/UID verification status. It
carries no source UIDs, no source paths, no exact date offsets and no PHI audit
values: it ships with the export and is a pseudonymous operational record, not a
reverse-linkage database.

`run_record.json` records what produced the export — timestamp, the config as
given, the profile id, the UID scheme, and a SHA-256 for each linkage file, so
later tampering with a mapping is detectable.

### Linkage

`uid_mapping.json` is the only thing that can relink an export to its source.
Every source UID appears with its pseudonym, so a study, series, or instance
resolves in either direction without recomputation and without a key. Its
`uid_replacement` field records whether UIDs were replaced at all, so an empty
`uids` list reads as "this run kept its source UIDs" rather than as a mapping
that failed to record anything.

Because the UIDs are random, this file is not reproducible: lose it and the
export is permanently unlinkable, which is also what makes destroying it a
clean, auditable way to sever linkage for good. Re-running the writer over the
same source produces different UIDs and therefore a different mapping, so an
export and its mapping are a matched pair.

Keep the linkage tree in the same restricted zone as the source data and under
the custody, access-logging and destruction controls you would apply to any
identifiable mapping table. `source_metadata.json` is the heavier of the two:
it holds raw UIDs, dates and private-tag values, so it is a PHI archive as much
as a linkage aid, and it grants far more than the ability to relink. The writer
refuses a `linkage_directory` inside the export or inside the read-only source
for exactly this reason.

## What the QC audit reports

The read-only audit in `radiology_qc/deidentification.py` consumes the same
policy and reports anything the writer would have had to transform:
removal-group values under their group, with `removal_policy_compliant` false
while any remain; UIDs still carrying source identity under `original_uids`; and
DA/DT values never shifted onto the anchor date under `unnormalised_dates`.
`original_uids_present` and `dates_normalised` summarise the latter two.

A populated `PatientID` is reported under `pseudonym_tags_present` rather than
as a finding, but only when all three hold: the file declares
`PatientIdentityRemoved=YES`, carries `radqc-default-v1` in
`DeidentificationMethod`, **and** the value is one of the two forms
`study_identifier` emits. Anything else is an ordinary residual identifier and
counts against the verdict, so raw data, data de-identified by another tool that
left `PatientID` populated, and a value of the wrong shape all still fail:

| `PatientID` | `deidentified` | Reported as |
| --- | --- | --- |
| `PH_01_123456_01_IMMG_1C4AE64D` | true | `{"PatientID": "pharos_id"}` |
| `2972DDD5` | true | `{"PatientID": "hash_segment"}`, also listed in `pseudonym_identifiers_weak` |
| `RXH1234567` | false | residual, under `additional_flagged_by_deid` |
| `PH_01_123456_IMMG` | false | residual — declares the shape but does not match it |
| *(empty)* | true | nothing; an empty tag carries no identity |

`pseudonym_identifiers_weak` exists because the bare hash segment is a much
weaker assertion than a full PharosID: eight hex characters is a shape plenty of
real hospital numbers share, so the audit cannot meaningfully distinguish one
from a residual value. Configure participant attribution for anything bound for
release, and treat a weak identifier as a prompt to check rather than a pass.

The writer does not rely on any of this: it rereads its own output and fails the
run unless `PatientID` is exactly the identifier it assigned.

A study whose earliest surviving date is the anchor date is treated as
normalised — only the writer, which rereads its own output, verifies the actual
source-to-output mapping. Deferred private values are reported by tag, VR, and
encoded length only, never copied into the report, and are blanked when
`strip_private_tag_text` is on.

## Limitations

- The export mirrors source directory and file names; sites must ensure those
  names do not themselves contain identifying information.
- Writes are verified but not transactionally staged; an I/O failure can leave a
  partial output tree that must not be released.
- These rules are a local metadata policy, not a claim of formal DICOM Basic
  Application Confidentiality Profile conformance. Literal removal of content
  sequences can make SR, presentation-state, or encapsulated-document objects
  unusable without an SOP-specific policy.
- Metadata processing does not prove that identifying text is absent from pixel
  data or other opaque binary payloads; those require separate pixel/content
  review before release, and this writer assumes that review already happened —
  see [the prerequisite above](#prerequisite-pixel-redaction-must-already-have-run).

## Strategy references

Design inputs for the layered, DICOM-aware de-identification and stable
pseudonymisation strategy. Neither is a claim of formal conformance.

- Shahid, A., Bazargani, M., Banahan, P., Mac Namee, B., Kechadi, T., Treacy,
  C., Regan, G., and MacMahon, P. (2022). [A Two-Stage De-Identification
  Process for Privacy-Preserving Medical Image Analysis](https://www.mdpi.com/2227-9032/10/5/755).
  *Healthcare*, 10(5), 755. https://doi.org/10.3390/healthcare10050755
- Noumeir, R., Lemay, A., and Lina, J.-M. (2007). [Pseudonymization of Radiology
  Data for Research Purposes](https://link.springer.com/article/10.1007/s10278-006-1051-4).
  *Journal of Digital Imaging*, 20(3), 284–295.
  https://doi.org/10.1007/s10278-006-1051-4
