from __future__ import annotations

import hashlib
import json
import logging
import os
import sys
from datetime import date, datetime, timezone
from pathlib import Path
from typing import AbstractSet, Any, Dict, Iterable, List, Optional, Set, Tuple

import pydicom
from pydicom.dataelem import RawDataElement
from pydicom.datadict import dictionary_VR, keyword_for_tag
from pydicom.dataset import FileMetaDataset
from pydicom.multival import MultiValue
from pydicom.uid import (
    ExplicitVRBigEndian,
    ExplicitVRLittleEndian,
    ImplicitVRLittleEndian,
    PYDICOM_IMPLEMENTATION_UID,
)

from extract_metadata.extract_metadata import (
    DEFAULT_OUTPUT_FILENAME,
    discover_dicom_files,
    extract_study_metadata,
    group_by_study,
    study_directory,
)
from id_generation.generate_pharos_id import study_identifier, study_pixel_digest
from nifti_conversion.convert import convert_study as convert_study_to_nifti
from radiology_qc.deidentification import audit_deidentification
from deidentify.normalise_dates import (
    can_shift_date_time_value,
    compute_offset_days,
    shift_date_time_value,
    shift_dataset_dates,
)
from deidentify.settings import (
    ALLOWED_OUTPUT_FILE_META_TAGS,
    DEFAULT_ANCHOR_DATE,
    DEFAULT_DEID_ALLOWED_TAGS,
    DEFAULT_DEID_DATE_TIME_TAGS,
    DEFAULT_DEID_EFFECTIVE_CONCRETE_TAG_COUNT,
    DEFAULT_DEID_PRESERVE_TAGS,
    DEFAULT_DEID_PSEUDONYM_TAGS,
    DEFAULT_DEID_REMOVE_TAGS,
    DEFAULT_DEID_RETAINED_TIME_TAGS,
    DEFAULT_DEID_UID_REMAP_TAGS,
    DEFAULT_DEIDENTIFICATION_PROFILE_ID,
    DEFAULT_DEIDENTIFICATION_MANIFEST_FILENAME,
    DEIDENTIFICATION_METHOD_TAG,
    DEFAULT_NORMALISE_DATES,
    DEFAULT_REPLACE_UIDS,
    DEFAULT_STRIP_PHI,
    DEFAULT_STRIP_PRIVATE_TAG_TEXT,
    DICOM_READ_DEFER_SIZE,
    DICOM_TAG_CODE_RE,
    DicomTag,
    IMPLEMENTATION_CLASS_UID_TAG,
    MEDIA_STORAGE_SOP_CLASS_UID_TAG,
    MEDIA_STORAGE_SOP_INSTANCE_UID_TAG,
    PATIENT_IDENTITY_REMOVED_TAG,
    PHAROS_COMPONENT_RE,
    PATIENT_IDENTITY_REMOVED_VALUE,
    REQUIRED_UID_TAGS,
    SERIES_INSTANCE_UID_TAG,
    SHIFTED_DATE_VRS,
    SOP_CLASS_UID_TAG,
    SOP_INSTANCE_UID_TAG,
    STUDY_INSTANCE_UID_TAG,
    TRANSFER_SYNTAX_UID_TAG,
    UID_DIGEST_BYTES as UID_DIGEST_BYTES,
    UID_GENERATION_SCHEME,
    UID_ROOT,
    UID_TRUNCATED_BITS,
    ZEROED_DICOM_PREAMBLE,
    default_deid_remove_group,
)
from deidentify.strip_tags import (
    flagged_tags,
    remove_dataset_tags,
    strip_dataset_tags,
)
from deidentify.uids import (
    RandomUIDRemapper,
    uid_requires_remapping,
    validate_canonical_uid,
)

logger = logging.getLogger(__name__)


def _boolean_config(config: Dict[str, Any], name: str, default: bool) -> bool:
    value = config.get(name, default)
    if not isinstance(value, bool):
        raise ValueError(f"'{name}' must be true or false")
    return value


def _optional_config_str(config: Dict[str, Any], name: str) -> Optional[str]:
    """An optional string setting, where empty means unset rather than invalid.

    Config templates ship these keys present-but-blank so the shape is visible,
    so a blank has to mean the same thing as an absent key.
    """
    value = config.get(name)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"'{name}' must be a string")
    return value.strip() or None


def _parse_tag_code(value: str) -> DicomTag:
    """Parse the JSON boundary form ``GGGG,EEEE`` into the canonical tuple."""
    if not isinstance(value, str) or DICOM_TAG_CODE_RE.fullmatch(value) is None:
        raise ValueError("DICOM tag codes must use four-digit hex 'GGGG,EEEE'")
    group, element = value.split(",", 1)
    return int(group, 16), int(element, 16)


def _validate_separate_roots(input_root: Path, output_root: Path) -> None:
    resolved_input = input_root.resolve()
    resolved_output = output_root.resolve()
    if (
        resolved_output == resolved_input
        or resolved_output.is_relative_to(resolved_input)
        or resolved_input.is_relative_to(resolved_output)
    ):
        raise ValueError(
            "'input_directory' and 'output_directory' must be separate, "
            "non-nested directories"
        )


def _study_modality(entries: List[Tuple[Path, pydicom.dataset.Dataset]]) -> str:
    """The study's single Modality, which the identifier's `IM<modality>` needs."""
    modalities = {
        str(getattr(ds, "Modality", "")).strip().upper()
        for _, ds in entries
        if getattr(ds, "Modality", None)
    }
    if not modalities:
        raise ValueError("Study has no Modality; it cannot be named")
    if len(modalities) > 1:
        raise ValueError(
            f"Study spans modalities {sorted(modalities)}; the identifier "
            "carries exactly one, so this study needs a per-modality split"
        )
    return modalities.pop()


def _write_json(path: Path, payload: Any) -> str:
    """Write JSON via a temporary file and return the SHA-256 of what landed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    body = json.dumps(payload, indent=2).encode("utf-8")
    with open(temporary, "xb") as f:
        f.write(body)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temporary, path)
    return hashlib.sha256(body).hexdigest()


def _study_metadata_from_files(study_uid: str, paths: List[Path]) -> Dict[str, Any]:
    """Header-only metadata for already-written files, in the extract format."""
    entries = [
        (path, pydicom.dcmread(path, stop_before_pixels=True)) for path in paths
    ]
    return extract_study_metadata(study_uid, entries)


def write_study_linkage(
    linkage_root: Path,
    identifier: str,
    source_study_uid: str,
    source_entries: List[Tuple[Path, pydicom.dataset.Dataset]],
    uid_pairs: Dict[str, str],
    pixel_digest: str,
    uid_replacement: bool,
) -> Dict[str, str]:
    """Write one study's restricted-zone record and return the file digests.

    This is the only artefact that can relink an export to its source, so it
    never goes near `output_directory`.
    """
    study_dir = linkage_root / identifier
    digests: Dict[str, str] = {}

    digests["source_metadata.json"] = _write_json(
        study_dir / "source_metadata.json",
        extract_study_metadata(source_study_uid, source_entries),
    )
    digests["uid_mapping.json"] = _write_json(
        study_dir / "uid_mapping.json",
        {
            "identifier": identifier,
            "pixel_digest": pixel_digest,
            "uid_replacement": uid_replacement,
            "source_study_instance_uid": source_study_uid,
            "pseudonymous_study_instance_uid": uid_pairs.get(source_study_uid),
            "uid_count": len(uid_pairs),
            "uids": [
                {"source": source, "pseudonym": pseudonym}
                for source, pseudonym in sorted(uid_pairs.items())
            ],
        },
    )
    return digests


def load_participant_id_map(path: Path) -> Dict[str, str]:
    """Load the directory-to-participant map, validating it as an ID source."""
    try:
        with open(path, "r") as f:
            participant_id_map = json.load(f)
    except FileNotFoundError as exc:
        raise ValueError(f"'participant_id_map' not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"'participant_id_map' is not valid JSON: {exc}") from exc

    if not isinstance(participant_id_map, dict) or not participant_id_map:
        raise ValueError(
            "'participant_id_map' must be a non-empty JSON object mapping a "
            "directory relative to 'input_directory' to a participant ID"
        )
    for directory, participant_id in participant_id_map.items():
        validate_pharos_component(participant_id, name=f"participant ID for {directory!r}")
    return participant_id_map


def validate_pharos_component(value: Any, *, name: str) -> str:
    """Reject values that would corrupt the underscore-delimited PharosID."""
    if not isinstance(value, str) or PHAROS_COMPONENT_RE.fullmatch(value) is None:
        raise ValueError(
            f"{name} must be a non-empty string of letters, digits or '-'; "
            "'_' is the PharosID field separator and cannot appear in a component"
        )
    return value


def resolve_participant_id(
    study_dir: Path, input_root: Path, participant_id_map: Dict[str, str]
) -> str:
    """Find the participant owning `study_directory` by deepest matching entry.

    Entries may be keyed at any depth under the scan root, so a map keyed by
    patient folder and one keyed by individual study folder both work; the most
    specific match wins. An unmapped study fails the run rather than inventing
    an ID.
    """
    try:
        relative = study_dir.resolve().relative_to(input_root.resolve())
    except ValueError as exc:
        raise ValueError(
            f"Study directory {study_dir} is outside 'input_directory'"
        ) from exc

    candidates = [relative, *relative.parents]
    for candidate in candidates:
        key = candidate.as_posix()
        if key in participant_id_map:
            return participant_id_map[key]
    raise ValueError(
        f"No 'participant_id_map' entry covers {relative.as_posix()!r}; add an "
        "entry for it or one of its parent directories"
    )


def _output_destinations(
    entries: Iterable[Tuple[Path, pydicom.dataset.Dataset]],
    output_root: Path,
    input_root: Path,
) -> List[Path]:
    """Resolve safe, unique, non-existing output paths for source entries."""
    resolved_input = input_root.resolve()
    destinations: List[Path] = []
    seen: Set[Path] = set()
    for instance_number, (source_path, _) in enumerate(entries, start=1):
        try:
            relative_path = source_path.resolve().relative_to(resolved_input)
        except ValueError as exc:
            raise ValueError(
                f"DICOM instance {instance_number} is outside input_directory"
            ) from exc
        destination = output_root / relative_path
        resolved_destination = destination.resolve()
        if resolved_destination in seen:
            raise ValueError(
                f"DICOM instance {instance_number} resolves to a duplicate output path"
            )
        if destination.exists():
            raise FileExistsError(
                f"Output for DICOM instance {instance_number} already exists"
            )
        seen.add(resolved_destination)
        destinations.append(destination)
    return destinations


def _remap_uid_value(
    tag: DicomTag,
    uid: str,
    remapper: RandomUIDRemapper,
) -> str:
    """Remap entity UIDs while retaining registered or structural constants."""
    validate_canonical_uid(uid, name=f"{_tag_label(tag)} value")
    if not uid_requires_remapping(tag, uid):
        return uid
    return remapper.remap(uid)


def _uid_values(value: Any) -> Iterable[str]:
    if isinstance(value, MultiValue):
        values = value
    elif isinstance(value, (list, tuple)):
        values = value
    else:
        values = (value,)
    for item in values:
        if item is None:
            continue
        text = str(item)
        if text:
            yield text


def _iter_uid_elements(
    ds: pydicom.dataset.Dataset,
    excluded_tags: Set[DicomTag] = frozenset(),
):
    """Yield UI elements recursively without materialising deferred bulk data."""
    for tag in sorted(ds.keys()):
        if (tag.group, tag.element) in excluded_tags:
            continue
        elem = ds.get_item(tag, keep_deferred=True)
        if isinstance(elem, RawDataElement):
            vr = elem.VR
            if vr is None:
                try:
                    vr = dictionary_VR(tag)
                except KeyError:
                    vr = None
            if vr not in {"UI", "SQ"}:
                continue
            elem = ds[tag]
        if elem is None:
            continue
        if elem.VR == "UI":
            yield elem
        elif elem.VR == "SQ":
            for item in elem.value:
                yield from _iter_uid_elements(item, excluded_tags)


def _iter_date_time_elements(
    ds: pydicom.dataset.Dataset,
    excluded_tags: Set[DicomTag] = frozenset(),
):
    """Yield DA/DT elements recursively without loading unrelated bulk data."""
    for tag in sorted(ds.keys()):
        if (tag.group, tag.element) in excluded_tags:
            continue
        elem = ds.get_item(tag, keep_deferred=True)
        if isinstance(elem, RawDataElement):
            vr = elem.VR
            if vr is None:
                try:
                    vr = dictionary_VR(tag)
                except KeyError:
                    vr = None
            if vr not in {"DA", "DT", "SQ"}:
                continue
            elem = ds[tag]
        if elem is None:
            continue
        if elem.VR in {"DA", "DT"}:
            yield elem
        elif elem.VR == "SQ":
            for item in elem.value or ():
                yield from _iter_date_time_elements(item, excluded_tags)


def _date_time_values(value: Any) -> Tuple[Any, ...]:
    if isinstance(value, (MultiValue, list, tuple)):
        return tuple(value)
    return (value,)


def _date_time_signature(
    ds: pydicom.dataset.Dataset,
    *,
    offset_days: Optional[int] = None,
    excluded_tags: Set[DicomTag] = frozenset(),
) -> List[Tuple[DicomTag, Tuple[str, ...]]]:
    """Ordered signature of surviving DA/DT values and expected shifts."""
    signature: List[Tuple[DicomTag, Tuple[str, ...]]] = []
    for elem in _iter_date_time_elements(ds, excluded_tags):
        values = _date_time_values(elem.value)
        if offset_days is not None:
            values = tuple(
                shift_date_time_value(value, elem.VR, offset_days)
                for value in values
            )
        signature.append(
            (
                (elem.tag.group, elem.tag.element),
                tuple("" if value is None else str(value) for value in values),
            )
        )
    return signature


def _validate_profile_date_times_are_shiftable(
    entries: Iterable[Tuple[Path, pydicom.dataset.Dataset]],
) -> None:
    """Fail before writing if a surviving populated DA/DT cannot be shifted."""
    for instance_number, (_, ds) in enumerate(entries, start=1):
        for elem in _iter_date_time_elements(ds, DEFAULT_DEID_REMOVE_TAGS):
            if (
                elem.value
                and not can_shift_date_time_value(elem.value, elem.VR)
            ):
                raise ValueError(
                    "DICOM instance "
                    f"{instance_number} has an unshiftable {elem.keyword or elem.tag} "
                    "value required by the date normalisation policy"
                )


def _retained_value_tags(offset_days: Optional[int]) -> frozenset[DicomTag]:
    """Return the tags whose source values must survive a run unchanged.

    Normalising shifts only DA/DT, so the policy's TM tags survive with their
    source value. Without an offset no timestamp survives at all.
    """
    if offset_days is None:
        return DEFAULT_DEID_PRESERVE_TAGS
    return DEFAULT_DEID_PRESERVE_TAGS | DEFAULT_DEID_RETAINED_TIME_TAGS


def _collect_profile_removal_tags(
    ds: pydicom.dataset.Dataset,
    *,
    remove_date_times: bool,
) -> Set[DicomTag]:
    """Return configured removal-policy tags present anywhere in ``ds``."""
    found: Set[DicomTag] = set()
    for tag in sorted(ds.keys()):
        tag_tuple = (tag.group, tag.element)
        elem = ds.get_item(tag, keep_deferred=True)
        vr = getattr(elem, "VR", None)
        if isinstance(elem, RawDataElement) and vr is None:
            try:
                vr = dictionary_VR(tag)
            except KeyError:
                vr = None
        must_remove = default_deid_remove_group(tag_tuple) is not None or (
            remove_date_times
            and (
                vr in SHIFTED_DATE_VRS
                or tag_tuple in DEFAULT_DEID_DATE_TIME_TAGS
            )
        )
        if must_remove:
            found.add(tag_tuple)
            continue
        if (
            tag_tuple in DEFAULT_DEID_PRESERVE_TAGS
            or tag_tuple in DEFAULT_DEID_UID_REMAP_TAGS
            or tag_tuple in DEFAULT_DEID_DATE_TIME_TAGS
        ):
            continue

        if vr == "SQ":
            sequence = ds[tag] if isinstance(elem, RawDataElement) else elem
            for item in sequence.value or ():
                found.update(
                    _collect_profile_removal_tags(
                        item,
                        remove_date_times=remove_date_times,
                    )
                )
    return found


def _tag_label(tag: DicomTag) -> str:
    return keyword_for_tag(tag) or f"({tag[0]:04X},{tag[1]:04X})"


def _element_value(ds: pydicom.dataset.Dataset, tag: DicomTag) -> Any:
    elem = ds.get_item(tag, keep_deferred=True)
    if isinstance(elem, RawDataElement):
        elem = ds[tag]
    return None if elem is None else elem.value


def _required_uid(
    ds: pydicom.dataset.Dataset,
    tag: DicomTag,
    instance_number: int,
) -> str:
    label = _tag_label(tag)
    value = _element_value(ds, tag)
    if value is None or not str(value):
        raise ValueError(f"DICOM instance {instance_number} is missing {label}")
    if isinstance(value, (MultiValue, list, tuple)):
        raise ValueError(f"DICOM instance {instance_number} has a multi-valued {label}")
    text = str(value)
    validate_canonical_uid(
        text,
        name=f"DICOM instance {instance_number} {label}",
    )
    return text


def _source_sop_class_uid(ds: pydicom.dataset.Dataset, instance_number: int) -> str:
    dataset_uid = _element_value(ds, SOP_CLASS_UID_TAG)
    if dataset_uid is None or not str(dataset_uid):
        raise ValueError(f"DICOM instance {instance_number} is missing SOPClassUID")
    validate_canonical_uid(
        str(dataset_uid),
        name=f"DICOM instance {instance_number} SOP Class UID",
    )
    file_meta = getattr(ds, "file_meta", None)
    file_meta_uid = (
        _element_value(file_meta, MEDIA_STORAGE_SOP_CLASS_UID_TAG)
        if file_meta is not None
        else None
    )
    if file_meta_uid is not None:
        validate_canonical_uid(
            str(file_meta_uid),
            name=f"DICOM instance {instance_number} file-meta SOP Class UID",
        )
    if file_meta_uid is not None and str(file_meta_uid) != str(dataset_uid):
        raise ValueError(
            f"DICOM instance {instance_number} has inconsistent dataset and "
            "file-meta SOP Class UIDs"
        )
    return str(dataset_uid)


def _source_transfer_syntax_uid(
    ds: pydicom.dataset.Dataset,
    instance_number: int,
) -> str:
    file_meta = getattr(ds, "file_meta", None)
    transfer_syntax = (
        _element_value(file_meta, TRANSFER_SYNTAX_UID_TAG)
        if file_meta is not None
        else None
    )
    if transfer_syntax is not None and str(transfer_syntax):
        value = str(transfer_syntax)
        validate_canonical_uid(
            value,
            name=f"DICOM instance {instance_number} Transfer Syntax UID",
        )
        return value

    if getattr(ds, "is_little_endian", True) is False:
        if getattr(ds, "is_implicit_VR", False):
            raise ValueError(
                f"DICOM instance {instance_number} has unsupported implicit-VR "
                "big-endian encoding"
            )
        return str(ExplicitVRBigEndian)
    if getattr(ds, "is_implicit_VR", False):
        return str(ImplicitVRLittleEndian)
    return str(ExplicitVRLittleEndian)


def validate_source_datasets(
    entries: Iterable[Tuple[Path, pydicom.dataset.Dataset]],
) -> None:
    """Validate file-meta identity consistency before any output is written."""
    for instance_number, (_, ds) in enumerate(entries, start=1):
        sop_instance_uid = _required_uid(ds, SOP_INSTANCE_UID_TAG, instance_number)
        _source_sop_class_uid(ds, instance_number)
        _source_transfer_syntax_uid(ds, instance_number)
        file_meta = getattr(ds, "file_meta", None)
        file_meta_uid = (
            _element_value(file_meta, MEDIA_STORAGE_SOP_INSTANCE_UID_TAG)
            if file_meta is not None
            else None
        )
        if file_meta_uid is not None and str(file_meta_uid) != sop_instance_uid:
            raise ValueError(
                f"DICOM instance {instance_number} has inconsistent dataset and "
                "file-meta SOP Instance UIDs"
            )


def record_pseudonymous_identifiers(
    ds: pydicom.dataset.Dataset, identifier: str
) -> None:
    """Write the study identifier into the policy's pseudonym tags.

    Runs after removals and blanking so it is the last writer of these values,
    whatever the supplementary recipe did to them.
    """
    for tag in sorted(DEFAULT_DEID_PSEUDONYM_TAGS):
        vr = dictionary_VR(pydicom.tag.Tag(*tag))
        if len(identifier) > 64:
            raise ValueError(
                f"Identifier {identifier!r} exceeds the 64-character limit of "
                f"{_tag_label(tag)} [{vr}]"
            )
        ds.add_new(tag, vr, identifier)


def record_deidentification_method(ds: pydicom.dataset.Dataset) -> None:
    """Declare this profile in the PS3.15 de-identification attributes.

    Any method the source already recorded is kept: the export is the result of
    both, and a reader cannot tell which rule removed what from the id alone.
    """
    ds.add_new(PATIENT_IDENTITY_REMOVED_TAG, "CS", PATIENT_IDENTITY_REMOVED_VALUE)
    existing = [
        str(value)
        for value in _date_time_values(_element_value(ds, DEIDENTIFICATION_METHOD_TAG))
        if value is not None and str(value)
    ]
    if DEFAULT_DEIDENTIFICATION_PROFILE_ID not in existing:
        existing.append(DEFAULT_DEIDENTIFICATION_PROFILE_ID)
    ds.add_new(DEIDENTIFICATION_METHOD_TAG, "LO", existing)


def sanitise_file_meta(
    ds: pydicom.dataset.Dataset,
    transfer_syntax_uid: str,
) -> None:
    """Replace source file meta and preamble with a minimal safe Part-10 header."""
    sop_class_uid = _element_value(ds, SOP_CLASS_UID_TAG)
    sop_instance_uid = _element_value(ds, SOP_INSTANCE_UID_TAG)
    if not sop_class_uid or not sop_instance_uid:
        raise ValueError(
            "Cannot rebuild file meta without SOP Class and SOP Instance UIDs"
        )

    file_meta = FileMetaDataset()
    file_meta.add_new(
        MEDIA_STORAGE_SOP_CLASS_UID_TAG,
        "UI",
        str(sop_class_uid),
    )
    file_meta.add_new(
        MEDIA_STORAGE_SOP_INSTANCE_UID_TAG,
        "UI",
        str(sop_instance_uid),
    )
    file_meta.add_new(TRANSFER_SYNTAX_UID_TAG, "UI", transfer_syntax_uid)
    ds.file_meta = file_meta
    ds.preamble = ZEROED_DICOM_PREAMBLE


def preflight_uid_remapping(
    entries: Iterable[Tuple[Path, pydicom.dataset.Dataset]],
    remapper: RandomUIDRemapper,
    excluded_tags: Set[DicomTag] = frozenset(),
) -> Set[str]:
    """Validate and register every surviving identity UID before writing."""
    entries = list(entries)
    registered: Set[str] = set()

    # Require the hierarchy-defining values on every physical instance first.
    for instance_number, (_, ds) in enumerate(entries, start=1):
        required: Dict[DicomTag, str] = {}
        for tag in REQUIRED_UID_TAGS:
            uid = _required_uid(ds, tag, instance_number)
            remapper.remap(uid)
            registered.add(uid)
            required[tag] = uid

        file_meta = getattr(ds, "file_meta", None)
        file_meta_uid = (
            _element_value(file_meta, MEDIA_STORAGE_SOP_INSTANCE_UID_TAG)
            if file_meta is not None
            else None
        )
        if (
            file_meta_uid is not None
            and str(file_meta_uid) != required[SOP_INSTANCE_UID_TAG]
        ):
            raise ValueError(
                f"DICOM instance {instance_number} has inconsistent dataset and "
                "file-meta SOP Instance UIDs"
            )

    # Include entity/linkage UIDs and nested references, including references
    # whose target is outside this export. Registered semantic constants remain
    # unchanged so SOP classes, transfer syntaxes, and well-known instances work.
    for _, ds in entries:
        for elem in _iter_uid_elements(ds, excluded_tags):
            for uid in _uid_values(elem.value):
                tag = (elem.tag.group, elem.tag.element)
                replacement = _remap_uid_value(
                    tag,
                    uid,
                    remapper,
                )
                if replacement != uid:
                    registered.add(uid)

    return registered


def remap_dataset_uids(
    ds: pydicom.dataset.Dataset,
    remapper: RandomUIDRemapper,
) -> None:
    """Remap hierarchy UIDs and every matching in-dataset reference in place."""
    for elem in _iter_uid_elements(ds):
        value = elem.value
        is_multiple = isinstance(value, (MultiValue, list, tuple))
        values = list(value) if is_multiple else [value]
        remapped_values: List[Any] = []
        changed = False

        for item in values:
            if item is None:
                remapped_values.append(item)
                continue
            uid = str(item)
            if not uid:
                remapped_values.append(item)
                continue
            replacement = _remap_uid_value(
                (elem.tag.group, elem.tag.element),
                uid,
                remapper,
            )
            remapped_values.append(replacement)
            changed = changed or replacement != uid

        if changed:
            elem.value = remapped_values if is_multiple else remapped_values[0]


def _remappable_uid_signature(
    ds: pydicom.dataset.Dataset,
    remapper: Optional[RandomUIDRemapper] = None,
    excluded_tags: Set[DicomTag] = frozenset(),
) -> List[Tuple[DicomTag, Tuple[str, ...]]]:
    """Ordered signature of every UID occurrence and expected output value."""
    signature: List[Tuple[DicomTag, Tuple[str, ...]]] = []
    for elem in _iter_uid_elements(ds, excluded_tags):
        tag = (elem.tag.group, elem.tag.element)
        values = tuple(
            _remap_uid_value(tag, uid, remapper)
            if remapper is not None
            else uid
            for uid in _uid_values(elem.value)
        )
        signature.append((tag, values))
    return signature


def _validate_written_uid_hierarchy(
    entries: List[Tuple[Path, pydicom.dataset.Dataset]],
    destinations: List[Path],
    remapper: RandomUIDRemapper,
    removed_tags: Set[DicomTag],
) -> Dict[str, Any]:
    """Reread outputs and verify per-file study/series/SOP identity mappings."""
    output_studies: Set[str] = set()
    output_series: Set[str] = set()
    output_instances: Set[str] = set()

    for instance_number, ((_, source_ds), destination) in enumerate(
        zip(entries, destinations), start=1
    ):
        try:
            output_ds = pydicom.dcmread(
                destination,
                defer_size=DICOM_READ_DEFER_SIZE,
            )
        except Exception as exc:
            raise RuntimeError(
                f"Could not verify written DICOM instance {instance_number}"
            ) from exc

        actual: Dict[DicomTag, str] = {}
        for tag in REQUIRED_UID_TAGS:
            source_uid = _required_uid(source_ds, tag, instance_number)
            expected_uid = remapper.remap(source_uid)
            output_uid = _element_value(output_ds, tag)
            if output_uid is None or str(output_uid) != expected_uid:
                raise RuntimeError(
                    f"UID hierarchy verification failed for DICOM instance "
                    f"{instance_number} ({_tag_label(tag)})"
                )
            actual[tag] = str(output_uid)

        output_studies.add(actual[STUDY_INSTANCE_UID_TAG])
        output_series.add(actual[SERIES_INSTANCE_UID_TAG])
        output_instances.add(actual[SOP_INSTANCE_UID_TAG])

        output_file_meta = getattr(output_ds, "file_meta", None)
        file_meta_uid = (
            _element_value(output_file_meta, MEDIA_STORAGE_SOP_INSTANCE_UID_TAG)
            if output_file_meta is not None
            else None
        )
        if file_meta_uid is None or str(file_meta_uid) != actual[SOP_INSTANCE_UID_TAG]:
            raise RuntimeError(
                f"File-meta SOP Instance UID verification failed for DICOM "
                f"instance {instance_number}"
            )
        output_file_meta_sop_class = (
            _element_value(output_file_meta, MEDIA_STORAGE_SOP_CLASS_UID_TAG)
            if output_file_meta is not None
            else None
        )
        if str(output_file_meta_sop_class or "") != str(
            _element_value(output_ds, SOP_CLASS_UID_TAG) or ""
        ):
            raise RuntimeError(
                f"File-meta SOP Class UID verification failed for DICOM "
                f"instance {instance_number}"
            )
        expected_transfer_syntax = _source_transfer_syntax_uid(
            source_ds, instance_number
        )
        output_transfer_syntax = (
            _element_value(output_file_meta, TRANSFER_SYNTAX_UID_TAG)
            if output_file_meta is not None
            else None
        )
        if str(output_transfer_syntax or "") != expected_transfer_syntax:
            raise RuntimeError(
                f"File-meta transfer syntax verification failed for DICOM "
                f"instance {instance_number}"
            )
        output_implementation_uid = (
            _element_value(output_file_meta, IMPLEMENTATION_CLASS_UID_TAG)
            if output_file_meta is not None
            else None
        )
        if str(output_implementation_uid or "") != str(PYDICOM_IMPLEMENTATION_UID):
            raise RuntimeError(
                f"File-meta implementation verification failed for DICOM "
                f"instance {instance_number}"
            )
        unexpected_file_meta = [
            elem.keyword or str(elem.tag)
            for elem in output_file_meta
            if (elem.tag.group, elem.tag.element) not in ALLOWED_OUTPUT_FILE_META_TAGS
        ]
        if unexpected_file_meta or output_ds.preamble != ZEROED_DICOM_PREAMBLE:
            raise RuntimeError(
                f"File-meta sanitisation verification failed for DICOM "
                f"instance {instance_number}"
            )

        expected_references = _remappable_uid_signature(
            source_ds,
            remapper,
            removed_tags,
        )
        output_references = _remappable_uid_signature(output_ds)
        if output_references != expected_references:
            raise RuntimeError(
                f"Nested UID reference verification failed for DICOM instance "
                f"{instance_number}"
            )

    return {
        "hierarchy_verified": True,
        "uid_references_verified": True,
        "file_meta_sanitised": True,
        "instances_verified": len(entries),
        "output_study_count": len(output_studies),
        "output_series_count": len(output_series),
        "output_sop_instance_count": len(output_instances),
    }


def _preserved_value_signature(
    ds: pydicom.dataset.Dataset,
    retained_tags: AbstractSet[DicomTag],
    excluded_tags: Set[DicomTag] = frozenset(),
) -> List[Tuple[DicomTag, Tuple[str, ...]]]:
    """Ordered recursive signature of retained fields that survive policy."""
    signature: List[Tuple[DicomTag, Tuple[str, ...]]] = []
    for tag in sorted(ds.keys()):
        tag_tuple = (tag.group, tag.element)
        if tag_tuple in excluded_tags:
            continue
        elem = ds.get_item(tag, keep_deferred=True)
        if tag_tuple in retained_tags:
            if isinstance(elem, RawDataElement):
                elem = ds[tag]
            values = _date_time_values(elem.value)
            signature.append(
                (
                    tag_tuple,
                    tuple("" if value is None else str(value) for value in values),
                )
            )
            continue

        vr = getattr(elem, "VR", None)
        if isinstance(elem, RawDataElement) and vr is None:
            try:
                vr = dictionary_VR(tag)
            except KeyError:
                vr = None
        if vr == "SQ":
            sequence = ds[tag] if isinstance(elem, RawDataElement) else elem
            for item in sequence.value or ():
                signature.extend(
                    _preserved_value_signature(item, retained_tags, excluded_tags)
                )
    return signature


def _validate_written_deidentification_profile(
    entries: List[Tuple[Path, pydicom.dataset.Dataset]],
    destinations: List[Path],
    *,
    offset_days: Optional[int],
    removed_tags: Set[DicomTag],
    identifier: str,
) -> Dict[str, Any]:
    """Verify fixed removals, shifted dates, reuse fields, and pseudonyms."""
    for instance_number, ((_, source_ds), destination) in enumerate(
        zip(entries, destinations), start=1
    ):
        try:
            output_ds = pydicom.dcmread(
                destination,
                defer_size=DICOM_READ_DEFER_SIZE,
            )
        except Exception as exc:
            raise RuntimeError(
                f"Could not verify de-identification profile for DICOM "
                f"instance {instance_number}"
            ) from exc

        for tag in sorted(DEFAULT_DEID_PSEUDONYM_TAGS):
            written = _element_value(output_ds, tag)
            if written is None or str(written) != identifier:
                raise RuntimeError(
                    f"DICOM instance {instance_number} has "
                    f"{_tag_label(tag)}={written!r}, expected the study "
                    f"identifier {identifier!r}"
                )

        remaining = _collect_profile_removal_tags(
            output_ds,
            remove_date_times=offset_days is None,
        )
        if remaining:
            formatted = ", ".join(
                f"({group:04X},{element:04X})"
                for group, element in sorted(remaining)
            )
            raise RuntimeError(
                f"De-identification profile verification failed for DICOM "
                f"instance {instance_number}: {formatted}"
            )

        retained_tags = _retained_value_tags(offset_days)
        expected_preserved = _preserved_value_signature(
            source_ds,
            retained_tags,
            removed_tags,
        )
        actual_preserved = _preserved_value_signature(output_ds, retained_tags)
        if actual_preserved != expected_preserved:
            raise RuntimeError(
                "Reuse-field preservation verification failed for DICOM "
                f"instance {instance_number}"
            )

        if offset_days is not None:
            expected_dates = _date_time_signature(
                source_ds,
                offset_days=offset_days,
                excluded_tags=removed_tags,
            )
            actual_dates = _date_time_signature(output_ds)
            if actual_dates != expected_dates:
                raise RuntimeError(
                    "Date normalisation verification failed for DICOM "
                    f"instance {instance_number}"
                )

    return {
        "enabled": True,
        "verified": True,
        "dates_verified": True,
        "reuse_fields_verified": True,
        "instances_verified": len(entries),
    }


def deidentify_study(
    entries: List[Tuple[Path, pydicom.dataset.Dataset]],
    output_root: Path,
    input_root: Path,
    identifier: str,
    strip_phi: bool = DEFAULT_STRIP_PHI,
    normalise_dates: bool = DEFAULT_NORMALISE_DATES,
    anchor_date: date = DEFAULT_ANCHOR_DATE,
    strip_private_tag_text: bool = DEFAULT_STRIP_PRIVATE_TAG_TEXT,
    allowed_tags: Optional[List[DicomTag]] = None,
    uid_remapper: Optional[RandomUIDRemapper] = None,
) -> Dict[str, Any]:
    """De-identify one study's files and write them under `output_root`, mirroring their position under `input_root`."""
    if not entries:
        raise ValueError("deidentify_study requires at least one DICOM instance")
    if strip_phi and uid_remapper is None:
        raise ValueError(
            "The fixed de-identification profile requires UID hashing; "
            "provide a project-scoped UID remapper"
        )
    _validate_separate_roots(input_root, output_root)
    destinations = _output_destinations(entries, output_root, input_root)
    full_entries: List[Tuple[Path, pydicom.dataset.Dataset]] = []
    headers: List[pydicom.dataset.Dataset] = []
    for instance_number, (path, _) in enumerate(entries, start=1):
        try:
            full_header = pydicom.dcmread(path, defer_size=DICOM_READ_DEFER_SIZE)
            header = pydicom.dcmread(path, stop_before_pixels=True)
        except Exception as exc:
            raise ValueError(
                f"Could not fully parse DICOM instance {instance_number}"
            ) from exc
        full_entries.append((path, full_header))
        headers.append(header)
    validate_source_datasets(full_entries)

    registered_uids: Set[str] = set()
    if uid_remapper is not None:
        registered_uids = preflight_uid_remapping(
            full_entries,
            uid_remapper,
            DEFAULT_DEID_REMOVE_TAGS if strip_phi else frozenset(),
        )

    offset_days = None
    if normalise_dates:
        if strip_phi:
            _validate_profile_date_times_are_shiftable(full_entries)
        # Derive the study-wide offset from the complete datasets so that
        # nested or late-stream DA/DT elements participate in the same
        # longitudinal transformation as ordinary header dates.
        offset_days = compute_offset_days(
            [dataset for _, dataset in full_entries],
            anchor_date,
            DEFAULT_DEID_REMOVE_TAGS if strip_phi else frozenset(),
        )
        if offset_days is None:
            logger.warning("No DA/DT elements found; dates left unchanged.")
        else:
            for h in headers:
                shift_dataset_dates(h, offset_days)

    blanked_tags: Set[DicomTag] = set()
    profile_removed_tags: Set[DicomTag] = set()
    audit = None
    if strip_phi:
        audit = audit_deidentification(
            (dataset for _, dataset in full_entries),
            allowed_tags=allowed_tags,
        )
        if not audit["supplementary_policy_available"]:
            raise RuntimeError(
                "Supplementary de-identification policy could not be loaded "
                "or normalized completely"
            )
        exclude_vrs = set(SHIFTED_DATE_VRS if offset_days is not None else ())
        if uid_remapper is not None:
            # Every surviving UI value is handled by the remapper or protected
            # semantic-UID policy. Fixed UI removals are collected separately.
            exclude_vrs.add("UI")
        blanked_tags = set(
            flagged_tags(audit, strip_private_tag_text=strip_private_tag_text, exclude_vrs=exclude_vrs)
        )
        if uid_remapper is not None:
            uid_tags = {
                (elem.tag.group, elem.tag.element)
                for _, dataset in full_entries
                for elem in _iter_uid_elements(dataset, DEFAULT_DEID_REMOVE_TAGS)
            }
            blanked_tags.difference_update(uid_tags)

        for _, full_header in full_entries:
            profile_removed_tags.update(
                _collect_profile_removal_tags(
                    full_header,
                    remove_date_times=offset_days is None,
                )
            )
        blanked_tags.difference_update(_retained_value_tags(offset_days))
        blanked_tags.difference_update(profile_removed_tags)

    transformed_tags = blanked_tags | profile_removed_tags

    for instance_number, ((path, source_header), destination) in enumerate(
        zip(full_entries, destinations), start=1
    ):
        ds = pydicom.dcmread(path)
        if offset_days is not None:
            shift_dataset_dates(ds, offset_days)
        if blanked_tags:
            strip_dataset_tags(ds, blanked_tags)
        if profile_removed_tags:
            remove_dataset_tags(ds, profile_removed_tags)
        if uid_remapper is not None:
            remap_dataset_uids(ds, uid_remapper)
        if strip_phi:
            record_pseudonymous_identifiers(ds, identifier)
            record_deidentification_method(ds)
        sanitise_file_meta(
            ds,
            _source_transfer_syntax_uid(source_header, instance_number),
        )
        destination.parent.mkdir(parents=True, exist_ok=True)
        ds.save_as(destination, enforce_file_format=True)

    profile_result: Dict[str, Any] = {"enabled": False, "verified": False}
    if strip_phi:
        profile_result = _validate_written_deidentification_profile(
            full_entries,
            destinations,
            offset_days=offset_days,
            removed_tags=profile_removed_tags,
            identifier=identifier,
        )

    uid_result: Dict[str, Any] = {"enabled": False}
    if uid_remapper is not None:
        uid_result = {
            "enabled": True,
            "scheme": UID_GENERATION_SCHEME,
            "truncated_bits": UID_TRUNCATED_BITS,
            "uid_root": UID_ROOT,
            "distinct_uid_count": len(registered_uids),
            "study_instance_uid": uid_remapper.remap(
                _required_uid(headers[0], STUDY_INSTANCE_UID_TAG, 1)
            ),
            **_validate_written_uid_hierarchy(
                full_entries,
                destinations,
                uid_remapper,
                profile_removed_tags,
            ),
        }
        if strip_phi:
            profile_result["uids_verified"] = True

    return {
        "instance_count": len(entries),
        "date_offset_days": offset_days,
        "stripped_tag_count": len(transformed_tags),
        "blanked_tag_count": len(blanked_tags),
        "profile_removed_tag_count": len(profile_removed_tags),
        "audit": audit,
        "deidentification_profile": profile_result,
        "uid_remapping": uid_result,
        # This study's own pairs. Taken from the UIDs registered for these
        # entries, not from the run-wide remapper, which holds every study's.
        "uid_pairs": {
            uid: uid_remapper.mapping[uid]
            for uid in sorted(registered_uids)
            if uid in uid_remapper.mapping
        },
        "destinations": destinations,
    }


def write_deidentification_manifest(
    output_root: Path,
    study_results: List[Dict[str, Any]],
    file_count: int,
) -> Path:
    """Write an export-safe run manifest without source linkage or PHI values."""
    uid_enabled = any(r["uid_remapping"]["enabled"] for r in study_results)
    profile_results = [
        r.get(
            "deidentification_profile",
            {"enabled": False, "verified": False},
        )
        for r in study_results
    ]
    profile_enabled = bool(profile_results) and all(
        result["enabled"] for result in profile_results
    )
    manifest: Dict[str, Any] = {
        "schema_version": 1,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "study_count": len(study_results),
        "file_count": file_count,
        "deidentification_profile": {
            "id": DEFAULT_DEIDENTIFICATION_PROFILE_ID,
            "enabled": profile_enabled,
            "verified": (
                profile_enabled
                and all(result["verified"] for result in profile_results)
            ),
            "effective_concrete_tag_count": (
                DEFAULT_DEID_EFFECTIVE_CONCRETE_TAG_COUNT
            ),
        },
        "uid_remapping": {
            "enabled": uid_enabled,
            "scheme": UID_GENERATION_SCHEME if uid_enabled else None,
            "truncated_bits": UID_TRUNCATED_BITS if uid_enabled else None,
            "uid_root": UID_ROOT if uid_enabled else None,
        },
        "studies": [
            {
                "study_number": study_number,
                "file_count": result["instance_count"],
                "dates_normalised": result["date_offset_days"] is not None,
                "stripped_tag_count": result["stripped_tag_count"],
                "profile_removed_tag_count": result.get(
                    "profile_removed_tag_count",
                    0,
                ),
                "deidentification_profile": result.get(
                    "deidentification_profile",
                    {"enabled": False, "verified": False},
                ),
                "uid_remapping": result["uid_remapping"],
            }
            for study_number, result in enumerate(study_results, start=1)
        ],
    }

    output_root.mkdir(parents=True, exist_ok=True)
    destination = output_root / DEFAULT_DEIDENTIFICATION_MANIFEST_FILENAME
    temporary = output_root / f".{DEFAULT_DEIDENTIFICATION_MANIFEST_FILENAME}.tmp"
    with open(temporary, "x") as f:
        json.dump(manifest, f, indent=2)
    os.replace(temporary, destination)
    return destination


def main(config_path: Path) -> None:
    """De-identify every study found under `input_directory`, writing results to `output_directory`."""
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
    except FileNotFoundError:
        logger.error(f"Config not found: {config_path}")
        return
    except Exception as e:
        logger.error(f"Config error: {e}")
        return

    if not isinstance(config, dict):
        logger.error("Config root must be a JSON object.")
        return

    input_dir = config.get("input_directory")
    output_dir = config.get("output_directory")
    if not isinstance(input_dir, str) or not input_dir.strip():
        logger.error(
            f"Set 'input_directory' in {config_path} "
            "(the DICOM scan root; may contain multiple studies)."
        )
        return
    if not isinstance(output_dir, str) or not output_dir.strip():
        logger.error(
            "Set 'output_directory': de-identification writes new files and must "
            "never overwrite the source data in place."
        )
        return

    input_root = Path(input_dir)
    output_root = Path(output_dir)
    try:
        _validate_separate_roots(input_root, output_root)
    except ValueError as exc:
        logger.error("%s.", exc)
        return

    if output_root.exists():
        try:
            output_is_nonempty = any(output_root.iterdir())
        except OSError as exc:
            logger.error("Cannot inspect 'output_directory': %s", exc)
            return
        if output_is_nonempty:
            logger.error(
                "'output_directory' must be absent or empty; use a fresh export "
                "directory to avoid overwrites and mixed key versions."
            )
            return

    linkage_dir = config.get("linkage_directory")
    if not isinstance(linkage_dir, str) or not linkage_dir.strip():
        logger.error(
            "Set 'linkage_directory': it receives the source metadata and the "
            "source-to-output UID mapping, without which an export cannot be "
            "relinked. It belongs in the source security zone, never inside "
            "'output_directory'."
        )
        return
    linkage_root = Path(linkage_dir)
    resolved_linkage = linkage_root.resolve()
    if (
        resolved_linkage == output_root.resolve()
        or resolved_linkage.is_relative_to(output_root.resolve())
        or output_root.resolve().is_relative_to(resolved_linkage)
    ):
        logger.error(
            "'linkage_directory' must be outside 'output_directory'; together "
            "with the export it is a linkage record and must not be released "
            "with it."
        )
        return
    if resolved_linkage.is_relative_to(input_root.resolve()):
        logger.error(
            "'linkage_directory' must be outside 'input_directory', which is "
            "treated as read-only."
        )
        return
    if linkage_root.exists() and any(linkage_root.iterdir()):
        logger.error(
            "'linkage_directory' must be absent or empty; a stale mapping "
            "would not describe this export."
        )
        return

    try:
        write_nifti = _boolean_config(config, "write_nifti", False)
        nifti_directory = _optional_config_str(config, "nifti_directory")
    except ValueError as exc:
        logger.error("%s.", exc)
        return
    nifti_root = Path(nifti_directory) if nifti_directory else None
    if nifti_root is not None and not write_nifti:
        logger.error(
            "'nifti_directory' is set but 'write_nifti' is false; enable "
            "'write_nifti' or remove the directory."
        )
        return
    if nifti_root is not None and nifti_root.resolve().is_relative_to(
        input_root.resolve()
    ):
        logger.error(
            "'nifti_directory' must be outside 'input_directory', which is "
            "treated as read-only."
        )
        return

    participant_id_map = None
    try:
        centre = _optional_config_str(config, "centre")
        tissue_source_site = _optional_config_str(config, "tissue_source_site")
        participant_id_map_path = _optional_config_str(config, "participant_id_map")
        for name, value in (("centre", centre),
                            ("tissue_source_site", tissue_source_site)):
            if value is not None:
                validate_pharos_component(value, name=f"'{name}'")
        if participant_id_map_path is not None:
            participant_id_map = load_participant_id_map(Path(participant_id_map_path))
    except ValueError as exc:
        logger.error("%s.", exc)
        return

    if not (participant_id_map and centre and tissue_source_site):
        logger.info(
            "No complete participant attribution configured; studies will be "
            "named by their hash segment alone, which is the suffix the full "
            "PharosID would end with."
        )

    try:
        replace_uids = _boolean_config(config, "replace_uids", DEFAULT_REPLACE_UIDS)
        strip_phi = _boolean_config(config, "strip_phi", DEFAULT_STRIP_PHI)
        normalise_dates_flag = _boolean_config(
            config,
            "normalise_dates",
            DEFAULT_NORMALISE_DATES,
        )
        strip_private_tag_text = _boolean_config(
            config,
            "strip_private_tag_text",
            DEFAULT_STRIP_PRIVATE_TAG_TEXT,
        )
    except ValueError as exc:
        logger.error("%s.", exc)
        return

    uid_remapper = RandomUIDRemapper() if replace_uids else None

    if "allowed_tags" not in config:
        allowed_tags = list(DEFAULT_DEID_ALLOWED_TAGS)
    else:
        configured_allowed_tags = config["allowed_tags"]
        if not isinstance(configured_allowed_tags, list):
            logger.error(
                "'allowed_tags' must be a JSON list of DICOM tag codes "
                "formatted as 'GGGG,EEEE'."
            )
            return
        try:
            allowed_tags = [
                _parse_tag_code(value) for value in configured_allowed_tags
            ]
        except ValueError as exc:
            logger.error("Invalid 'allowed_tags' entry: %s.", exc)
            return

    anchor_date_str = config.get("anchor_date", DEFAULT_ANCHOR_DATE.isoformat())
    if not isinstance(anchor_date_str, str):
        logger.error("'anchor_date' must be a YYYY-MM-DD string.")
        return
    try:
        anchor_date = date.fromisoformat(anchor_date_str)
        if anchor_date.isoformat() != anchor_date_str:
            raise ValueError("non-canonical date format")
    except ValueError as e:
        logger.error(f"'anchor_date' must be YYYY-MM-DD, got {anchor_date_str!r}: {e}")
        return

    files = discover_dicom_files(input_root)
    if not files:
        logger.error(f"No DICOM files found under {input_root}")
        return

    studies = group_by_study(
        files,
        stop_before_pixels=False,
        defer_size=DICOM_READ_DEFER_SIZE,
    )
    grouped_file_count = sum(len(entries) for entries in studies.values())
    if not studies or grouped_file_count != len(files):
        logger.error(
            "DICOM grouping parsed %d of %d discovered file(s); refusing a "
            "partial de-identification export.",
            grouped_file_count,
            len(files),
        )
        return
    all_entries = [
        entry
        for study_entries in studies.values()
        for entry in study_entries
    ]
    try:
        validate_source_datasets(all_entries)
    except (TypeError, ValueError) as exc:
        logger.error("DICOM file-meta preflight failed: %s", exc)
        return
    if uid_remapper is not None:
        try:
            preflight_uid_remapping(
                all_entries,
                uid_remapper,
                DEFAULT_DEID_REMOVE_TAGS if strip_phi else frozenset(),
            )
        except (TypeError, ValueError, RuntimeError) as exc:
            logger.error("UID remapping preflight failed: %s", exc)
            return

    if strip_phi and not replace_uids:
        logger.error(
            "The fixed de-identification profile requires 'replace_uids' to be "
            "true; source UIDs would survive into the export."
        )
        return
    if not replace_uids:
        logger.warning(
            "'replace_uids' is false: the export keeps its source UIDs and is "
            "directly linkable to the source data. Never release it."
        )

    if strip_phi and normalise_dates_flag:
        try:
            for study_entries in studies.values():
                _validate_profile_date_times_are_shiftable(study_entries)
        except (TypeError, ValueError) as exc:
            logger.error("Date normalisation preflight failed: %s", exc)
            return

    logger.info(
        "De-identifying %d study(ies), %d file(s) "
        "(strip_phi=%s, normalise_dates=%s, uid_scheme=%s)",
        len(studies),
        len(files),
        strip_phi,
        normalise_dates_flag,
        UID_GENERATION_SCHEME,
    )

    # Resolve every study's identifier before writing anything. A study that
    # cannot be named — mixed modality, no pixels, no mapped participant —
    # would otherwise abort partway and leave a partial export, and every such
    # study is reported in one pass so they can be fixed together.
    plan: List[Tuple[str, str, List[Tuple[Path, pydicom.dataset.Dataset]], Path, str]] = []
    identifiers: Dict[str, str] = {}
    naming_problems: List[str] = []
    for source_study_uid, entries in studies.items():
        study_dir = study_directory(entries)
        try:
            modality = _study_modality(entries)
            pixel_digest = study_pixel_digest(ds for _, ds in entries)
            participant_id = (
                resolve_participant_id(study_dir, input_root, participant_id_map)
                if participant_id_map is not None
                else None
            )
        except ValueError as exc:
            naming_problems.append(f"{study_dir}: {exc}")
            continue

        identifier = study_identifier(
            modality,
            pixel_digest,
            participant_id=participant_id,
            centre=centre,
            tissue_source_site=tissue_source_site,
        )
        if identifier in identifiers:
            naming_problems.append(
                f"{study_dir}: identifier {identifier} is already taken by study "
                f"{identifiers[identifier]}; the two have identical pixel content "
                "and cannot be told apart in the export"
            )
            continue
        identifiers[identifier] = source_study_uid
        plan.append((identifier, source_study_uid, entries, study_dir, pixel_digest))

    if naming_problems:
        logger.error(
            "%d of %d study(ies) cannot be named; refusing to write a partial "
            "export:\n  %s",
            len(naming_problems),
            len(studies),
            "\n  ".join(naming_problems),
        )
        return

    study_results: List[Dict[str, Any]] = []
    linkage_digests: Dict[str, Dict[str, str]] = {}
    for study_number, (
        identifier,
        source_study_uid,
        entries,
        study_dir,
        pixel_digest,
    ) in enumerate(plan, start=1):
        # Each study is exported under its own identifier, so source directory
        # names never reach the export root.
        result = deidentify_study(
            entries,
            output_root / identifier,
            study_dir,
            identifier,
            strip_phi=strip_phi,
            normalise_dates=normalise_dates_flag,
            anchor_date=anchor_date,
            strip_private_tag_text=strip_private_tag_text,
            allowed_tags=allowed_tags,
            uid_remapper=uid_remapper,
        )
        result["identifier"] = identifier
        # uid_pairs and destinations are run-internal; the manifest ships with
        # the export and must carry neither source UIDs nor source paths.
        study_results.append({
            k: v for k, v in result.items()
            if k not in ("uid_pairs", "destinations")
        })
        uid_result = result["uid_remapping"]

        linkage_digests[identifier] = write_study_linkage(
            linkage_root,
            identifier,
            source_study_uid,
            entries,
            result["uid_pairs"],
            pixel_digest,
            replace_uids,
        )
        # The export-side pass describes what was written, so it reads the
        # output rather than transforming the source metadata.
        _write_json(
            output_root / identifier / DEFAULT_OUTPUT_FILENAME,
            _study_metadata_from_files(
                uid_result.get("study_instance_uid") or source_study_uid,
                result["destinations"],
            ),
        )

        if write_nifti:
            # Converted from the written export, so the NIfTI can only ever
            # contain what was already cleared for release.
            nifti_directory_for_study = (
                output_root / identifier if nifti_root is None
                else nifti_root / identifier
            )
            nifti_result = convert_study_to_nifti(
                [
                    (path, pydicom.dcmread(path))
                    for path in result["destinations"]
                ],
                nifti_directory_for_study,
            )
            result["nifti"] = nifti_result
            logger.info(
                "Study %d/%d [%s]: %d NIfTI series written, %d skipped -> %s",
                study_number, len(plan), identifier,
                nifti_result["written_count"], nifti_result["skipped_count"],
                nifti_directory_for_study,
            )

        logger.info(
            "Study %d/%d [%s]: %d file(s), dates_normalised=%s, "
            "%d tag(s) stripped, UID remapping=%s%s",
            study_number,
            len(plan),
            identifier,
            len(entries),
            result["date_offset_days"] is not None,
            result["stripped_tag_count"],
            "verified" if uid_result["enabled"] else "disabled",
            (
                f", pseudonymous_study_uid={uid_result['study_instance_uid']}"
                if uid_result["enabled"]
                else ""
            ),
        )

    _write_json(
        linkage_root / "run_record.json",
        {
            "schema_version": 1,
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "config_path": str(config_path.resolve()),
            "config": config,
            "input_directory": str(input_root.resolve()),
            "output_directory": str(output_root.resolve()),
            "deidentification_profile_id": DEFAULT_DEIDENTIFICATION_PROFILE_ID,
            "uid_generation_scheme": UID_GENERATION_SCHEME,
            "study_count": len(study_results),
            "file_count": len(files),
            "studies": [
                {
                    "identifier": identifier,
                    "source_study_instance_uid": source_uid,
                    "file_digests": linkage_digests[identifier],
                }
                for identifier, source_uid in identifiers.items()
            ],
        },
    )

    write_deidentification_manifest(
        output_root,
        study_results,
        len(files),
    )
    logger.info(
        "De-identification completed with an export manifest for %d study(ies).",
        len(study_results),
    )


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    config_arg = (Path(sys.argv[1]) if len(sys.argv) > 1
                  else Path(__file__).resolve().parent / "config.json")
    main(config_arg)
