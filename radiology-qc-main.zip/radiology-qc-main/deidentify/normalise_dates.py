from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import AbstractSet, Any, List, Optional, Union

import pydicom
from pydicom.dataelem import RawDataElement
from pydicom.datadict import dictionary_VR

from deidentify.settings import DicomTag

_DATE_VRS = ("DA", "DT")


def _parse_da(value: Union[str, "pydicom.valuerep.DA"]) -> Optional[date]:
    text = str(value).strip()
    if len(text) < 8:
        return None
    try:
        return datetime.strptime(text[:8], "%Y%m%d").date()
    except ValueError:
        return None


def _parse_dt_date(value: Union[str, "pydicom.valuerep.DT"]) -> Optional[date]:
    """Return the date prefix of a DICOM datetime."""
    return _parse_da(value)


def date_time_value_date(value: Any, vr: str) -> Optional[date]:
    """Return the calendar date a DA/DT value carries, or None if it has none."""
    if vr not in _DATE_VRS or value is None:
        return None
    return _parse_da(value)


def _shift_da_value(value: str, offset_days: int) -> str:
    parsed = _parse_da(value)
    if parsed is None:
        return value
    return (parsed + timedelta(days=offset_days)).strftime("%Y%m%d")


def _shift_dt_value(value: str, offset_days: int) -> str:
    """Shift the date prefix while preserving the remaining value."""
    text = str(value).strip()
    parsed = _parse_dt_date(text)
    if parsed is None:
        return value
    shifted = (parsed + timedelta(days=offset_days)).strftime("%Y%m%d")
    return shifted + text[8:]


def _shift_value(value, vr: str, offset_days: int):
    if isinstance(value, pydicom.multival.MultiValue):
        return [_shift_value(v, vr, offset_days) for v in value]
    if vr == "DA":
        return _shift_da_value(value, offset_days)
    return _shift_dt_value(value, offset_days)


def can_shift_date_time_value(value: Any, vr: str) -> bool:
    """Return whether every populated DA/DT value has a shiftable date."""
    if isinstance(value, (pydicom.multival.MultiValue, list, tuple)):
        return all(can_shift_date_time_value(item, vr) for item in value)
    if value is None or not str(value).strip():
        return True
    text = str(value).strip()
    try:
        pydicom.valuerep.validate_value(vr, text, pydicom.config.RAISE)
    except (TypeError, ValueError):
        return False
    if vr == "DA":
        if len(text) != 8 or not text.isdigit() or _parse_da(text) is None:
            return False
        try:
            return pydicom.valuerep.DA(text) is not None
        except (TypeError, ValueError):
            return False
    if vr == "DT":
        if len(text) < 8 or not text[:8].isdigit() or _parse_dt_date(text) is None:
            return False
        try:
            return pydicom.valuerep.DT(text) is not None
        except (TypeError, ValueError):
            return False
    return False


def shift_date_time_value(value: Any, vr: str, offset_days: int):
    """Return a DA/DT value shifted using the writer's canonical method."""
    if vr not in _DATE_VRS:
        raise ValueError("Date shifting only supports DA and DT values")
    return _shift_value(value, vr, offset_days)


def study_earliest_date(
    datasets: List[pydicom.dataset.Dataset],
    excluded_tags: AbstractSet[DicomTag] = frozenset(),
) -> Optional[date]:
    """Return the earliest DA/DT date in a study."""
    earliest: Optional[date] = None
    for ds in datasets:
        for tag in sorted(ds.keys()):
            if (tag.group, tag.element) in excluded_tags:
                continue
            elem = ds.get_item(tag, keep_deferred=True)
            vr = getattr(elem, "VR", None)
            if isinstance(elem, RawDataElement):
                if vr is None:
                    try:
                        vr = dictionary_VR(tag)
                    except KeyError:
                        vr = None
                if vr not in _DATE_VRS and vr != "SQ":
                    continue
                elem = ds[tag]
            if elem is None:
                continue
            if elem.VR == "SQ":
                nested = study_earliest_date(
                    list(elem.value or ()),
                    excluded_tags,
                )
                if nested is not None and (earliest is None or nested < earliest):
                    earliest = nested
                continue
            if elem.VR not in _DATE_VRS or not elem.value:
                continue
            values = (
                elem.value if isinstance(elem.value, pydicom.multival.MultiValue) else [elem.value]
            )
            for v in values:
                parsed = date_time_value_date(v, elem.VR)
                if parsed is not None and (earliest is None or parsed < earliest):
                    earliest = parsed
    return earliest


def compute_offset_days(
    datasets: List[pydicom.dataset.Dataset],
    anchor_date: date,
    excluded_tags: AbstractSet[DicomTag] = frozenset(),
) -> Optional[int]:
    """Return the offset that moves the earliest date to ``anchor_date``."""
    earliest = study_earliest_date(datasets, excluded_tags)
    if earliest is None:
        return None
    return (anchor_date - earliest).days


def shift_dataset_dates(ds: pydicom.dataset.Dataset, offset_days: int) -> None:
    """Shift every populated DA/DT element recursively by `offset_days`."""
    for elem in ds:
        if elem.VR == "SQ":
            for item in elem.value or ():
                shift_dataset_dates(item, offset_days)
            continue
        if elem.VR not in _DATE_VRS or not elem.value:
            continue
        elem.value = _shift_value(elem.value, elem.VR, offset_days)
