"""Central defaults, policy, and fixed invariants for DICOM de-identification.

The bracketed code after each policy tag is its DICOM Value Representation, the
value type that decides how the writer empties an element and whether a rule can
apply to it at all:

    AE  Application Entity      LO  Long String (64 chars)
    AS  Age String              LT  Long Text (10240 chars)
    CS  Code String             OB  Other Byte (binary)
    DA  Date (YYYYMMDD)         PN  Person Name
    DS  Decimal String          SH  Short String (16 chars)
    DT  Date Time               SQ  Sequence of Items
    TM  Time (HHMMSS.FFFFFF)    ST  Short Text (1024 chars)
    UI  Unique Identifier       US  Unsigned Short (16-bit)

Only DA and DT carry a shiftable date; TM is wall-clock only; SQ and OB hold
nested or opaque content that is deleted whole rather than blanked.
"""

from __future__ import annotations

import re
from datetime import date
from types import MappingProxyType
from typing import Mapping

DicomTag = tuple[int, int]

# Run defaults. Secrets remain environment-injected and are never settings values.
DEFAULT_ANCHOR_DATE = date(2020, 1, 1)
DEFAULT_DEIDENTIFICATION_MANIFEST_FILENAME = "deidentification_manifest.json"
DEFAULT_DEIDENTIFICATION_PROFILE_ID = "radqc-default-v1"
DEIDENTIFICATION_METHOD_TAG: DicomTag = (0x0012, 0x0063)
PATIENT_IDENTITY_REMOVED_VALUE = "YES"
DEFAULT_UID_HMAC_KEY_ENV = "RADQC_UID_HMAC_KEY"
DEFAULT_REPLACE_UIDS = True
DEFAULT_STRIP_PHI = True
DEFAULT_NORMALISE_DATES = True
DEFAULT_STRIP_PRIVATE_TAG_TEXT = True
DEFAULT_DEID_ALLOWED_TAGS: tuple[DicomTag, ...] = ()

# Fixed UID mapping and DICOM validation invariants. Changing these values changes
# the mapping scheme or its security/interoperability properties.
UID_GENERATION_SCHEME = "random-128-bit"
UID_ROOT = "2.25"
UID_DIGEST_BYTES = 16
UID_TRUNCATED_BITS = UID_DIGEST_BYTES * 8
# Bounded retry for the ~2^-128 chance of generating a UID already in use.
UID_GENERATION_ATTEMPTS = 8
MAX_DICOM_UID_LENGTH = 64
CANONICAL_DICOM_UID_RE = re.compile(
    r"(?:0|[1-9][0-9]*)(?:\.(?:0|[1-9][0-9]*))*\Z"
)
ENVIRONMENT_VARIABLE_NAME_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\Z")
DICOM_TAG_CODE_RE = re.compile(r"[0-9A-Fa-f]{4},[0-9A-Fa-f]{4}\Z")
# PharosID fields are joined with "_", so no component may contain one.
PHAROS_COMPONENT_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9-]*\Z")

# Writer policy and Part-10 output invariants.
SHIFTED_DATE_VRS = frozenset({"DA", "DT"})
SOP_CLASS_UID_TAG: DicomTag = (0x0008, 0x0016)
SOP_INSTANCE_UID_TAG: DicomTag = (0x0008, 0x0018)
STUDY_INSTANCE_UID_TAG: DicomTag = (0x0020, 0x000D)
SERIES_INSTANCE_UID_TAG: DicomTag = (0x0020, 0x000E)
MEDIA_STORAGE_SOP_CLASS_UID_TAG: DicomTag = (0x0002, 0x0002)
MEDIA_STORAGE_SOP_INSTANCE_UID_TAG: DicomTag = (0x0002, 0x0003)
TRANSFER_SYNTAX_UID_TAG: DicomTag = (0x0002, 0x0010)
IMPLEMENTATION_CLASS_UID_TAG: DicomTag = (0x0002, 0x0012)
BURNED_IN_ANNOTATION_TAG: DicomTag = (0x0028, 0x0301)
PATIENT_IDENTITY_REMOVED_TAG: DicomTag = (0x0012, 0x0062)
PIXEL_DATA_TAG: DicomTag = (0x7FE0, 0x0010)
REQUIRED_UID_TAGS: tuple[DicomTag, ...] = (
    STUDY_INSTANCE_UID_TAG,
    SERIES_INSTANCE_UID_TAG,
    SOP_INSTANCE_UID_TAG,
)
PRIMARY_IDENTITY_UID_TAGS = frozenset(REQUIRED_UID_TAGS) | frozenset({
    MEDIA_STORAGE_SOP_INSTANCE_UID_TAG,
})
FORCE_REMAP_UID_TAGS = frozenset({
    (0x0018, 0x100B),  # ManufacturerDeviceClassUID
    (0x0040, 0xDB0D),  # TemplateExtensionCreatorUID
    (0x0040, 0xDB0C),  # TemplateExtensionOrganizationUID
})
PROTECTED_UID_TAGS = frozenset({
    (0x0000, 0x0002),  # AffectedSOPClassUID
    (0x0000, 0x0003),  # RequestedSOPClassUID
    MEDIA_STORAGE_SOP_CLASS_UID_TAG,
    TRANSFER_SYNTAX_UID_TAG,
    (0x0002, 0x0032),  # RTVCommunicationSOPClassUID
    (0x0004, 0x1510),  # ReferencedSOPClassUIDInFile
    (0x0004, 0x1512),  # ReferencedTransferSyntaxUIDInFile
    (0x0004, 0x151A),  # ReferencedRelatedGeneralSOPClassUIDInFile
    SOP_CLASS_UID_TAG,
    (0x0008, 0x001A),  # RelatedGeneralSOPClassUID
    (0x0008, 0x001B),  # OriginalSpecializedSOPClassUID
    (0x0008, 0x0062),  # SOPClassesInStudy
    (0x0008, 0x040E),  # StoredInstanceTransferSyntaxUID
    (0x0008, 0x010C),  # CodingSchemeUID
    (0x0008, 0x0117),  # ContextUID
    (0x0008, 0x0118),  # MappingResourceUID
    (0x0008, 0x1150),  # ReferencedSOPClassUID
    (0x0008, 0x115A),  # SOPClassesSupported
    (0x0008, 0x3002),  # AvailableTransferSyntaxUID
    (0x0034, 0x0003),  # FlowTransferSyntaxUID
    (0x0400, 0x0010),  # MACCalculationTransferSyntaxUID
    (0x0400, 0x0510),  # EncryptedContentTransferSyntaxUID
    (0x3010, 0x0052),  # PertinentSOPClassesInStudy
    (0x3010, 0x0053),  # PertinentSOPClassesInSeries
})
ALLOWED_OUTPUT_FILE_META_TAGS = frozenset({
    (0x0002, 0x0000),  # FileMetaInformationGroupLength
    (0x0002, 0x0001),  # FileMetaInformationVersion
    MEDIA_STORAGE_SOP_CLASS_UID_TAG,
    MEDIA_STORAGE_SOP_INSTANCE_UID_TAG,
    TRANSFER_SYNTAX_UID_TAG,
    IMPLEMENTATION_CLASS_UID_TAG,
    (0x0002, 0x0013),  # ImplementationVersionName
})
ZEROED_DICOM_PREAMBLE = b"\x00" * 128
DICOM_READ_DEFER_SIZE = "1 KB"

# Every tag below takes exactly one action: retained, UID-replaced, date/time
# normalised, replaced with the study identifier, or removed. The five sets are
# validated as disjoint below.

# Overwritten with the export's study identifier rather than deleted, so
# downstream tools that key on a patient identifier keep working while the
# value carries no source identity. The writer verifies the written value on
# reread; the audit reports it as a pseudonym rather than a residual removal.
DEFAULT_DEID_PSEUDONYM_TAGS: frozenset[DicomTag] = frozenset({
    (0x0010, 0x0020),  # PatientID [LO]
})

# Retained for reuse: these name the examination and how it was acquired or
# displayed, not the patient, and are populated by the scanner or order rather
# than typed.
DEFAULT_DEID_PRESERVE_TAGS: frozenset[DicomTag] = frozenset({
    (0x0008, 0x1030),  # StudyDescription [LO]
    (0x0008, 0x103E),  # SeriesDescription [LO]
    (0x0018, 0x0010),  # ContrastBolusAgent [LO]
    (0x0018, 0x1030),  # ProtocolName [LO]
    (0x0018, 0x1400),  # AcquisitionDeviceProcessingDescription [LO]
    (0x0018, 0x9424),  # AcquisitionProtocolDescription [LT]
    (0x0028, 0x140E),  # DataPathID [CS]
    (0x0032, 0x1060),  # RequestedProcedureDescription [LO]
    (0x0032, 0x1070),  # RequestedContrastAgent [LO]
    (0x0040, 0x0007),  # ScheduledProcedureStepDescription [LO]
    (0x0040, 0x0254),  # PerformedProcedureStepDescription [LO]
})

DEFAULT_DEID_UID_REMAP_TAGS: frozenset[DicomTag] = frozenset(
    REQUIRED_UID_TAGS
)

# One whole-day study offset shifts these, preserving intervals within the study
# while moving its real calendar position.
DEFAULT_DEID_SHIFTED_DATE_TIME_TAGS: frozenset[DicomTag] = frozenset({
    (0x0008, 0x0012),  # InstanceCreationDate [DA]
    (0x0008, 0x0015),  # InstanceCoercionDateTime [DT]
    (0x0008, 0x0020),  # StudyDate [DA]
    (0x0008, 0x0021),  # SeriesDate [DA]
    (0x0008, 0x0022),  # AcquisitionDate [DA]
    (0x0008, 0x0023),  # ContentDate [DA]
    (0x0008, 0x0024),  # OverlayDate [DA]
    (0x0008, 0x0025),  # CurveDate [DA]
    (0x0008, 0x002A),  # AcquisitionDateTime [DT]
    (0x0018, 0x9516),  # StartAcquisitionDateTime [DT]
    (0x0018, 0x9517),  # EndAcquisitionDateTime [DT]
    (0x0038, 0x0020),  # AdmittingDate [DA]
    (0x0040, 0x0002),  # ScheduledProcedureStepStartDate [DA]
    (0x0040, 0x0004),  # ScheduledProcedureStepEndDate [DA]
    (0x0040, 0x0244),  # PerformedProcedureStepStartDate [DA]
    (0x0040, 0x0250),  # PerformedProcedureStepEndDate [DA]
    (0x0040, 0x4005),  # ScheduledProcedureStepStartDateTime [DT]
    (0x0040, 0x4008),  # ScheduledProcedureStepExpirationDateTime [DT]
    (0x0040, 0x4010),  # ScheduledProcedureStepModificationDateTime [DT]
    (0x0040, 0x4011),  # ExpectedCompletionDateTime [DT]
    (0x0040, 0x4050),  # PerformedProcedureStepStartDateTime [DT]
    (0x0040, 0x4051),  # PerformedProcedureStepEndDateTime [DT]
    (0x0040, 0x4052),  # ProcedureStepCancellationDateTime [DT]
    (0x0040, 0xA192),  # ObservationDateTrial [DA]
})

# Wall-clock times kept for intra-study intervals such as contrast and
# radiopharmaceutical timing. A whole-day offset leaves a TM value unchanged, so
# normalising retains these; each keeps whatever date context it had in the
# source, either its shifted DA partner or the acquisition it belongs to.
DEFAULT_DEID_RETAINED_TIME_TAGS: frozenset[DicomTag] = frozenset({
    (0x0008, 0x0013),  # InstanceCreationTime [TM]
    (0x0008, 0x0030),  # StudyTime [TM]
    (0x0008, 0x0031),  # SeriesTime [TM]
    (0x0008, 0x0032),  # AcquisitionTime [TM]
    (0x0008, 0x0033),  # ContentTime [TM]
    (0x0008, 0x0034),  # OverlayTime [TM]
    (0x0008, 0x0035),  # CurveTime [TM]
    (0x0018, 0x0027),  # InterventionDrugStopTime [TM]
    (0x0018, 0x0035),  # InterventionDrugStartTime [TM]
    (0x0018, 0x1042),  # ContrastBolusStartTime [TM]
    (0x0018, 0x1043),  # ContrastBolusStopTime [TM]
    (0x0018, 0x1072),  # RadiopharmaceuticalStartTime [TM]
    (0x0018, 0x1073),  # RadiopharmaceuticalStopTime [TM]
    (0x0038, 0x0021),  # AdmittingTime [TM]
    (0x0040, 0x0003),  # ScheduledProcedureStepStartTime [TM]
    (0x0040, 0x0005),  # ScheduledProcedureStepEndTime [TM]
    (0x0040, 0x0245),  # PerformedProcedureStepStartTime [TM]
    (0x0040, 0x0251),  # PerformedProcedureStepEndTime [TM]
    (0x0040, 0xA193),  # ObservationTimeTrial [TM]
})

DEFAULT_DEID_DATE_TIME_TAGS: frozenset[DicomTag] = (
    DEFAULT_DEID_SHIFTED_DATE_TIME_TAGS | DEFAULT_DEID_RETAINED_TIME_TAGS
)

# The overlay repeater rules are finite in DICOM: even groups 6000-601E for
# OverlayData and OverlayComments. Expanded here so every policy member has the
# same exact (group, element) representation.
DEFAULT_DEID_OVERLAY_DATA_TAGS = frozenset(
    (group, 0x3000) for group in range(0x6000, 0x6020, 2)
)
DEFAULT_DEID_OVERLAY_COMMENT_TAGS = frozenset(
    (group, 0x4000) for group in range(0x6000, 0x6020, 2)
)

# One mandatory numeric removal policy. Groups only describe what a finding
# exposes, so each tag is grouped by what its value identifies.
DEFAULT_DEID_REMOVE_TAGS_BY_GROUP: Mapping[
    str, frozenset[DicomTag]
] = MappingProxyType({
    "patient": frozenset({
        (0x0010, 0x0010),  # PatientName [PN]
        (0x0010, 0x0021),  # IssuerOfPatientID [LO]
        (0x0010, 0x0024),  # IssuerOfPatientIDQualifiersSequence [SQ]
        (0x0010, 0x0030),  # PatientBirthDate [DA]
        (0x0010, 0x0032),  # PatientBirthTime [TM]
        (0x0010, 0x0040),  # PatientSex [CS]
        (0x0010, 0x0050),  # PatientInsurancePlanCodeSequence [SQ]
        (0x0010, 0x0101),  # PatientPrimaryLanguageCodeSequence [SQ]
        (0x0010, 0x0102),  # PatientPrimaryLanguageModifierCodeSequence [SQ]
        (0x0010, 0x1000),  # OtherPatientIDs [LO]
        (0x0010, 0x1001),  # OtherPatientNames [PN]
        (0x0010, 0x1002),  # OtherPatientIDsSequence [SQ]
        (0x0010, 0x1005),  # PatientBirthName [PN]
        (0x0010, 0x1010),  # PatientAge [AS]
        (0x0010, 0x1020),  # PatientSize [DS]
        (0x0010, 0x1021),  # PatientSizeCodeSequence [SQ]
        (0x0010, 0x1022),  # PatientBodyMassIndex [DS]
        (0x0010, 0x1023),  # MeasuredAPDimension [DS]
        (0x0010, 0x1024),  # MeasuredLateralDimension [DS]
        (0x0010, 0x1030),  # PatientWeight [DS]
        (0x0010, 0x1040),  # PatientAddress [LO]
        (0x0010, 0x1050),  # InsurancePlanIdentification [LO]
        (0x0010, 0x1060),  # PatientMotherBirthName [PN]
        (0x0010, 0x1080),  # MilitaryRank [LO]
        (0x0010, 0x1081),  # BranchOfService [LO]
        (0x0010, 0x1090),  # MedicalRecordLocator [LO]
        (0x0010, 0x1100),  # ReferencedPatientPhotoSequence [SQ]
        (0x0010, 0x2000),  # MedicalAlerts [LO]
        (0x0010, 0x2110),  # Allergies [LO]
        (0x0010, 0x2150),  # CountryOfResidence [LO]
        (0x0010, 0x2152),  # RegionOfResidence [LO]
        (0x0010, 0x2154),  # PatientTelephoneNumbers [SH]
        (0x0010, 0x2155),  # PatientTelecomInformation [LT]
        (0x0010, 0x2160),  # EthnicGroup [SH]
        (0x0010, 0x2161),  # EthnicGroupCodeSequence [SQ]
        (0x0010, 0x2180),  # Occupation [SH]
        (0x0010, 0x21A0),  # SmokingStatus [CS]
        (0x0010, 0x21C0),  # PregnancyStatus [US]
        (0x0010, 0x21D0),  # LastMenstrualDate [DA]
        (0x0010, 0x21F0),  # PatientReligiousPreference [LO]
        (0x0010, 0x2203),  # PatientSexNeutered [CS]
        (0x0038, 0x0050),  # SpecialNeeds [LO]
        (0x0038, 0x0500),  # PatientState [LO]
        (0x0040, 0x0012),  # PreMedication [LO]
        (0x0040, 0x1004),  # PatientTransportArrangements [LO]
    }),
    "personnel": frozenset({
        (0x0008, 0x0090),  # ReferringPhysicianName [PN]
        (0x0008, 0x0092),  # ReferringPhysicianAddress [ST]
        (0x0008, 0x0094),  # ReferringPhysicianTelephoneNumbers [SH]
        (0x0008, 0x0096),  # ReferringPhysicianIdentificationSequence [SQ]
        (0x0008, 0x009C),  # ConsultingPhysicianName [PN]
        (0x0008, 0x009D),  # ConsultingPhysicianIdentificationSequence [SQ]
        (0x0008, 0x1048),  # PhysiciansOfRecord [PN]
        (0x0008, 0x1049),  # PhysiciansOfRecordIdentificationSequence [SQ]
        (0x0008, 0x1050),  # PerformingPhysicianName [PN]
        (0x0008, 0x1052),  # PerformingPhysicianIdentificationSequence [SQ]
        (0x0008, 0x1060),  # NameOfPhysiciansReadingStudy [PN]
        (0x0008, 0x1062),  # PhysiciansReadingStudyIdentificationSequence [SQ]
        (0x0008, 0x1070),  # OperatorsName [PN]
        (0x0008, 0x1072),  # OperatorIdentificationSequence [SQ]
        (0x0010, 0x2297),  # ResponsiblePerson [PN]
        (0x0032, 0x1032),  # RequestingPhysician [PN]
        (0x0040, 0x0006),  # ScheduledPerformingPhysicianName [PN]
        (0x0040, 0x000B),  # ScheduledPerformingPhysicianIdentificationSequence [SQ]
        (0x0040, 0x1010),  # NamesOfIntendedRecipientsOfResults [PN]
        (0x0040, 0x1011),  # IntendedRecipientsOfResultsIdentificationSequence [SQ]
        (0x0040, 0x1101),  # PersonIdentificationCodeSequence [SQ]
        (0x0040, 0x1102),  # PersonAddress [ST]
        (0x0040, 0x1103),  # PersonTelephoneNumbers [LO]
        (0x0040, 0x1104),  # PersonTelecomInformation [LT]
        (0x0040, 0x2008),  # OrderEnteredBy [PN]
        (0x0040, 0x2010),  # OrderCallbackPhoneNumber [SH]
        (0x0040, 0x2011),  # OrderCallbackTelecomInformation [LT]
        (0x0040, 0x4034),  # ScheduledHumanPerformersSequence [SQ]
        (0x0040, 0x4035),  # ActualHumanPerformersSequence [SQ]
        (0x0040, 0x4037),  # HumanPerformerName [PN]
        (0x0040, 0xA073),  # VerifyingObserverSequence [SQ]
        (0x0040, 0xA075),  # VerifyingObserverName [PN]
        (0x0040, 0xA078),  # AuthorObserverSequence [SQ]
        (0x0040, 0xA07A),  # ParticipantSequence [SQ]
        (0x0040, 0xA088),  # VerifyingObserverIdentificationCodeSequence [SQ]
        (0x0040, 0xA123),  # PersonName [PN]
        (0x0040, 0xA307),  # CurrentObserverTrial [PN]
        (0x0040, 0xA352),  # VerbalSourceTrial [PN]
        (0x0040, 0xA353),  # AddressTrial [ST]
        (0x0040, 0xA354),  # TelephoneNumberTrial [LO]
        (0x0040, 0xA358),  # VerbalSourceIdentifierCodeSequenceTrial [SQ]
        (0x0070, 0x0086),  # ContentCreatorIdentificationCodeSequence [SQ]
        (0x0088, 0x0910),  # TopicAuthor [LO]
        (0x300E, 0x0008),  # ReviewerName [PN]
        (0x4008, 0x0102),  # InterpretationRecorder [PN]
        (0x4008, 0x010A),  # InterpretationTranscriber [PN]
        (0x4008, 0x010C),  # InterpretationAuthor [PN]
        (0x4008, 0x0111),  # InterpretationApproverSequence [SQ]
        (0x4008, 0x0114),  # PhysicianApprovingInterpretation [PN]
        (0x4008, 0x0118),  # ResultsDistributionListSequence [SQ]
        (0x4008, 0x0119),  # DistributionName [PN]
        (0x4008, 0x011A),  # DistributionAddress [LO]
    }),
    "institution": frozenset({
        (0x0008, 0x0080),  # InstitutionName [LO]
        (0x0008, 0x0081),  # InstitutionAddress [ST]
        (0x0008, 0x0082),  # InstitutionCodeSequence [SQ]
        (0x0008, 0x0201),  # TimezoneOffsetFromUTC [SH]
        (0x0008, 0x1010),  # StationName [SH]
        (0x0008, 0x1040),  # InstitutionalDepartmentName [LO]
        (0x0008, 0x1041),  # InstitutionalDepartmentTypeCodeSequence [SQ]
        (0x0010, 0x2299),  # ResponsibleOrganization [LO]
        (0x0018, 0x1000),  # DeviceSerialNumber [LO]
        (0x0018, 0x1004),  # PlateID [LO]
        (0x0018, 0x1005),  # GeneratorID [LO]
        (0x0018, 0x1007),  # CassetteID [LO]
        (0x0018, 0x1008),  # GantryID [LO]
        (0x0018, 0x700A),  # DetectorID [SH]
        (0x0020, 0x3401),  # ModifyingDeviceID [CS]
        (0x0032, 0x1020),  # ScheduledStudyLocation [LO]
        (0x0032, 0x1021),  # ScheduledStudyLocationAETitle [AE]
        (0x0032, 0x1033),  # RequestingService [LO]
        (0x0038, 0x001E),  # ScheduledPatientInstitutionResidence [LO]
        (0x0038, 0x0300),  # CurrentPatientLocation [LO]
        (0x0038, 0x0400),  # PatientInstitutionResidence [LO]
        (0x0040, 0x0001),  # ScheduledStationAETitle [AE]
        (0x0040, 0x0010),  # ScheduledStationName [SH]
        (0x0040, 0x0011),  # ScheduledProcedureStepLocation [SH]
        (0x0040, 0x0241),  # PerformedStationAETitle [AE]
        (0x0040, 0x0242),  # PerformedStationName [SH]
        (0x0040, 0x0243),  # PerformedLocation [SH]
        (0x0040, 0x1005),  # RequestedProcedureLocation [LO]
        (0x0040, 0x2009),  # OrderEntererLocation [SH]
        (0x0040, 0x4025),  # ScheduledStationNameCodeSequence [SQ]
        (0x0040, 0x4027),  # ScheduledStationGeographicLocationCodeSequence [SQ]
        (0x0040, 0x4030),  # PerformedStationGeographicLocationCodeSequence [SQ]
        (0x0040, 0x4036),  # HumanPerformerOrganization [LO]
        (0x0040, 0xA027),  # VerifyingOrganization [LO]
        (0x0040, 0xA07C),  # CustodialOrganizationSequence [SQ]
        (0x3008, 0x0105),  # SourceSerialNumber [LO]
    }),
    "workflow_ids": frozenset({
        (0x0008, 0x0050),  # AccessionNumber [SH]
        (0x0020, 0x0010),  # StudyID [SH]
        (0x0032, 0x0012),  # StudyIDIssuer [LO]
        (0x0038, 0x0010),  # AdmissionID [LO]
        (0x0038, 0x0011),  # IssuerOfAdmissionID [LO]
        (0x0038, 0x0060),  # ServiceEpisodeID [LO]
        (0x0038, 0x0061),  # IssuerOfServiceEpisodeID [LO]
        (0x0040, 0x0009),  # ScheduledProcedureStepID [SH]
        (0x0040, 0x0253),  # PerformedProcedureStepID [SH]
        (0x0040, 0x1001),  # RequestedProcedureID [SH]
        (0x0040, 0x2016),  # PlacerOrderNumberImagingServiceRequest [LO]
        (0x0040, 0x2017),  # FillerOrderNumberImagingServiceRequest [LO]
        (0x4008, 0x0042),  # ResultsIDIssuer [LO]
        (0x4008, 0x0202),  # InterpretationIDIssuer [LO]
    }),
    "free_text": frozenset({
        (0x0008, 0x1080),  # AdmittingDiagnosesDescription [LO]
        (0x0008, 0x2111),  # DerivationDescription [ST]
        (0x0008, 0x4000),  # IdentifyingComments [LT]
        (0x0010, 0x21B0),  # AdditionalPatientHistory [LT]
        (0x0010, 0x4000),  # PatientComments [LT]
        (0x0018, 0x4000),  # AcquisitionComments [LT]
        (0x0018, 0xA003),  # ContributionDescription [ST]
        (0x0020, 0x3406),  # ModifiedImageDescription [LO]
        (0x0020, 0x4000),  # ImageComments [LT]
        (0x0020, 0x9158),  # FrameComments [LT]
        (0x0028, 0x4000),  # ImagePresentationComments [LT]
        (0x0032, 0x1030),  # ReasonForStudy [LO]
        (0x0032, 0x4000),  # StudyComments [LT]
        (0x0038, 0x0040),  # DischargeDiagnosisDescription [LO]
        (0x0038, 0x0062),  # ServiceEpisodeDescription [LO]
        (0x0038, 0x4000),  # VisitComments [LT]
        (0x0040, 0x0280),  # CommentsOnThePerformedProcedureStep [ST]
        (0x0040, 0x0310),  # CommentsOnRadiationDose [ST]
        (0x0040, 0x1400),  # RequestedProcedureComments [LT]
        (0x0040, 0x2001),  # ReasonForTheImagingServiceRequest [LO]
        (0x0040, 0x2400),  # ImagingServiceRequestComments [LT]
        (0x0040, 0x3001),  # ConfidentialityConstraintOnPatientDataDescription [LO]
        (0x0042, 0x0010),  # DocumentTitle [ST]
        (0x0088, 0x0904),  # TopicTitle [LO]
        (0x0088, 0x0906),  # TopicSubject [ST]
        (0x0088, 0x0912),  # TopicKeywords [LO]
        (0x2030, 0x0020),  # TextString [LO]
        (0x300C, 0x0113),  # ReasonForOmissionDescription [LO]
        (0x4000, 0x0010),  # Arbitrary [LT]
        (0x4000, 0x4000),  # TextComments [LT]
        (0x4008, 0x010B),  # InterpretationText [ST]
        (0x4008, 0x0115),  # InterpretationDiagnosisDescription [LT]
        (0x4008, 0x0300),  # Impressions [ST]
        (0x4008, 0x4000),  # ResultsComments [ST]
    }) | DEFAULT_DEID_OVERLAY_COMMENT_TAGS,
    "embedded_content": frozenset({
        (0x0008, 0x1084),  # AdmittingDiagnosesCodeSequence [SQ]
        (0x0008, 0x1110),  # ReferencedStudySequence [SQ]
        (0x0008, 0x1111),  # ReferencedPerformedProcedureStepSequence [SQ]
        (0x0008, 0x1120),  # ReferencedPatientSequence [SQ]
        (0x0008, 0x1140),  # ReferencedImageSequence [SQ]
        (0x0008, 0x2112),  # SourceImageSequence [SQ]
        (0x0040, 0x0275),  # RequestAttributesSequence [SQ]
        (0x0040, 0x0555),  # AcquisitionContextSequence [SQ]
        (0x0040, 0xA730),  # ContentSequence [SQ]
        (0x0042, 0x0011),  # EncapsulatedDocument [OB]
        (0x0070, 0x0001),  # GraphicAnnotationSequence [SQ]
        (0x0088, 0x0200),  # IconImageSequence [SQ]
        (0x0400, 0x0100),  # DigitalSignatureUID [UI]
        (0x0400, 0x0402),  # ReferencedDigitalSignatureSequence [SQ]
        (0x0400, 0x0403),  # ReferencedSOPInstanceMACSequence [SQ]
        (0x0400, 0x0404),  # MAC [OB]
        (0x0400, 0x0550),  # ModifiedAttributesSequence [SQ]
        (0x0400, 0x0561),  # OriginalAttributesSequence [SQ]
        (0xFFFA, 0xFFFA),  # DigitalSignaturesSequence [SQ]
        (0xFFFC, 0xFFFC),  # DataSetTrailingPadding [OB]
    }) | DEFAULT_DEID_OVERLAY_DATA_TAGS,
})

# The flat writer blacklist is derived from the grouped source of truth.
DEFAULT_DEID_REMOVE_TAGS: frozenset[DicomTag] = frozenset().union(
    *DEFAULT_DEID_REMOVE_TAGS_BY_GROUP.values()
)
DEFAULT_DEID_REMOVE_GROUP_BY_TAG: Mapping[DicomTag, str] = (
    MappingProxyType({
        tag: group
        for group, tags in DEFAULT_DEID_REMOVE_TAGS_BY_GROUP.items()
        for tag in tags
    })
)
if sum(len(tags) for tags in DEFAULT_DEID_REMOVE_TAGS_BY_GROUP.values()) != len(
    DEFAULT_DEID_REMOVE_TAGS
):
    raise RuntimeError("De-identification removal groups must be disjoint")
_DEID_ACTION_SETS = (
    DEFAULT_DEID_PRESERVE_TAGS,
    DEFAULT_DEID_UID_REMAP_TAGS,
    DEFAULT_DEID_DATE_TIME_TAGS,
    DEFAULT_DEID_PSEUDONYM_TAGS,
    DEFAULT_DEID_REMOVE_TAGS,
)
if sum(len(tags) for tags in _DEID_ACTION_SETS) != len(
    frozenset().union(*_DEID_ACTION_SETS)
):
    raise RuntimeError("De-identification exact-tag actions must be disjoint")
DEFAULT_DEID_EFFECTIVE_CONCRETE_TAG_COUNT = len(
    frozenset().union(*_DEID_ACTION_SETS)
)

def default_deid_remove_group(tag: DicomTag) -> str | None:
    """Return the canonical removal-reporting group for a DICOM tag."""
    return DEFAULT_DEID_REMOVE_GROUP_BY_TAG.get(tag)

# Tags whose values the audit inspects. All are removed by policy above; these
# name where a value-pattern detector looks, not a second blacklist.
DEFAULT_DEID_ACCESSION_NUMBER_TAG: DicomTag = (0x0008, 0x0050)
DEFAULT_DEID_ACCESSION_ECHO_TAGS: tuple[DicomTag, ...] = (
    (0x0020, 0x0010),  # StudyID
    (0x0040, 0x0009),  # ScheduledProcedureStepID
    (0x0040, 0x1001),  # RequestedProcedureID
    (0x0040, 0x0253),  # PerformedProcedureStepID
)

DEFAULT_DEID_NHS_IDENTIFIER_TAGS: tuple[DicomTag, ...] = (
    (0x0010, 0x0020),  # PatientID
    (0x0010, 0x1000),  # OtherPatientIDs
)
