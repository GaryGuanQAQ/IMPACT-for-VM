from __future__ import annotations

from typing import Any, Dict, Iterable, Set

import pydicom
from pydicom.dataelem import RawDataElement
from pydicom.datadict import dictionary_VR

from deidentify.settings import DicomTag

# Type 2 elements stay present with a VR-compatible empty value.
_TEXT_VRS = {
    "AE", "AS", "CS", "DA", "DS", "DT", "IS", "LO", "LT", "PN", "SH", "ST", "TM", "UC", "UI", "UR", "UT",
}


def _canonical_report_tag(value: Any) -> DicomTag:
    """Validate a machine-readable audit tag without coercing other formats."""
    if (
        not isinstance(value, (tuple, list))
        or len(value) != 2
        or any(
            not isinstance(component, int) or isinstance(component, bool)
            for component in value
        )
        or any(component < 0 or component > 0xFFFF for component in value)
    ):
        raise ValueError(
            "audit tag fields must contain two-component integer DICOM tags"
        )
    return value[0], value[1]


def _tag_vr(group: int, element: int) -> str:
    """The dictionary VR for a public tag, or "" if unknown (e.g. a private tag)."""
    try:
        return dictionary_VR((group, element))
    except KeyError:
        return ""


def flagged_tags(
    audit: Dict[str, Any],
    strip_private_tag_text: bool = True,
    exclude_vrs: Iterable[str] = (),
) -> Set[DicomTag]:
    """Read canonical numeric transformation fields from an audit result."""
    required_fields = ["actionable_tags"]
    if strip_private_tag_text:
        required_fields.extend(("private_text_tags", "uninspected_private_tags"))

    tags: Set[DicomTag] = set()
    for field in required_fields:
        if field not in audit or not isinstance(audit[field], (list, tuple)):
            raise ValueError(f"audit result is missing canonical {field!r} tags")
        tags.update(_canonical_report_tag(tag) for tag in audit[field])

    exclude_vrs = set(exclude_vrs)
    if exclude_vrs:
        tags = {(g, e) for (g, e) in tags if _tag_vr(g, e) not in exclude_vrs}
    return tags


def _element_vr(ds: pydicom.dataset.Dataset, tag) -> str:
    elem = ds.get_item(tag, keep_deferred=True)
    if isinstance(elem, RawDataElement):
        if elem.VR is not None:
            return elem.VR
        try:
            return dictionary_VR(tag)
        except KeyError:
            return ""
    return elem.VR if elem is not None else ""


def strip_dataset_tags(
    ds: pydicom.dataset.Dataset,
    tags: Iterable[DicomTag],
) -> None:
    """Blank each configured tag recursively, preserving the element itself."""
    tags = set(tags)
    for tag in list(ds.keys()):
        tag_tuple = (tag.group, tag.element)
        if tag_tuple in tags:
            elem = ds[tag]
            elem.value = "" if elem.VR in _TEXT_VRS else None
            continue
        if _element_vr(ds, tag) == "SQ":
            for item in ds[tag].value or ():
                strip_dataset_tags(item, tags)


def remove_dataset_tags(
    ds: pydicom.dataset.Dataset,
    tags: Iterable[DicomTag],
) -> None:
    """Delete each configured tag recursively from a dataset in place."""
    tags = set(tags)
    for tag in list(ds.keys()):
        tag_tuple = (tag.group, tag.element)
        if tag_tuple in tags:
            del ds[tag]
            continue
        if _element_vr(ds, tag) == "SQ":
            for item in ds[tag].value or ():
                remove_dataset_tags(item, tags)
