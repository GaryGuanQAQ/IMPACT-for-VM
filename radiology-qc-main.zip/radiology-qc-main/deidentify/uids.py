from __future__ import annotations

import secrets
from types import MappingProxyType
from typing import Dict, Mapping

from pydicom.uid import UID

from deidentify.settings import (
    CANONICAL_DICOM_UID_RE,
    DicomTag,
    FORCE_REMAP_UID_TAGS,
    MAX_DICOM_UID_LENGTH,
    PRIMARY_IDENTITY_UID_TAGS,
    PROTECTED_UID_TAGS,
    UID_GENERATION_ATTEMPTS as UID_GENERATION_ATTEMPTS,
    UID_ROOT as UID_ROOT,
    UID_TRUNCATED_BITS as UID_TRUNCATED_BITS,
)


class UIDCollisionError(RuntimeError):
    """Raised when two source UIDs would share one remapped UID."""


def is_protected_semantic_uid(tag: DicomTag, uid: str) -> bool:
    """Whether a UID value conveys protocol semantics rather than identity."""
    if tag in PROTECTED_UID_TAGS:
        return True
    # The pydicom registry includes SOP classes, transfer syntaxes, coding
    # schemes, well-known instances/frames, and other DICOM constants.
    return bool(UID(uid).type)


def uid_requires_remapping(tag: DicomTag, uid: str) -> bool:
    """Whether a UID value still carries source identity and must be remapped.

    Shared by the writer and the audit so a UID the writer rewrites is exactly
    the UID the audit reports.
    """
    if tag in PRIMARY_IDENTITY_UID_TAGS or tag in FORCE_REMAP_UID_TAGS:
        return True
    return not is_protected_semantic_uid(tag, uid)


def is_pseudonymous_uid(uid: str) -> bool:
    """Whether a UID sits under this project's remapping root.

    The only in-band signal that a value has already been remapped.
    """
    return uid.startswith(f"{UID_ROOT}.")


def validate_canonical_uid(uid: str, *, name: str = "uid") -> None:
    """Reject non-canonical DICOM UID values before preserving or remapping."""
    if not isinstance(uid, str):
        raise TypeError(f"{name} must be a string")
    if (
        not uid
        or len(uid) > MAX_DICOM_UID_LENGTH
        or CANONICAL_DICOM_UID_RE.fullmatch(uid) is None
    ):
        raise ValueError(
            f"{name} must be a non-empty canonical DICOM UID of at most "
            f"{MAX_DICOM_UID_LENGTH} characters"
        )


class RandomUIDRemapper:
    """Map canonical DICOM UIDs to fresh random ``2.25`` UIDs.

    The association is recorded rather than recomputable: nothing in the output
    is derived from the source UID, so relinking requires the exported mapping
    and no key exists to be guarded or destroyed. A source UID seen twice within
    a run maps to one replacement; the same UID in a later run does not.
    """

    __slots__ = ("_forward", "_reverse", "_mapping_view")

    def __init__(self) -> None:
        self._forward: Dict[str, str] = {}
        self._reverse: Dict[str, str] = {}
        self._mapping_view: Mapping[str, str] = MappingProxyType(self._forward)

    def __repr__(self) -> str:
        return f"{type(self).__name__}(count={self.count})"

    @property
    def mapping(self) -> Mapping[str, str]:
        """A live, read-only view of source-to-remapped UIDs."""
        return self._mapping_view

    @property
    def count(self) -> int:
        """Number of distinct source UIDs remapped by this instance."""
        return len(self._forward)

    def remap(self, original_uid: str) -> str:
        """Return this run's replacement for ``original_uid`` and record it."""
        validate_canonical_uid(original_uid, name="original_uid")

        cached = self._forward.get(original_uid)
        if cached is not None:
            return cached
        if original_uid in self._reverse:
            raise UIDCollisionError(
                "UID source/output namespace collision detected"
            )

        # A repeat is a ~2^-128 event; retry rather than abort an export, but
        # still fail closed if the entropy source is somehow degenerate.
        for _ in range(UID_GENERATION_ATTEMPTS):
            value = secrets.randbits(UID_TRUNCATED_BITS)
            remapped_uid = f"{UID_ROOT}.{value}"
            validate_canonical_uid(remapped_uid, name="remapped_uid")
            if (
                remapped_uid == original_uid
                or remapped_uid in self._forward
                or remapped_uid in self._reverse
            ):
                continue
            self._forward[original_uid] = remapped_uid
            self._reverse[remapped_uid] = original_uid
            return remapped_uid

        raise UIDCollisionError(
            f"No unused UID generated in {UID_GENERATION_ATTEMPTS} attempts"
        )
