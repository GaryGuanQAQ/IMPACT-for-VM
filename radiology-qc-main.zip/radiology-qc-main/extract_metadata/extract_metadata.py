from __future__ import annotations

import base64
import json
import logging
import os
import re
import sys
from collections import defaultdict
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pydicom

logger = logging.getLogger(__name__)

DEFAULT_FILE_PATTERNS: Tuple[str, ...] = ("*.dcm", "*.DCM")
DEFAULT_OUTPUT_FILENAME = "dicom_metadata.json"

_EXCLUDED_VRS = {"SQ", "OB", "OW", "OF", "OD", "UN"}
PRIVATE_TAG_COUNT_KEY = "_private_tag_count"
_PRIVATE_KEY_RE = re.compile(r"^\((?P<group>[0-9a-f]{4}),(?P<element>[0-9a-f]{4})\)$")
_MISSING = object()


def private_tag_key(group: int, element: int) -> str:
    """The dict key `_flatten_tags` gives a private element, e.g. "(0029,1010)"."""
    return f"({group:04x},{element:04x})"


def parse_private_tag_key(key: str) -> Optional[Tuple[int, int]]:
    """Return (group, element) if `key` is a private-tag key from `_flatten_tags`, else None."""
    m = _PRIVATE_KEY_RE.match(key)
    if not m:
        return None
    return int(m.group("group"), 16), int(m.group("element"), 16)


def discover_dicom_files(root: Path) -> List[Path]:
    """Recursively find DICOM files under `root`."""
    files: List[Path] = []
    for pattern in DEFAULT_FILE_PATTERNS:
        files.extend(root.rglob(pattern))
    return sorted(set(files))


def _json_safe(value: Any) -> Any:
    """Convert a pydicom value to a plain JSON-compatible type."""
    if isinstance(value, pydicom.multival.MultiValue):
        return [_json_safe(v) for v in value]
    if isinstance(value, pydicom.valuerep.PersonName):
        return str(value)
    if isinstance(value, pydicom.valuerep.IS):
        return int(value)
    if isinstance(value, (pydicom.valuerep.DSfloat, Decimal)):
        return float(value)
    if isinstance(value, pydicom.uid.UID):
        return str(value)
    if isinstance(value, bytes):
        return None
    return value


def _private_value_safe(raw: Any) -> Any:
    """Keep decoded values and base64-encode private bytes."""
    if isinstance(raw, bytes):
        return {"base64": base64.b64encode(raw).decode("ascii")}
    return _json_safe(raw)


def _flatten_tags(ds: pydicom.dataset.Dataset) -> Dict[str, Any]:
    """Flatten top-level, non-sequence header elements."""
    tags: Dict[str, Any] = {}
    private_count = 0
    for elem in ds:
        if elem.tag == 0x7FE00010:
            continue
        if elem.tag.is_private:
            private_count += 1
            if elem.VR == "SQ":
                continue
            key = private_tag_key(elem.tag.group, elem.tag.element)
            try:
                tags[key] = {"vr": elem.VR, "value": _private_value_safe(elem.value)}
            except Exception as e:
                logger.debug("Skipping unreadable private tag %s: %s", key, e)
            continue
        if elem.VR in _EXCLUDED_VRS:
            continue
        if not elem.keyword:
            continue
        tags[elem.keyword] = _json_safe(elem.value)
    tags[PRIVATE_TAG_COUNT_KEY] = private_count
    return tags


def _all_equal(values: List[Any]) -> bool:
    first = values[0]
    return all(v == first for v in values[1:])


def _bucket_tags(
    per_series_instance_tags: Dict[str, Dict[str, Dict[str, Any]]]
) -> Tuple[Dict[str, Any], Dict[str, Dict[str, Any]], Dict[str, Dict[str, Dict[str, Any]]]]:
    """Move each tag to its coarsest shared scope."""
    all_keys = {
        key
        for series in per_series_instance_tags.values()
        for tags in series.values()
        for key in tags
    }
    flat_instances = [tags for series in per_series_instance_tags.values() for tags in series.values()]

    study_tags: Dict[str, Any] = {}
    series_tags: Dict[str, Dict[str, Any]] = {s: {} for s in per_series_instance_tags}
    instance_tags: Dict[str, Dict[str, Dict[str, Any]]] = {
        s: {i: {} for i in insts} for s, insts in per_series_instance_tags.items()
    }

    for key in sorted(all_keys):
        study_values = [tags.get(key, _MISSING) for tags in flat_instances]
        if _MISSING not in study_values and _all_equal(study_values):
            study_tags[key] = study_values[0]
            continue

        for series_uid, insts in per_series_instance_tags.items():
            series_values = [tags.get(key, _MISSING) for tags in insts.values()]
            if _MISSING not in series_values and _all_equal(series_values):
                series_tags[series_uid][key] = series_values[0]
            else:
                for sop_uid, tags in insts.items():
                    if key in tags:
                        instance_tags[series_uid][sop_uid][key] = tags[key]

    return study_tags, series_tags, instance_tags


def extract_study_metadata(
    study_instance_uid: str, entries: List[Tuple[Path, pydicom.dataset.Dataset]]
) -> Dict[str, Any]:
    """Build the tiered metadata dict for one study from its (file_path, header) instance entries."""
    per_series_files: Dict[str, Dict[str, Path]] = defaultdict(dict)
    per_series_tags: Dict[str, Dict[str, Dict[str, Any]]] = defaultdict(dict)

    for path, ds in entries:
        series_uid = str(getattr(ds, "SeriesInstanceUID", "UNKNOWN_SERIES"))
        sop_uid = str(getattr(ds, "SOPInstanceUID", path.name))
        per_series_files[series_uid][sop_uid] = path
        per_series_tags[series_uid][sop_uid] = _flatten_tags(ds)

    study_tags, series_tags, instance_tags = _bucket_tags(per_series_tags)

    series_out: Dict[str, Any] = {}
    for series_uid, instances in instance_tags.items():
        series_out[series_uid] = {
            "tags": series_tags[series_uid],
            "instances": {
                sop_uid: {
                    "file_path": str(per_series_files[series_uid][sop_uid]),
                    "tags": tags,
                }
                for sop_uid, tags in instances.items()
            },
        }

    return {"study_instance_uid": study_instance_uid, "tags": study_tags, "series": series_out}


def group_by_study(
    files: List[Path],
    stop_before_pixels: bool = True,
    defer_size: Optional[str] = None,
) -> Dict[str, List[Tuple[Path, pydicom.dataset.Dataset]]]:
    """Parse every file and group by StudyInstanceUID.

    Metadata extraction uses the header-only default. Callers that must inspect
    elements serialized after Pixel Data can disable ``stop_before_pixels`` and
    defer large values.
    """
    studies: Dict[str, List[Tuple[Path, pydicom.dataset.Dataset]]] = defaultdict(list)
    for path in files:
        try:
            ds = pydicom.dcmread(
                path,
                stop_before_pixels=stop_before_pixels,
                defer_size=defer_size,
            )
        except Exception as e:
            logger.warning("Failed to parse DICOM %s: %s", path, e)
            continue
        uid = str(getattr(ds, "StudyInstanceUID", "UNKNOWN_STUDY"))
        studies[uid].append((path, ds))
    return studies


def study_directory(entries: List[Tuple[Path, pydicom.dataset.Dataset]]) -> Path:
    """The common parent directory of every file in a study."""
    return Path(os.path.commonpath([str(p.parent) for p, _ in entries]))


def write_study_metadata(
    study_instance_uid: str,
    entries: List[Tuple[Path, pydicom.dataset.Dataset]],
    output_directory: Optional[Path] = None,
    output_filename: str = DEFAULT_OUTPUT_FILENAME,
) -> Path:
    """Write one study's tiered metadata JSON."""
    metadata = extract_study_metadata(study_instance_uid, entries)
    destination_dir = output_directory or study_directory(entries)
    destination_dir.mkdir(parents=True, exist_ok=True)
    destination = destination_dir / output_filename
    with open(destination, "w") as f:
        json.dump(metadata, f, indent=2)
    logger.info("Wrote %s (%d series)", destination, len(metadata["series"]))
    return destination


def load_metadata_file(path: Path) -> Dict[str, Any]:
    """Load a previously-written tiered metadata JSON file."""
    with open(path, "r") as f:
        return json.load(f)


def find_metadata_file(directory: Path, filename: str = DEFAULT_OUTPUT_FILENAME) -> Optional[Path]:
    """Locate a metadata file in `directory`, or None if it isn't there."""
    candidate = Path(directory) / filename
    return candidate if candidate.is_file() else None


def find_metadata_files(
    directory: Path, filename: str = DEFAULT_OUTPUT_FILENAME
) -> List[Path]:
    """Every metadata file in `directory`.

    A directory holding more than one study has one file per study: `filename`
    plus the UID-qualified siblings `write_study_metadata` falls back to.
    """
    directory = Path(directory)
    stem, suffix = os.path.splitext(filename)
    candidates = [directory / filename, *sorted(directory.glob(f"{stem}_*{suffix}"))]
    return [c for c in candidates if c.is_file()]


def iter_instances(metadata: Dict[str, Any]):
    """Yield every (sop_uid, instance dict) in a loaded metadata file."""
    for series in metadata.get("series", {}).values():
        yield from series.get("instances", {}).items()


def metadata_file_for_instance(
    instance_path: Path, filename: str = DEFAULT_OUTPUT_FILENAME
) -> Optional[Path]:
    """The metadata file describing `instance_path`, or None if no file lists it.

    Resolves the ambiguity of a directory holding several studies, where the
    instance belongs to only one of them.
    """
    instance_path = Path(instance_path)
    target = instance_path.resolve()
    for candidate in find_metadata_files(instance_path.parent, filename):
        try:
            metadata = load_metadata_file(candidate)
        except Exception as e:
            logger.warning("Skipping unreadable metadata file %s: %s", candidate, e)
            continue
        for _, instance in iter_instances(metadata):
            if Path(instance.get("file_path", "")).resolve() == target:
                return candidate
    return None


def main(config_path: Path) -> None:
    """Extract tiered DICOM metadata for every study found under `input_directory`."""
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
    except FileNotFoundError:
        logger.error(f"Config not found: {config_path}")
        return
    except Exception as e:
        logger.error(f"Config error: {e}")
        return

    input_dir = config.get("input_directory") or config.get("root_directory")
    if not input_dir:
        logger.error(
            f"Set 'input_directory' in {config_path} "
            "(the DICOM scan root; may contain multiple studies).")
        return

    output_dir = config.get("output_directory")
    output_root = Path(output_dir) if output_dir else None
    output_filename = config.get("output_filename", DEFAULT_OUTPUT_FILENAME)

    root_path = Path(input_dir)
    files = discover_dicom_files(root_path)
    if not files:
        logger.error(f"No DICOM files found under {root_path}")
        return

    logger.info(f"Grouping {len(files)} files into studies...")
    studies = group_by_study(files)

    logger.info(f"Found {len(studies)} studies; writing one metadata file each.")
    written: set = set()
    for study_uid, entries in studies.items():
        study_dir = study_directory(entries)
        destination = None
        if output_root is not None:
            # Mirror input paths to avoid output filename collisions.
            try:
                relative = study_dir.relative_to(root_path)
            except ValueError:
                relative = Path(study_dir.name)
            destination = output_root / relative
        filename = output_filename
        if (destination or study_dir) / filename in written:
            # Two studies share a directory; keep both by qualifying with the UID.
            stem, suffix = os.path.splitext(output_filename)
            filename = f"{stem}_{study_uid}{suffix}"
        written.add((destination or study_dir) / filename)
        write_study_metadata(study_uid, entries, destination, filename)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    config_arg = (Path(sys.argv[1]) if len(sys.argv) > 1
                  else Path(__file__).resolve().parent / "config.json")
    main(config_arg)
