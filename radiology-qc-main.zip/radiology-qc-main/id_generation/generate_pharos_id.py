from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Iterable, Optional, Tuple, Union

import pydicom

from extract_metadata.extract_metadata import (
    DEFAULT_OUTPUT_FILENAME,
    find_metadata_files,
    load_metadata_file,
    metadata_file_for_instance,
)
from id_generation.hash import generate_hash_segment

PROJECT_ID = "PH"
HASH_LENGTH = 8

DicomSource = Union[Path, str, pydicom.dataset.Dataset]

# The two forms `study_identifier` emits. Anything else in a pseudonym tag is a
# residual identifier, not something this pipeline wrote.
_COMPONENT = r"[A-Za-z0-9][A-Za-z0-9-]*"
_HASH = f"[0-9A-F]{{{HASH_LENGTH}}}"
PHAROS_ID_RE = re.compile(
    rf"{PROJECT_ID}_{_COMPONENT}_{_COMPONENT}_{_COMPONENT}_IM[A-Z0-9]+_{_HASH}\Z"
)
HASH_SEGMENT_RE = re.compile(rf"{_HASH}\Z")


def identifier_form(value: object) -> Optional[str]:
    """Which identifier form `value` is: 'pharos_id', 'hash_segment', or None.

    The bare hash is a far weaker assertion than a full PharosID — eight hex
    characters is a shape plenty of real hospital numbers share — so callers
    that care about the distinction get it rather than a bare boolean.
    """
    if not isinstance(value, str):
        return None
    if PHAROS_ID_RE.fullmatch(value):
        return "pharos_id"
    if HASH_SEGMENT_RE.fullmatch(value):
        return "hash_segment"
    return None


def instance_pixel_digest(ds: pydicom.dataset.Dataset) -> Optional[str]:
    """SHA-256 of one instance's Pixel Data, or None if it carries none.

    Hashes the stored bytes rather than a decoded array, so the value is
    unchanged by anything that leaves Pixel Data untouched.
    """
    pixel_data = ds.get("PixelData")
    if not pixel_data:
        return None
    return hashlib.sha256(pixel_data).hexdigest()


def study_pixel_digest(datasets: Iterable[pydicom.dataset.Dataset]) -> str:
    """Digest a study's pixel content, independent of instance ordering.

    Per-instance digests are sorted before combining, so file traversal order
    and any UID remapping that would reorder instances cannot change the
    result. It is derived from the full pixel content of every instance, so it
    does change if the study's composition changes.
    """
    digests = sorted(
        digest
        for digest in (instance_pixel_digest(ds) for ds in datasets)
        if digest is not None
    )
    if not digests:
        raise ValueError(
            "Cannot derive a pixel digest: no instance in this study carries "
            "Pixel Data"
        )
    return hashlib.sha256("|".join(digests).encode("utf-8")).hexdigest()


def study_hash_segment(modality: str, hash_source: str) -> str:
    """The PharosID's trailing hash, computed the same way with or without a
    participant.

    The participant ID is deliberately *not* part of the payload: it already
    appears verbatim in the assembled PharosID, so including it would add no
    uniqueness while making this segment change depending on whether a
    participant map happened to be configured.
    """
    return generate_hash_segment(
        str(modality).strip().upper(), hash_source, length=HASH_LENGTH
    )


def pharos_id_from_components(
    participant_id: str,
    centre: str,
    tissue_source_site: str,
    modality: str,
    hash_source: str,
) -> str:
    """Assemble a full PharosID from a resolved modality and hash input."""
    modality = str(modality).strip().upper()
    return "_".join(
        [
            PROJECT_ID,
            centre,
            participant_id,
            tissue_source_site,
            f"IM{modality}",
            study_hash_segment(modality, hash_source),
        ]
    )


def study_identifier(
    modality: str,
    hash_source: str,
    participant_id: Optional[str] = None,
    centre: Optional[str] = None,
    tissue_source_site: Optional[str] = None,
) -> str:
    """The identifier naming one study's export.

    A full PharosID when the participant, centre and tissue source site are all
    known; otherwise the hash segment alone, which is the same value the full ID
    would have ended with. An unattributed export is therefore renameable to its
    PharosID later without recomputing anything.
    """
    if participant_id and centre and tissue_source_site:
        return pharos_id_from_components(
            participant_id, centre, tissue_source_site, modality, hash_source
        )
    return study_hash_segment(modality, hash_source)


def _modality_and_study_uid_from_metadata_file(metadata_path: Path) -> Tuple[str, str]:
    metadata = load_metadata_file(metadata_path)
    study_uid = metadata.get("study_instance_uid")
    modality = metadata.get("tags", {}).get("Modality")

    if not study_uid:
        raise ValueError(f"{metadata_path} has no study_instance_uid")
    if not modality:
        raise ValueError(
            f"{metadata_path} has no study-level Modality - it likely varies by series "
            "(a multi-modality study); pass a DICOM source for that series instead"
        )
    return str(modality).strip().upper(), str(study_uid).strip()


def extract_modality_and_study_uid(
    dicom_source: DicomSource,
    use_extracted_metadata: bool = False,
    metadata_filename: str = DEFAULT_OUTPUT_FILENAME,
) -> Tuple[str, str]:
    """Read Modality and StudyInstanceUID from DICOM or its metadata cache."""
    if use_extracted_metadata and not isinstance(dicom_source, pydicom.dataset.Dataset):
        source_path = Path(dicom_source)
        if source_path.is_file():
            # A directory can hold several studies, so match the file to its own
            # metadata rather than to whichever study wrote the unqualified name.
            metadata_path = metadata_file_for_instance(source_path, metadata_filename)
        else:
            candidates = find_metadata_files(source_path, metadata_filename)
            if len(candidates) > 1:
                raise ValueError(
                    f"{source_path} holds {len(candidates)} studies; pass a DICOM "
                    "file path rather than a directory to select one"
                )
            metadata_path = candidates[0] if candidates else None
        if metadata_path is not None:
            return _modality_and_study_uid_from_metadata_file(metadata_path)

    if isinstance(dicom_source, pydicom.dataset.Dataset):
        ds = dicom_source
    else:
        ds = pydicom.dcmread(dicom_source, stop_before_pixels=True)

    modality = getattr(ds, "Modality", None)
    study_uid = getattr(ds, "StudyInstanceUID", None)

    if not modality:
        raise ValueError("DICOM metadata is missing Modality")
    if not study_uid:
        raise ValueError("DICOM metadata is missing StudyInstanceUID")

    return str(modality).strip().upper(), str(study_uid).strip()


def generate_pharos_id(
    participant_id: str,
    centre: str,
    tissue_source_site: str,
    dicom_source: DicomSource,
    use_extracted_metadata: bool = False,
    metadata_filename: str = DEFAULT_OUTPUT_FILENAME,
) -> str:
    """Build a medical-image PharosID for a study."""
    modality, study_uid = extract_modality_and_study_uid(
        dicom_source,
        use_extracted_metadata=use_extracted_metadata,
        metadata_filename=metadata_filename,
    )
    return pharos_id_from_components(
        participant_id, centre, tissue_source_site, modality, study_uid
    )
