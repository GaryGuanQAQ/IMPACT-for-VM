import hashlib


def generate_hash_segment(*components: str, length: int = 8) -> str:
    """Return an uppercase SHA-256 fragment for delimited components."""
    if not components:
        raise ValueError("At least one component is required to compute a hash segment")

    payload = "|".join(str(c) for c in components).encode("utf-8")
    digest = hashlib.sha256(payload).hexdigest().upper()
    return digest[:length]
