#!/usr/bin/env bash
# Export the published model image for an air-gapped environment.
# Examples:
#   ./jobs/export_model_image.sh
#   TOTALSEG_FORMAT=both ./jobs/export_model_image.sh
#   TOTALSEG_SOURCE_IMAGE=ghcr.io/pharoskcl/totalsegmentator_2-15-0@sha256:... \
#     ./jobs/export_model_image.sh

set -euo pipefail

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
  sed -n '2,10p' "$0"
  exit 0
fi
if [[ $# -gt 0 ]]; then
  echo "ERROR: this script takes no positional arguments (use environment variables)" >&2
  exit 1
fi

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="${TOTALSEG_EXPORT_DIR:-$REPO_DIR/images}"
SOURCE_IMAGE="${TOTALSEG_SOURCE_IMAGE:-ghcr.io/pharoskcl/totalsegmentator_2-15-0:latest}"
FORMAT="${TOTALSEG_FORMAT:-archive}"
ARTEFACT_NAME="totalsegmentator_2-15-0"

sha256() {
  if command -v sha256sum >/dev/null; then
    command sha256sum "$@"
  else
    shasum -a 256 "$@"
  fi
}

case "$FORMAT" in
  archive|sif|both) ;;
  *)
    echo "ERROR: TOTALSEG_FORMAT must be archive, sif or both" >&2
    exit 1
    ;;
esac

command -v docker >/dev/null || {
  echo "ERROR: docker not found on PATH" >&2
  exit 1
}
mkdir -p "$OUT_DIR"

echo "=== Pulling published model runtime: $SOURCE_IMAGE"
docker pull --platform linux/amd64 "$SOURCE_IMAGE"
docker image inspect "$SOURCE_IMAGE" >/dev/null

echo "=== Smoke-testing pulled model runtime offline"
docker run --rm --platform linux/amd64 --network none "$SOURCE_IMAGE" --metadata

archive="$OUT_DIR/${ARTEFACT_NAME}.tar.gz"
sif="$OUT_DIR/${ARTEFACT_NAME}.sif"

if [[ "$FORMAT" == "archive" || "$FORMAT" == "both" ]]; then
  echo "=== Exporting $archive"
  docker save "$SOURCE_IMAGE" | gzip >"$archive"
  (cd "$OUT_DIR" && sha256 "$(basename "$archive")") | tee "${archive}.sha256"
fi

if [[ "$FORMAT" == "sif" || "$FORMAT" == "both" ]]; then
  if ! command -v apptainer >/dev/null && ! command -v singularity >/dev/null; then
    echo "ERROR: TOTALSEG_FORMAT=$FORMAT needs apptainer or singularity" >&2
    exit 1
  fi
  runtime="$(command -v apptainer || command -v singularity)"
  echo "=== Converting the pulled image to $sif"
  "$runtime" build --force "$sif" "docker-daemon:${SOURCE_IMAGE}"
  (cd "$OUT_DIR" && sha256 "$(basename "$sif")") | tee "${sif}.sha256"
fi

echo "=== Export complete: $SOURCE_IMAGE"
