#!/bin/bash -l
# Run light or full QC in KCL CREATE; see README for setup.
#   submit_job jobs/kcl_tre/qc_slurm.sh
#   submit_job -p gpu --gres=gpu:1 jobs/kcl_tre/qc_slurm.sh    # full mode

#SBATCH --job-name=radiology_qc
#SBATCH --output=logs/qc_%j.out
#SBATCH --error=logs/qc_%j.err
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=32G
#SBATCH --time=0-4:00

set -euo pipefail

cd "${SLURM_SUBMIT_DIR:-$PWD}"
mkdir -p logs

ENV_FILE="${QC_ENV_FILE:-jobs/kcl_tre/env}"
if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: config not found: $ENV_FILE" >&2
  echo "Create it with: cp jobs/kcl_tre/env.example jobs/kcl_tre/env" >&2
  exit 1
fi
# shellcheck source=env.example
source "$ENV_FILE"

QC_MODE="${QC_MODE:-light}"
if [[ "$QC_MODE" == "full" ]]; then
  : "${TOTALSEG_RUNTIME:?QC_MODE=full requires TOTALSEG_RUNTIME}"
  : "${TOTALSEG_SOURCE:?QC_MODE=full requires TOTALSEG_SOURCE}"
  : "${TOTALSEG_IMAGE:?QC_MODE=full requires TOTALSEG_IMAGE}"
  : "${SINGULARITY_CACHEDIR:?QC_MODE=full requires SINGULARITY_CACHEDIR}"
  [[ "$TOTALSEG_RUNTIME" == "singularity" ]] || {
    echo "ERROR: KCL full mode requires TOTALSEG_RUNTIME=singularity" >&2
    exit 1
  }
  [[ "$TOTALSEG_SOURCE" == docker://* ]] || {
    echo "ERROR: TOTALSEG_SOURCE must be a docker:// GHCR image" >&2
    exit 1
  }
  [[ "$TOTALSEG_IMAGE" != *"://"* ]] || {
    echo "ERROR: TOTALSEG_IMAGE must be the local persistent SIF path" >&2
    exit 1
  }
  [[ "$TOTALSEG_IMAGE" == *.sif ]] || {
    echo "ERROR: TOTALSEG_IMAGE must end in .sif" >&2
    exit 1
  }
  command -v singularity >/dev/null || {
    echo "ERROR: singularity not found on PATH" >&2
    exit 1
  }

  export SINGULARITY_CACHEDIR
  mkdir -p "$SINGULARITY_CACHEDIR" "$(dirname "$TOTALSEG_IMAGE")"
  if [[ -s "$TOTALSEG_IMAGE" ]]; then
    echo "Using cached TotalSegmentator SIF: $TOTALSEG_IMAGE"
  else
    image_tmp="${TOTALSEG_IMAGE%.sif}.part-${SLURM_JOB_ID:-$$}.sif"
    trap 'rm -f "$image_tmp"' EXIT
    echo "Pulling TotalSegmentator from $TOTALSEG_SOURCE"
    singularity pull "$image_tmp" "$TOTALSEG_SOURCE"
    # Keep the first SIF if concurrent jobs pull the same image.
    mv -n "$image_tmp" "$TOTALSEG_IMAGE"
    [[ ! -e "$image_tmp" ]] || rm -f "$image_tmp"
    [[ -s "$TOTALSEG_IMAGE" ]] || {
      echo "ERROR: Singularity did not create $TOTALSEG_IMAGE" >&2
      exit 1
    }
    trap - EXIT
    echo "Cached TotalSegmentator SIF: $TOTALSEG_IMAGE"
  fi
fi

echo "QC started on $(date), node $(hostname)"
# Data mounts may be noexec.
QC_ENV_FILE="$ENV_FILE" bash ./jobs/run_qc.sh "$@"
echo "QC finished on $(date)"
