#!/bin/bash -l
# Run full mode on Apocrita; see README for setup.
#   cp jobs/qmul_hpc/env.example jobs/qmul_hpc/env
#   sbatch jobs/qmul_hpc/apocrita_full.sh

#SBATCH --job-name=radqc_full
#SBATCH --output=logs/apocrita_full_%j.out
#SBATCH --error=logs/apocrita_full_%j.err
#SBATCH --account=pilot_bciwiph
#SBATCH --partition=bciwiph
#SBATCH --gres=gpu:nvidia_l40s:1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12
#SBATCH --mem=128G
#SBATCH --time=0-2:00

set -euo pipefail

REPO_DIR="${SLURM_SUBMIT_DIR:-$PWD}"
cd "$REPO_DIR"
mkdir -p logs images

ENV_FILE="${QC_ENV_FILE:-$REPO_DIR/jobs/qmul_hpc/env}"
if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: config not found: $ENV_FILE" >&2
  echo "Create it with: cp jobs/qmul_hpc/env.example jobs/qmul_hpc/env" >&2
  exit 1
fi
# shellcheck source=env.example
source "$ENV_FILE"

: "${DATA_DIR:?not set in $ENV_FILE}"
: "${OUT_DIR:?not set in $ENV_FILE}"
: "${CONFIG_FILE:?not set in $ENV_FILE}"
: "${TOTALSEG_IMAGE:?not set in $ENV_FILE}"

export APPTAINER_CACHEDIR="${APPTAINER_CACHEDIR:?not set in $ENV_FILE}"
export APPTAINER_TMPDIR="${APPTAINER_TMPDIR:?not set in $ENV_FILE}"
mkdir -p "$APPTAINER_CACHEDIR" "$APPTAINER_TMPDIR"

export APPTAINERENV_SLURM_NTASKS="${SLURM_NTASKS:-1}"
umask 0002

echo "=== Apocrita full-mode validation, node $(hostname), $(date)"
nvidia-smi || {
  echo "ERROR: no GPU visible; is this a GPU partition?" >&2
  exit 1
}

# Convert the archive only when a SIF was not transferred.
if [[ -s "$TOTALSEG_IMAGE" ]]; then
  echo "INFO: $TOTALSEG_IMAGE exists, skipping archive conversion"
else
  : "${TOTALSEG_ARCHIVE:?missing TOTALSEG_ARCHIVE for SIF conversion}"
  [[ -s "$TOTALSEG_ARCHIVE" ]] || {
    echo "ERROR: no model image archive at $TOTALSEG_ARCHIVE" >&2
    exit 1
  }
  echo "=== Converting $TOTALSEG_ARCHIVE to $TOTALSEG_IMAGE"
  apptainer build "$TOTALSEG_IMAGE" "docker-archive:${TOTALSEG_ARCHIVE}"
fi

module load python/3.12.1-gcc-12.2.0
export PATH="$HOME/.local/bin:$PATH"
command -v poetry >/dev/null || pip install --user poetry==2.1.3
poetry env use "$(which python3)"
poetry config virtualenvs.in-project true
echo "=== Installing radiology-qc host dependencies"
poetry install --sync --no-interaction --only main

RUN_ENV="$(mktemp)"
trap 'rm -f "$RUN_ENV"' EXIT
cat > "$RUN_ENV" <<EOF
QC_MODE="full"
DATA_DIR="$DATA_DIR"
OUT_DIR="$OUT_DIR"
CONFIG_FILE="$CONFIG_FILE"
TOTALSEG_RUNTIME="apptainer"
TOTALSEG_IMAGE="$TOTALSEG_IMAGE"
TOTALSEG_USE_GPU="${TOTALSEG_USE_GPU:-true}"
SAVE_MASKS="${SAVE_MASKS:-false}"
EOF

echo "=== Running QC on host with model-only Apptainer inference"
QC_ENV_FILE="$RUN_ENV" bash ./jobs/run_qc.sh

# Require at least one successful segmentation.
echo "=== Checking segmentation ran"
python3 - "$OUT_DIR" <<'PY'
import json
import pathlib
import sys

out = pathlib.Path(sys.argv[1])
reports = list(out.rglob("*_qc_report.json"))
if not reports:
    sys.exit("ERROR: no reports written")
ran = errors = absent = 0
for report in reports:
    for series in json.loads(report.read_text()).get("series", []):
        result = series.get("image_quality", {}).get("segmentation_clipping")
        if result is None:
            absent += 1
        elif "error" in result:
            errors += 1
            print(f"  ERROR in {report.name}: {result['error']}")
        else:
            ran += 1
print(f"series with segmentation: {ran}, errored: {errors}, not applicable: {absent}")
if errors:
    sys.exit("FAIL: segmentation errored")
if not ran:
    sys.exit("FAIL: segmentation never ran")
print("PASS: host QC used the model-only Apptainer runtime")
PY

echo "=== Finished $(date)"
echo "Model artefact: $TOTALSEG_IMAGE"
