#!/bin/bash -l
# Run CPU-only light mode on Apocrita; see README for setup.
#   cp jobs/qmul_hpc/env.example jobs/qmul_hpc/env
#   sbatch jobs/qmul_hpc/apocrita_light.sh

#SBATCH --job-name=radqc_light
#SBATCH --output=logs/apocrita_light_%j.out
#SBATCH --error=logs/apocrita_light_%j.err
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --time=0-2:00

# The bciwiph partition requires a GPU, so light mode leaves it unset.

set -euo pipefail

REPO_DIR="${SLURM_SUBMIT_DIR:-$PWD}"
cd "$REPO_DIR"
mkdir -p logs

ENV_FILE="${QC_ENV_FILE:-$REPO_DIR/jobs/qmul_hpc/env}"
if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: config not found: $ENV_FILE" >&2
  echo "Create it with: cp jobs/qmul_hpc/env.example jobs/qmul_hpc/env" >&2
  exit 1
fi
# shellcheck source=env.example
source "$ENV_FILE"

: "${DATA_DIR:?not set in $ENV_FILE}"
: "${OUT_DIR:?not set in $ENV_FILE}"
: "${CONFIG_FILE:?not set in $ENV_FILE}"

module load python/3.12.1-gcc-12.2.0

echo "=== Apocrita light-mode validation, node $(hostname), $(date)"

export PATH="$HOME/.local/bin:$PATH"
command -v poetry >/dev/null || pip install --user poetry==2.1.3
poetry --version
poetry env use "$(which python3)"

poetry config virtualenvs.in-project true

echo "=== poetry install"
poetry install --sync --no-interaction --only main
poetry run python --version

RUN_ENV="$(mktemp)"
trap 'rm -f "$RUN_ENV"' EXIT
cat > "$RUN_ENV" <<EOF
QC_MODE="light"
DATA_DIR="$DATA_DIR"
OUT_DIR="$OUT_DIR"
CONFIG_FILE="$CONFIG_FILE"
EOF

echo "=== Running light QC (no container)"
# /data may be mounted noexec.
QC_ENV_FILE="$RUN_ENV" bash ./jobs/run_qc.sh

echo "=== Finished $(date)"
