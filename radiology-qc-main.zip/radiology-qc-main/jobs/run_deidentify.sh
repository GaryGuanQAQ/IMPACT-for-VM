#!/usr/bin/env bash
# Host launcher for de-identification.
#
#   QC_ENV_FILE=jobs/<environment>/env ./jobs/run_deidentify.sh
#
# The writer produces both metadata passes itself, so there is no separate
# extract stage: the source metadata and UID mapping go to LINKAGE_DIR, and the
# export carries its own pseudonymous cache for QC to read. DATA_DIR is treated
# as read-only. Run ./jobs/run_qc.sh against DEID_DIR afterwards.

set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${QC_ENV_FILE:-$REPO_DIR/jobs/env}"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: config not found: $ENV_FILE" >&2
  echo "Create it from the matching jobs/<environment>/env.example" >&2
  exit 1
fi
# shellcheck source=barts_sde/env.example
source "$ENV_FILE"

: "${DATA_DIR:?not set in $ENV_FILE}"
: "${DEID_DIR:?not set in $ENV_FILE}"
: "${LINKAGE_DIR:?not set in $ENV_FILE; it receives the source metadata and UID
  mapping and must sit in the source security zone, outside DATA_DIR and DEID_DIR}"

[[ -d "$DATA_DIR" ]] || {
  echo "ERROR: DATA_DIR does not exist: $DATA_DIR" >&2
  exit 1
}
command -v poetry >/dev/null || {
  echo "ERROR: poetry not found on PATH; install Poetry and run 'poetry install'" >&2
  exit 1
}

DATA_ABS="$(cd "$DATA_DIR" && pwd)"
mkdir -p "$DEID_DIR"
DEID_ABS="$(cd "$DEID_DIR" && pwd)"

if [[ "$DEID_ABS" == "$DATA_ABS" || "$DEID_ABS" == "$DATA_ABS"/* || "$DATA_ABS" == "$DEID_ABS"/* ]]; then
  echo "ERROR: DEID_DIR and DATA_DIR must be separate, non-nested directories" >&2
  exit 1
fi

# The writer enforces this too, on every invocation rather than only this one.
# Checked here as well so a misconfigured env file fails before any work starts.
case "$LINKAGE_DIR" in
  /*) LINKAGE_CANDIDATE="$LINKAGE_DIR" ;;
  *) LINKAGE_CANDIDATE="$PWD/$LINKAGE_DIR" ;;
esac
if [[ "$LINKAGE_CANDIDATE" == "$DEID_ABS" || "$LINKAGE_CANDIDATE" == "$DEID_ABS"/* ]]; then
  echo "ERROR: LINKAGE_DIR must not be inside DEID_DIR; together with the export" >&2
  echo "       it is a linkage record and must not be released with it." >&2
  exit 1
fi
if [[ "$LINKAGE_CANDIDATE" == "$DATA_ABS" || "$LINKAGE_CANDIDATE" == "$DATA_ABS"/* ]]; then
  echo "ERROR: LINKAGE_DIR must be outside DATA_DIR, which is read-only" >&2
  exit 1
fi
mkdir -p "$LINKAGE_DIR"
LINKAGE_ABS="$(cd "$LINKAGE_DIR" && pwd)"

CONFIG_FILE="$(mktemp -t radqc_deid_config.XXXXXX)"
trap 'rm -f "$CONFIG_FILE"' EXIT
INPUT_DIR="$DATA_ABS" OUTPUT_DIR="$DEID_ABS" LINKAGE="$LINKAGE_ABS" \
ANCHOR="${ANCHOR_DATE:-}" PARTICIPANT_ID_MAP="${PARTICIPANT_ID_MAP:-}" \
CENTRE="${CENTRE:-}" TISSUE_SOURCE_SITE="${TISSUE_SOURCE_SITE:-}" \
  poetry run --directory "$REPO_DIR" python -c '
import json, os, sys
config = {
    "input_directory": os.environ["INPUT_DIR"],
    "output_directory": os.environ["OUTPUT_DIR"],
    "linkage_directory": os.environ["LINKAGE"],
}
for key, name in (("ANCHOR", "anchor_date"),
                  ("PARTICIPANT_ID_MAP", "participant_id_map"),
                  ("CENTRE", "centre"),
                  ("TISSUE_SOURCE_SITE", "tissue_source_site")):
    if os.environ.get(key):
        config[name] = os.environ[key]
json.dump(config, open(sys.argv[1], "w"), indent=2)
' "$CONFIG_FILE"

echo "=== De-identifying $DATA_ABS to $DEID_ABS (linkage in $LINKAGE_ABS)"
(cd "$REPO_DIR" && poetry run python -m deidentify.deidentify "$CONFIG_FILE")

if [[ ! -f "$DEID_ABS/deidentification_manifest.json" ]]; then
  echo "ERROR: no export manifest written; the run refused to produce output" >&2
  exit 1
fi
if [[ ! -f "$LINKAGE_ABS/run_record.json" ]]; then
  echo "ERROR: no run record written; the export cannot be relinked" >&2
  exit 1
fi

echo "De-identification complete — export in $DEID_ABS, linkage in $LINKAGE_ABS"
echo "Next: DATA_DIR=$DEID_ABS ./jobs/run_qc.sh"
