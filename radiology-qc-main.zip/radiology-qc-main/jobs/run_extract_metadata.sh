#!/usr/bin/env bash
# Host launcher for the metadata cache; see README for the pipeline order.
#   QC_ENV_FILE=jobs/<environment>/env ./jobs/run_extract_metadata.sh [DATA_DIR] [METADATA_DIR]
#
# Positional arguments override EXTRACT_DATA_DIR/EXTRACT_METADATA_DIR so the
# de-identification launcher can reuse this script for its before/after passes.

set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${QC_ENV_FILE:-$REPO_DIR/jobs/env}"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: config not found: $ENV_FILE" >&2
  echo "Create it from the matching jobs/<environment>/env.example" >&2
  exit 1
fi
# shellcheck source=barts_sde/env.example
source "$ENV_FILE"

SOURCE_DIR="${1:-${EXTRACT_DATA_DIR:-${DATA_DIR:-}}}"
TARGET_DIR="${2:-${EXTRACT_METADATA_DIR:-}}"
METADATA_FILENAME="${METADATA_FILENAME:-dicom_metadata.json}"

: "${SOURCE_DIR:?set DATA_DIR or EXTRACT_DATA_DIR in $ENV_FILE}"
[[ -d "$SOURCE_DIR" ]] || {
  echo "ERROR: directory does not exist: $SOURCE_DIR" >&2
  exit 1
}
command -v poetry >/dev/null || {
  echo "ERROR: poetry not found on PATH; install Poetry and run 'poetry install'" >&2
  exit 1
}

SOURCE_ABS="$(cd "$SOURCE_DIR" && pwd)"
TARGET_ABS=""
if [[ -n "$TARGET_DIR" ]]; then
  mkdir -p "$TARGET_DIR"
  TARGET_ABS="$(cd "$TARGET_DIR" && pwd)"
elif [[ ! -w "$SOURCE_ABS" ]]; then
  # Without a target the cache is written beside the data, which a read-only
  # source tree cannot accept.
  echo "ERROR: no metadata directory given and the data is not writable:" >&2
  echo "       $SOURCE_ABS" >&2
  echo "Pass a writable target: ./jobs/run_extract_metadata.sh <data> <metadata>" >&2
  echo "or set EXTRACT_METADATA_DIR in $ENV_FILE" >&2
  exit 1
fi

# The cache holds private-tag text and raw UIDs, so it is as sensitive as its
# source. Never let a pre-de-identification cache land inside an export.
CONFIG_FILE="$(mktemp -t radqc_extract_config.XXXXXX)"
trap 'rm -f "$CONFIG_FILE"' EXIT
INPUT_DIR="$SOURCE_ABS" OUTPUT_DIR="$TARGET_ABS" FILENAME="$METADATA_FILENAME" \
  poetry run --directory "$REPO_DIR" python -c '
import json, os, sys
json.dump({
    "input_directory": os.environ["INPUT_DIR"],
    "output_directory": os.environ["OUTPUT_DIR"] or None,
    "output_filename": os.environ["FILENAME"],
}, open(sys.argv[1], "w"), indent=2)
' "$CONFIG_FILE"

echo "=== Extracting metadata from $SOURCE_ABS to ${TARGET_ABS:-<beside the data>}"
(cd "$REPO_DIR" && poetry run python -m extract_metadata.extract_metadata "$CONFIG_FILE")

echo "Metadata extraction complete — $METADATA_FILENAME per study"
