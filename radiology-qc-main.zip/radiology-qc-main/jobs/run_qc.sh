#!/usr/bin/env bash
# Host launcher; see README for light/full deployment.
#   QC_ENV_FILE=jobs/<environment>/env ./jobs/run_qc.sh [config.json]

set -euo pipefail

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${QC_ENV_FILE:-$REPO_DIR/jobs/env}"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: config not found: $ENV_FILE" >&2
  echo "Create it from the matching jobs/<environment>/env.example" >&2
  exit 1
fi
# shellcheck source=barts_sde/env.example
source "$ENV_FILE"

: "${DATA_DIR:?not set in $ENV_FILE}"
: "${OUT_DIR:?not set in $ENV_FILE}"
QC_MODE="${QC_MODE:-light}"
CONFIG_FILE="${1:-${CONFIG_FILE:-}}"

case "$QC_MODE" in
  light|full) ;;
  *)
    echo "ERROR: QC_MODE must be light or full, got '$QC_MODE'" >&2
    exit 1
    ;;
esac

[[ -d "$DATA_DIR" ]] || {
  echo "ERROR: DATA_DIR does not exist: $DATA_DIR" >&2
  exit 1
}
if [[ -n "$CONFIG_FILE" && ! -f "$CONFIG_FILE" ]]; then
  echo "ERROR: config does not exist: $CONFIG_FILE" >&2
  exit 1
fi
mkdir -p "$OUT_DIR"

CONFIG_ABS=""
if [[ -n "$CONFIG_FILE" ]]; then
  CONFIG_ABS="$(cd "$(dirname "$CONFIG_FILE")" && pwd)/$(basename "$CONFIG_FILE")"
fi

command -v poetry >/dev/null || {
  echo "ERROR: poetry not found on PATH; install Poetry and run 'poetry install'" >&2
  exit 1
}

export RADQC_ROOT_DIR="$(cd "$DATA_DIR" && pwd)"
export RADQC_OUTPUT_DIR="$(cd "$OUT_DIR" && pwd)"
export RADQC_MODE="$QC_MODE"
if [[ "${SAVE_MASKS:-false}" == "true" ]]; then
  export RADQC_SAVE_MASKS=1
fi

if [[ "$QC_MODE" == "full" ]]; then
  : "${TOTALSEG_RUNTIME:?QC_MODE=full requires TOTALSEG_RUNTIME}"
  : "${TOTALSEG_IMAGE:?QC_MODE=full requires TOTALSEG_IMAGE}"
  TOTALSEG_USE_GPU="${TOTALSEG_USE_GPU:-true}"

  case "$TOTALSEG_RUNTIME" in
    docker)
      command -v docker >/dev/null || {
        echo "ERROR: docker not found on PATH" >&2
        exit 1
      }
      if [[ "${TOTALSEG_PULL:-false}" == "true" ]]; then
        docker pull "$TOTALSEG_IMAGE"
      fi
      docker image inspect "$TOTALSEG_IMAGE" >/dev/null 2>&1 || {
        echo "ERROR: Docker model image is unavailable: $TOTALSEG_IMAGE" >&2
        echo "Pull it first, or set TOTALSEG_PULL=true in a connected environment." >&2
        exit 1
      }
      ;;
    apptainer|singularity)
      command -v "$TOTALSEG_RUNTIME" >/dev/null || {
        echo "ERROR: $TOTALSEG_RUNTIME not found on PATH" >&2
        exit 1
      }
      if [[ "$TOTALSEG_IMAGE" != *"://"* && ! -f "$TOTALSEG_IMAGE" ]]; then
        echo "ERROR: model image does not exist: $TOTALSEG_IMAGE" >&2
        exit 1
      fi
      ;;
    *)
      echo "ERROR: TOTALSEG_RUNTIME must be docker, apptainer or singularity" >&2
      exit 1
      ;;
  esac

  export RADQC_TOTALSEG_RUNTIME="$TOTALSEG_RUNTIME"
  export RADQC_TOTALSEG_IMAGE="$TOTALSEG_IMAGE"
  export RADQC_TOTALSEG_USE_GPU="$TOTALSEG_USE_GPU"
fi

command=(poetry run python -m radiology_qc.qc_pipeline)
[[ -n "$CONFIG_ABS" ]] && command+=("$CONFIG_ABS")

if [[ "$QC_MODE" == "light" ]]; then
  echo "=== Running radiology-qc (mode=light, no container)"
else
  echo "=== Running radiology-qc (mode=full, TotalSegmentator container)"
fi
(cd "$REPO_DIR" && "${command[@]}")

echo "QC complete — reports in $OUT_DIR"
