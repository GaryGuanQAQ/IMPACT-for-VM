# NIfTI conversion

Converts each **series** of a DICOM study into one NIfTI file. The series is the
unit because it is the smallest DICOM grouping guaranteed to share an
acquisition geometry; a study spanning several orientations or resolutions has
no single volume to write.

## Running it

Standalone, over a DICOM tree:

```bash
poetry run python -m nifti_conversion.convert nifti_conversion/config.json
```

Or as part of de-identification, which is the intended path for release data —
see [write_nifti](../deidentify/README.md#configuration). The de-identifier
converts **from its own export**, never from the source, so a NIfTI can only
ever hold pixels that were already cleared for release.

## Configuration

| Key | Default (`settings.py`) | What it does |
| --- | --- | --- |
| `input_directory` | required | Root scanned recursively for `*.dcm` / `*.DCM`; may hold many studies. |
| `output_directory` | `""` | Where NIfTI files go, mirroring input paths one directory per study. Empty writes beside the source data. |
| `rescale_values` | `true` (`DEFAULT_RESCALE_VALUES`) | Apply `RescaleSlope`/`RescaleIntercept`, producing real-world values (e.g. Hounsfield units) as float32. `false` keeps stored integers. |
| `skip_derived` | `false` (`DEFAULT_SKIP_DERIVED`) | Skip series whose `ImageType` contains `DERIVED`, such as MIPs and processed reconstructions. |
| `skip_single_instance` | `false` (`DEFAULT_SKIP_SINGLE_INSTANCE`) | Skip series holding one instance, which produce a single-slice volume. |

`DEFAULT_MAX_SLICE_SPACING_VARIATION_MM` (0.05 mm) is the tolerance for calling
a stack regular. It is a fixed invariant rather than a config key because
loosening it does not fix an irregular series, it just mislabels one.

## Geometry

The affine is built from `ImageOrientationPatient`, `ImagePositionPatient` and
`PixelSpacing`, then flipped on the first two axes: DICOM patient coordinates
are LPS, NIfTI is RAS. Voxel axis 0 walks image columns and axis 1 walks rows,
so `PixelSpacing`'s row/column order is not the array's.

Instances are ordered by their position projected onto the slice normal, which
is the only ordering that reflects physical stacking. `InstanceNumber` is used
only when the series carries no position — there it is acquisition order, which
may not be geometric.

## What is refused

A series is skipped, recorded, and reported rather than written when it cannot
be one regular volume. The rest of the study still converts.

| Reason | Meaning |
| --- | --- |
| `inconsistent_dimensions` | Instances differ in `Rows`/`Columns`, or are multi-sample or multi-frame. |
| `inconsistent_orientation` | Instances span more than one `ImageOrientationPatient`. |
| `irregular_slice_spacing` | Gaps between slices vary by more than the tolerance, so no single spacing describes the stack. |
| `no_pixel_data` | Pixel data is absent or could not be decoded. |

Refusing beats writing: a volume stacked from mismatched slices looks valid and
silently misrepresents the acquisition.

## Limitations

- **Metadata is not carried.** A NIfTI header has no place for acquisition
  parameters, so the DICOM export remains the record of record and the NIfTI is
  a derived artefact. This is also why nothing identifying can travel in the
  file.
- **2D modalities gain a meaningless third axis.** A mammography or radiography
  series has no through-plane geometry, so its slice spacing falls back to
  `SliceThickness` or 1.0 mm and the third dimension counts instances rather
  than measuring distance. The pixels and in-plane spacing are correct; the
  z axis is not a physical one.
- **Multi-frame instances are not supported**, and are refused as
  `inconsistent_dimensions` rather than silently mishandled.
- **Compressed transfer syntaxes** need a pydicom pixel data handler
  (`pylibjpeg`, `gdcm`) installed; without one the series is refused as
  `no_pixel_data`.
- Filenames come from `SeriesNumber` and `SeriesDescription`, which the
  de-identification profile retains as acquisition rather than patient
  information. Sites whose descriptions carry identifying text must review that
  assumption, since the filename travels with the file.
