"""Convert each series of a DICOM study into one NIfTI file.

The unit of conversion is the series, because that is the smallest DICOM
grouping guaranteed to share an acquisition geometry. A series whose instances
disagree on dimensions, orientation, or slice spacing is reported and skipped
rather than stacked into a volume that would silently misrepresent the
acquisition.
"""

from __future__ import annotations

import json
import logging
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pydicom

from extract_metadata.extract_metadata import (
    discover_dicom_files,
    group_by_study,
    study_directory,
)
from nifti_conversion.settings import (
    DEFAULT_MAX_SLICE_SPACING_VARIATION_MM,
    DEFAULT_NIFTI_EXTENSION,
    DEFAULT_RESCALE_VALUES,
    DEFAULT_SKIP_DERIVED,
    DEFAULT_SKIP_SINGLE_INSTANCE,
    LPS_TO_RAS,
    NIFTI_XYZT_UNITS_MM_SEC,
    sanitise_filename_stem,
)

logger = logging.getLogger(__name__)


class SeriesNotStackable(ValueError):
    """A series cannot be represented as a single regular volume."""

    def __init__(self, reason: str, detail: str):
        super().__init__(detail)
        self.reason = reason
        self.detail = detail


def _orientation(ds: pydicom.dataset.Dataset) -> Optional[np.ndarray]:
    value = getattr(ds, "ImageOrientationPatient", None)
    if value is None or len(value) != 6:
        return None
    return np.asarray([float(v) for v in value], dtype=float)


def _position(ds: pydicom.dataset.Dataset) -> Optional[np.ndarray]:
    value = getattr(ds, "ImagePositionPatient", None)
    if value is None or len(value) != 3:
        return None
    return np.asarray([float(v) for v in value], dtype=float)


def _pixel_spacing(ds: pydicom.dataset.Dataset) -> Tuple[float, float]:
    """Row/column spacing in mm, falling back to the projection form."""
    for keyword in ("PixelSpacing", "ImagerPixelSpacing"):
        value = getattr(ds, keyword, None)
        if value is not None and len(value) == 2:
            return float(value[0]), float(value[1])
    return 1.0, 1.0


def _instance_pixels(
    ds: pydicom.dataset.Dataset, rescale: bool
) -> np.ndarray:
    """One instance's pixels, with the stored-value transform applied."""
    array = ds.pixel_array
    if not rescale:
        return array
    slope = float(getattr(ds, "RescaleSlope", 1) or 1)
    intercept = float(getattr(ds, "RescaleIntercept", 0) or 0)
    if slope == 1.0 and intercept == 0.0:
        return array
    return array.astype(np.float32) * slope + intercept


def sort_series_instances(
    datasets: Sequence[pydicom.dataset.Dataset],
) -> List[pydicom.dataset.Dataset]:
    """Order instances along the slice normal, or by InstanceNumber if flat.

    Position along the normal is the only ordering that reflects physical
    stacking; InstanceNumber is a fallback for series that carry no position,
    where it is the acquisition order rather than a geometric one.
    """
    orientation = next(
        (o for o in (_orientation(ds) for ds in datasets) if o is not None), None
    )
    positions = [_position(ds) for ds in datasets]
    if orientation is not None and all(p is not None for p in positions):
        normal = np.cross(orientation[:3], orientation[3:])
        return [
            ds for _, ds in sorted(
                zip((float(np.dot(p, normal)) for p in positions), datasets),
                key=lambda pair: pair[0],
            )
        ]
    return sorted(
        datasets, key=lambda ds: int(getattr(ds, "InstanceNumber", 0) or 0)
    )


def slice_spacing(
    datasets: Sequence[pydicom.dataset.Dataset],
    max_variation_mm: float = DEFAULT_MAX_SLICE_SPACING_VARIATION_MM,
) -> float:
    """Spacing between ordered slices, rejecting irregular stacks.

    An irregular stack has no single spacing, so writing one would encode a
    geometry the acquisition does not have.
    """
    if len(datasets) < 2:
        thickness = getattr(datasets[0], "SliceThickness", None)
        return float(thickness) if thickness else 1.0

    orientation = _orientation(datasets[0])
    positions = [_position(ds) for ds in datasets]
    if orientation is None or any(p is None for p in positions):
        spacing = getattr(datasets[0], "SpacingBetweenSlices", None) or getattr(
            datasets[0], "SliceThickness", None
        )
        return float(spacing) if spacing else 1.0

    normal = np.cross(orientation[:3], orientation[3:])
    projections = np.asarray([float(np.dot(p, normal)) for p in positions])
    gaps = np.diff(projections)
    if not len(gaps):
        return 1.0
    spread = float(gaps.max() - gaps.min())
    if spread > max_variation_mm:
        raise SeriesNotStackable(
            "irregular_slice_spacing",
            f"slice spacing varies by {spread:.3f} mm across the series "
            f"(limit {max_variation_mm} mm)",
        )
    mean_gap = float(gaps.mean())
    return abs(mean_gap) if mean_gap else 1.0


def series_affine(
    datasets: Sequence[pydicom.dataset.Dataset], spacing_between_slices: float
) -> np.ndarray:
    """The RAS affine mapping voxel indices to millimetres.

    Built from the DICOM patient coordinate system and then flipped on the
    first two axes, since DICOM is LPS and NIfTI is RAS.
    """
    first = datasets[0]
    orientation = _orientation(first)
    position = _position(first)
    row_spacing, column_spacing = _pixel_spacing(first)

    if orientation is None:
        orientation = np.asarray([1.0, 0.0, 0.0, 0.0, 1.0, 0.0])
    if position is None:
        position = np.zeros(3)

    row_cosine = orientation[:3]
    column_cosine = orientation[3:]
    normal = np.cross(row_cosine, column_cosine)

    affine = np.eye(4, dtype=float)
    # Affine columns are the voxel axes of the stacked array, which is indexed
    # (row, column, slice) because that is the shape of a DICOM pixel array.
    # Stepping a row moves along the column cosine by the between-row spacing,
    # PixelSpacing[0]; stepping a column moves along the row cosine by
    # PixelSpacing[1]. Pairing each index with the other one's cosine transposes
    # every image.
    affine[:3, 0] = column_cosine * row_spacing
    affine[:3, 1] = row_cosine * column_spacing
    affine[:3, 2] = normal * spacing_between_slices
    affine[:3, 3] = position

    flip = np.asarray(LPS_TO_RAS, dtype=float)
    affine[:3, :] *= flip[:, np.newaxis]
    return affine


def build_series_volume(
    datasets: Sequence[pydicom.dataset.Dataset],
    rescale: bool = DEFAULT_RESCALE_VALUES,
    max_variation_mm: float = DEFAULT_MAX_SLICE_SPACING_VARIATION_MM,
) -> Tuple[np.ndarray, np.ndarray]:
    """Stack one series into a (rows, columns, slices) array and its affine."""
    if not datasets:
        raise SeriesNotStackable("no_pixel_data", "series has no instances")

    ordered = sort_series_instances(datasets)

    shapes = {(int(ds.Rows), int(ds.Columns)) for ds in ordered}
    if len(shapes) > 1:
        raise SeriesNotStackable(
            "inconsistent_dimensions",
            f"instances have differing sizes {sorted(shapes)}",
        )

    orientations = {
        tuple(np.round(o, 5))
        for o in (_orientation(ds) for ds in ordered)
        if o is not None
    }
    if len(orientations) > 1:
        raise SeriesNotStackable(
            "inconsistent_orientation",
            f"instances span {len(orientations)} distinct orientations",
        )

    try:
        planes = [_instance_pixels(ds, rescale) for ds in ordered]
    except Exception as exc:
        raise SeriesNotStackable(
            "no_pixel_data", f"pixel data could not be decoded: {exc}"
        ) from exc

    if any(plane.ndim != 2 for plane in planes):
        raise SeriesNotStackable(
            "inconsistent_dimensions",
            "multi-sample or multi-frame instances are not supported",
        )

    volume = np.stack(planes, axis=-1)
    spacing = slice_spacing(ordered, max_variation_mm)
    return volume, series_affine(ordered, spacing)


def series_filename(
    datasets: Sequence[pydicom.dataset.Dataset],
    taken: Iterable[str] = (),
    extension: str = DEFAULT_NIFTI_EXTENSION,
) -> str:
    """A readable, collision-free filename for one series.

    Uses SeriesNumber and SeriesDescription, both of which the
    de-identification profile retains as acquisition rather than patient
    information, and falls back to the Series Instance UID.
    """
    first = datasets[0]
    number = getattr(first, "SeriesNumber", None)
    description = sanitise_filename_stem(getattr(first, "SeriesDescription", "") or "")

    parts = []
    if number is not None:
        parts.append(f"{int(number):04d}")
    if description:
        parts.append(description)
    stem = "_".join(parts) or sanitise_filename_stem(
        str(getattr(first, "SeriesInstanceUID", "series"))
    )

    taken = set(taken)
    candidate = f"{stem}{extension}"
    if candidate not in taken:
        return candidate
    suffix = sanitise_filename_stem(
        str(getattr(first, "SeriesInstanceUID", ""))
    )[-12:]
    candidate = f"{stem}_{suffix}{extension}" if suffix else candidate
    counter = 2
    while candidate in taken:
        candidate = f"{stem}_{counter}{extension}"
        counter += 1
    return candidate


def convert_study(
    entries: Sequence[Tuple[Path, pydicom.dataset.Dataset]],
    output_directory: Path,
    rescale: bool = DEFAULT_RESCALE_VALUES,
    skip_derived: bool = DEFAULT_SKIP_DERIVED,
    skip_single_instance: bool = DEFAULT_SKIP_SINGLE_INSTANCE,
    max_variation_mm: float = DEFAULT_MAX_SLICE_SPACING_VARIATION_MM,
    extension: str = DEFAULT_NIFTI_EXTENSION,
) -> Dict[str, Any]:
    """Write one NIfTI per series of a study; report series that cannot convert.

    A series that cannot be stacked is skipped and recorded rather than raising,
    so one unusual series does not cost the rest of the study.
    """
    import nibabel as nib  # Imported late so the rest of the module stays light.

    by_series: Dict[str, List[pydicom.dataset.Dataset]] = defaultdict(list)
    for _, ds in entries:
        by_series[str(getattr(ds, "SeriesInstanceUID", "UNKNOWN"))].append(ds)

    written: List[Dict[str, Any]] = []
    skipped: List[Dict[str, Any]] = []
    taken: List[str] = []

    for series_uid, datasets in sorted(by_series.items()):
        first = datasets[0]
        image_type = [str(v).upper() for v in (getattr(first, "ImageType", None) or [])]
        if skip_derived and "DERIVED" in image_type:
            skipped.append({
                "series_instance_uid": series_uid,
                "reason": "derived",
                "detail": "ImageType marks this series as DERIVED",
            })
            continue
        if skip_single_instance and len(datasets) < 2:
            skipped.append({
                "series_instance_uid": series_uid,
                "reason": "single_instance",
                "detail": "series holds one instance",
            })
            continue

        try:
            volume, affine = build_series_volume(datasets, rescale, max_variation_mm)
        except SeriesNotStackable as exc:
            logger.warning("Skipping series %s: %s", series_uid, exc.detail)
            skipped.append({
                "series_instance_uid": series_uid,
                "reason": exc.reason,
                "detail": exc.detail,
            })
            continue

        filename = series_filename(datasets, taken, extension)
        taken.append(filename)
        output_directory.mkdir(parents=True, exist_ok=True)
        destination = output_directory / filename

        image = nib.Nifti1Image(volume, affine)
        image.header.set_xyzt_units(NIFTI_XYZT_UNITS_MM_SEC & 7, 8)
        nib.save(image, destination)

        written.append({
            "series_instance_uid": series_uid,
            "file_name": filename,
            "instance_count": len(datasets),
            "shape": list(volume.shape),
        })
        logger.info(
            "Wrote %s (%d instance(s), shape %s)",
            destination, len(datasets), tuple(volume.shape),
        )

    return {
        "series_written": written,
        "series_skipped": skipped,
        "written_count": len(written),
        "skipped_count": len(skipped),
    }


def main(config_path: Path) -> None:
    """Convert every study under `input_directory` to per-series NIfTI files."""
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
    except FileNotFoundError:
        logger.error(f"Config not found: {config_path}")
        return
    except Exception as e:
        logger.error(f"Config error: {e}")
        return

    input_dir = config.get("input_directory")
    if not input_dir:
        logger.error(
            f"Set 'input_directory' in {config_path} "
            "(the DICOM scan root; may contain multiple studies)."
        )
        return

    input_root = Path(input_dir)
    output_dir = config.get("output_directory")
    output_root = Path(output_dir) if output_dir else None

    files = discover_dicom_files(input_root)
    if not files:
        logger.error(f"No DICOM files found under {input_root}")
        return

    studies = group_by_study(files, stop_before_pixels=False)
    logger.info("Converting %d study(ies)...", len(studies))

    for study_uid, entries in studies.items():
        # The common parent of every instance, not the first file's folder,
        # which for a series-per-subdirectory layout is only one series.
        study_dir = study_directory(entries)
        if output_root is None:
            destination = study_dir
        else:
            try:
                relative = study_dir.relative_to(input_root)
            except ValueError:
                relative = Path(study_dir.name)
            destination = output_root / relative
        result = convert_study(
            entries,
            destination,
            rescale=config.get("rescale_values", DEFAULT_RESCALE_VALUES),
            skip_derived=config.get("skip_derived", DEFAULT_SKIP_DERIVED),
            skip_single_instance=config.get(
                "skip_single_instance", DEFAULT_SKIP_SINGLE_INSTANCE
            ),
        )
        logger.info(
            "Study %s: %d series written, %d skipped",
            study_uid, result["written_count"], result["skipped_count"],
        )


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    config_arg = (Path(sys.argv[1]) if len(sys.argv) > 1
                  else Path(__file__).resolve().parent / "config.json")
    main(config_arg)
