"""Defaults and fixed invariants for DICOM-to-NIfTI conversion.

Conversion is lossy in one direction only: pixel values and geometry are
carried over, DICOM metadata is not. A NIfTI header has nowhere to put patient
demographics, so nothing identifying can travel in the file — but nothing
clinical does either, which is why the DICOM export remains the record of
record and the NIfTI is a derived artefact.
"""

from __future__ import annotations

import re

# Run defaults.
DEFAULT_NIFTI_EXTENSION = ".nii.gz"
DEFAULT_RESCALE_VALUES = True
DEFAULT_SKIP_DERIVED = False
DEFAULT_SKIP_SINGLE_INSTANCE = False
DEFAULT_MAX_SLICE_SPACING_VARIATION_MM = 0.05

# Fixed invariants. Changing these changes what the written geometry means.
#
# DICOM patient coordinates are LPS (+x left, +y posterior, +z superior);
# NIfTI qform/sform are RAS. The first two axes therefore flip.
LPS_TO_RAS = (-1.0, -1.0, 1.0)
NIFTI_XYZT_UNITS_MM_SEC = 10  # 2 (mm) | 8 (sec)

# Series whose instances cannot be stacked into one volume.
UNSTACKABLE_REASONS = (
    "inconsistent_dimensions",
    "inconsistent_orientation",
    "irregular_slice_spacing",
    "no_pixel_data",
)

_FILENAME_SAFE_RE = re.compile(r"[^A-Za-z0-9._-]+")
MAX_FILENAME_STEM = 96


def sanitise_filename_stem(value: str) -> str:
    """Reduce a DICOM text value to something safe as a filename stem."""
    cleaned = _FILENAME_SAFE_RE.sub("_", str(value)).strip("._-")
    return cleaned[:MAX_FILENAME_STEM]
