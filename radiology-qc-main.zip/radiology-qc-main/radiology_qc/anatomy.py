from __future__ import annotations

from typing import Any, Dict

from radiology_qc.settings import DEFAULT_ANATOMY_PROFILES

VOLUMETRIC_MODALITIES = {"MR", "CT", "PT"}

_BODYPART_KEYWORDS = [
    ("BREAST", "BREAST"), ("MAMMO", "BREAST"),
    ("LUNG", "LUNG"), ("CHEST", "CHEST"), ("THORAX", "CHEST"),
    ("ABDOMEN", "ABDOMEN"), ("PANCR", "ABDOMEN"), ("LIVER", "ABDOMEN"),
]


def infer_body_part(body_part_examined: str, *descriptions: str) -> str:
    """Normalise BodyPartExamined; else scan descriptions for a known region."""
    bp = (body_part_examined or "").strip().upper()
    if bp:
        for key, norm in _BODYPART_KEYWORDS:
            if key in bp:
                return norm
        return bp
    blob = " ".join(d.upper() for d in descriptions if d)
    for key, norm in _BODYPART_KEYWORDS:
        if key in blob:
            return norm
    return "DEFAULT"


def resolve_profile(modality: str, body_part: str) -> Dict[str, Any]:
    """Look up the profile for modality/body_part, most specific first."""
    profiles = DEFAULT_ANATOMY_PROFILES
    for key in (f"{modality}/{body_part}", f"{modality}/DEFAULT", "DEFAULT"):
        if key in profiles:
            return {"profile_key": key, **profiles[key]}
    return {"profile_key": "DEFAULT", **profiles["DEFAULT"]}
