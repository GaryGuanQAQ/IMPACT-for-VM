import hashlib
import logging
from pathlib import Path
from typing import Optional, Tuple

import pydicom

logger = logging.getLogger(__name__)


def calculate_md5(file_path: Path) -> str:
    """Calculate the MD5 checksum of a file for binary integrity validation."""
    hash_md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


def validate_dicom_parse(
    file_path: Path, stop_before_pixels: bool = False
) -> Tuple[Optional[pydicom.dataset.Dataset], Optional[str]]:
    """Parse DICOM and return either the dataset or a readable error."""
    try:
        return pydicom.dcmread(file_path, stop_before_pixels=stop_before_pixels), None
    except Exception as e:
        error = f"{type(e).__name__}: {e}"
        logger.warning("Failed to parse DICOM %s: %s", file_path, error)
        return None, error
