from __future__ import annotations

import hashlib
import re
from datetime import date
from functools import lru_cache
from itertools import product
from typing import Any, Dict, Iterable, List, Optional, Set

import pydicom
from pydicom.dataelem import RawDataElement
from pydicom.datadict import (
    DicomDictionary,
    RepeatersDictionary,
    dictionary_VR,
    keyword_for_tag,
    tag_for_keyword,
)
from pydicom.multival import MultiValue
from pydicom.tag import Tag

from deidentify.normalise_dates import date_time_value_date
from deidentify.settings import (
    BURNED_IN_ANNOTATION_TAG,
    DEFAULT_ANCHOR_DATE,
    DEFAULT_DEID_ACCESSION_ECHO_TAGS,
    DEFAULT_DEID_ACCESSION_NUMBER_TAG,
    DEFAULT_DEID_ALLOWED_TAGS,
    DEFAULT_DEID_NHS_IDENTIFIER_TAGS,
    DEFAULT_DEID_PSEUDONYM_TAGS,
    DEFAULT_DEIDENTIFICATION_PROFILE_ID,
    DEIDENTIFICATION_METHOD_TAG,
    PATIENT_IDENTITY_REMOVED_VALUE,
    DEFAULT_DEID_PRESERVE_TAGS,
    DEFAULT_DEID_RETAINED_TIME_TAGS,
    DICOM_READ_DEFER_SIZE,
    DicomTag,
    PATIENT_IDENTITY_REMOVED_TAG,
    PIXEL_DATA_TAG,
    SHIFTED_DATE_VRS,
    default_deid_remove_group,
)
from deidentify.uids import is_pseudonymous_uid, uid_requires_remapping
from id_generation.generate_pharos_id import identifier_form

_NHS_RE = re.compile(r"\b\d{3}[ -]?\d{3}[ -]?\d{4}\b")
_PUBLIC_BINARY_VRS = {"OB", "OD", "OF", "OL", "OV", "OW", "UN"}
_MAX_PRIVATE_TEXT_AUDIT_CHARS = 512
# These are invalid/non-tag fields shipped by the pinned deid recipe. They are
# tolerated only at the external adapter; any other unresolved exact field is
# treated as policy drift and fails the audit closed.
_KNOWN_NON_TAG_DEID_RECIPE_FIELDS = frozenset({"PatientsName", "jitter"})
_PINNED_DEID_RECIPE_SELECTORS = frozenset({
    "endswith:Time",
    "endswith:Date",
    "endswith:time",
    "startswith:IssueDate",
    "contains:Trial",
    "startswith:PatientTelephoneNumber",
    "endswith:ID",
    "endswith:IDs",
    "contains:UID",
})
_PINNED_DEID_RECIPE_REMOVE_FIELD_COUNT = 66
_PINNED_DEID_RECIPE_REMOVE_FIELDS_SHA256 = (
    "2df2c8a1dfa9fab6065c27db25861cd645e0734cb7ec9d97c5e671985672ea3d"
)
_CANONICAL_NON_REMOVAL_VRS = SHIFTED_DATE_VRS | frozenset({"UI"})
_NAME_ID_SELECTORS = frozenset({"endswith:ID", "endswith:IDs"})
_STRUCTURAL_NUMERIC_VRS = frozenset({"US", "UL", "SS", "SL", "UV", "SV"})


def _tag_tuple(tag: Any) -> DicomTag:
    dicom_tag = Tag(tag)
    return dicom_tag.group, dicom_tag.element


def _canonical_tag_set(tags: Iterable[Any]) -> set[DicomTag]:
    normalized = set()
    for tag in tags:
        if (
            not isinstance(tag, tuple)
            or len(tag) != 2
            or any(not isinstance(component, int) or isinstance(component, bool) for component in tag)
            or any(component < 0 or component > 0xFFFF for component in tag)
        ):
            raise ValueError(
                "allowed_tags entries must be (group, element) integer tuples"
            )
        normalized.add(tag)
    return normalized


def _tag_entry(tag: Any) -> str:
    dicom_tag = Tag(tag)
    keyword = keyword_for_tag(dicom_tag) or "?"
    return f"({dicom_tag.group:04x},{dicom_tag.element:04x}) {keyword}"


def _tag_name(tag: DicomTag) -> str:
    return keyword_for_tag(Tag(*tag)) or f"{tag[0]:04X},{tag[1]:04X}"


def _value_at_tag(ds: Any, tag: DicomTag) -> Any:
    elem = ds.get_item(Tag(*tag), keep_deferred=True)
    if isinstance(elem, RawDataElement):
        elem = ds[Tag(*tag)]
    return None if elem is None else elem.value


def _element_values(value: Any) -> tuple:
    """Return an element's values as a tuple, single- or multi-valued."""
    if isinstance(value, (MultiValue, list, tuple)):
        return tuple(value)
    return (value,)


def _uid_carries_source_identity(tag: DicomTag, value: Any) -> bool:
    """Whether a surviving UI element still holds an un-remapped source UID."""
    for item in _element_values(value):
        uid = str(item or "")
        if not uid or is_pseudonymous_uid(uid):
            continue
        if uid_requires_remapping(tag, uid):
            return True
    return False


def _has_value(elem) -> bool:
    value = elem.value
    if value is None:
        return False
    if elem.VR == "SQ" or isinstance(value, bytes):
        return bool(value)
    return str(value).strip() not in ("", "None")


def _private_tag_text(elem) -> Optional[str]:
    """Decode a bounded private-tag sample for pattern matching."""
    value = elem.value
    if isinstance(value, bytes):
        try:
            value = value[:_MAX_PRIVATE_TEXT_AUDIT_CHARS].decode(
                "utf-8",
                errors="ignore",
            )
        except Exception:
            return None
    text = str(value)[:_MAX_PRIVATE_TEXT_AUDIT_CHARS]
    text = text.strip().strip("\x00").strip()
    return text if text and text.isprintable() else None


def _recipe_selector_matches(
    selector: str,
    description: str,
    keyword: str,
) -> bool:
    # Case-sensitive: the recipe pins both "endswith:Time" and "endswith:time"
    # as distinct rules, and case-folding would additionally match keywords that
    # merely end in the letters of a selector, such as Grid for "endswith:ID".
    mode, expression = selector.split(":", 1)
    candidates = (description, keyword)
    if mode == "contains":
        return any(expression in candidate for candidate in candidates)
    if mode == "startswith":
        return any(candidate.startswith(expression) for candidate in candidates)
    if mode == "endswith":
        return any(candidate.endswith(expression) for candidate in candidates)
    return False


def _expand_repeater_tag(pattern: str) -> Iterable[DicomTag]:
    """Expand a pydicom repeater key into exact numeric tag tuples."""
    choices = (
        "0123456789ABCDEF" if character.casefold() == "x" else character
        for character in pattern
    )
    for digits in product(*choices):
        packed = int("".join(digits), 16)
        tag = Tag(packed)
        if not tag.is_private:
            yield tag.group, tag.element


def _recipe_selector_removes_vr(selector: str, vr: str) -> bool:
    """Apply local action precedence to external name selectors."""
    if selector.casefold() == "endswith:time":
        # Acquisition durations such as EchoTime and RepetitionTime are not
        # wall-clock identifiers and are required for downstream QC/reuse.
        return vr == "TM"
    if selector in _NAME_ID_SELECTORS and vr in _STRUCTURAL_NUMERIC_VRS:
        # A binary integer such as DisplaySubsystemID or GraphicGroupID is an
        # index linking elements inside one object, not an identifier of a
        # person, place, or device. Blanking it to zero length would break the
        # references that resolve display pipelines, annotations, and implant
        # components. Text-valued device identifiers still match the selector.
        return False
    return vr not in _CANONICAL_NON_REMOVAL_VRS


def _expand_deid_recipe_selector(selector: str) -> Set[DicomTag]:
    """Resolve one pinned external selector to canonical numeric removals."""
    tags: Set[DicomTag] = set()
    for packed, definition in DicomDictionary.items():
        vr, _, description, _, keyword = definition
        if (
            _recipe_selector_removes_vr(selector, vr)
            and _recipe_selector_matches(selector, description, keyword)
        ):
            tags.add((packed >> 16, packed & 0xFFFF))
    for pattern, definition in RepeatersDictionary.items():
        vr, _, description, _, keyword = definition
        if (
            _recipe_selector_removes_vr(selector, vr)
            and _recipe_selector_matches(selector, description, keyword)
        ):
            tags.update(_expand_repeater_tag(pattern))
    return tags


@lru_cache(maxsize=1)
def _deid_recipe_policy() -> tuple[
    frozenset[DicomTag],
    tuple[str, ...],
    bool,
]:
    """Normalize deid's external keyword recipe to numeric DICOM tags."""
    try:
        import os
        os.environ.setdefault("MESSAGELEVEL", "QUIET")
        from deid.config import DeidRecipe

        tags = set()
        unresolved = set()
        observed_selectors = set()
        actions = DeidRecipe().get_actions()
        remove_fields = {
            str(action.get("field", ""))
            for action in actions
            if action.get("action") == "REMOVE"
        }
        remove_fields_digest = hashlib.sha256(
            "\n".join(sorted(remove_fields)).encode("utf-8")
        ).hexdigest()
        if (
            len(remove_fields) != _PINNED_DEID_RECIPE_REMOVE_FIELD_COUNT
            or remove_fields_digest
            != _PINNED_DEID_RECIPE_REMOVE_FIELDS_SHA256
        ):
            unresolved.add("REMOVE action fingerprint mismatch")

        for action in actions:
            field = action.get("field", "")
            if action.get("action") != "REMOVE":
                continue
            if ":" in field:
                if field in _PINNED_DEID_RECIPE_SELECTORS:
                    observed_selectors.add(field)
                    tags.update(_expand_deid_recipe_selector(field))
                else:
                    unresolved.add(field)
                continue
            tag = tag_for_keyword(field)
            if tag is None:
                unresolved.add(field)
            elif dictionary_VR(tag) not in _CANONICAL_NON_REMOVAL_VRS:
                tags.add((tag >> 16, tag & 0xFFFF))
        unresolved.update(
            f"missing selector:{selector}"
            for selector in _PINNED_DEID_RECIPE_SELECTORS - observed_selectors
        )
        return frozenset(tags), tuple(sorted(unresolved)), True
    except Exception:
        return frozenset(), (), False


def _deid_recipe_removal_tags() -> frozenset[DicomTag]:
    return _deid_recipe_policy()[0]


def audit_deidentification(
    headers: Iterable[Any],
    allowed_tags: Iterable[DicomTag] = None,
    anchor_date: date = DEFAULT_ANCHOR_DATE,
) -> Dict[str, Any]:
    """Audit recursively against the canonical removal policy and detectors.

    Anything the writer would have to transform is identifiable: removal-policy
    values, UIDs still carrying source identity, and DA/DT values never shifted
    onto ``anchor_date``.
    """
    headers = list(headers)
    allowed = _canonical_tag_set(
        DEFAULT_DEID_ALLOWED_TAGS if allowed_tags is None else allowed_tags
    )
    # The fixed profile outranks the supplementary recipe: what it retains for
    # reuse, including the times normalisation keeps, is never a finding.
    allowed.update(DEFAULT_DEID_PRESERVE_TAGS)
    allowed.update(DEFAULT_DEID_RETAINED_TIME_TAGS)
    recipe_tags = _deid_recipe_removal_tags()
    _, unresolved_recipe_fields, recipe_loaded = _deid_recipe_policy()
    recipe_policy_available = recipe_loaded and set(
        unresolved_recipe_fields
    ).issubset(_KNOWN_NON_TAG_DEID_RECIPE_FIELDS)
    groups: Dict[str, Set[str]] = {}
    fixed_removal_tags: Set[str] = set()
    supplementary_recipe_tags: Set[DicomTag] = set()
    allowed_present: Set[str] = set()
    actionable_tags: Set[DicomTag] = set()
    original_uid_entries: Set[str] = set()
    date_time_entries: Set[str] = set()
    earliest_date: Optional[date] = None
    private_text: Dict[DicomTag, str] = {}
    uninspected_private_tags: Dict[DicomTag, str] = {}
    private_tag_count = 0

    def audit_dataset(ds: Any) -> None:
        nonlocal private_tag_count, earliest_date
        for tag in sorted(ds.keys()):
            tag_key = _tag_tuple(tag)
            if tag_key == PIXEL_DATA_TAG:
                continue
            if tag.element == 0:
                continue

            entry = _tag_entry(tag)
            elem = ds.get_item(tag, keep_deferred=True)
            vr = getattr(elem, "VR", None)
            if isinstance(elem, RawDataElement) and vr is None:
                try:
                    vr = dictionary_VR(tag)
                except KeyError:
                    vr = None
            category = default_deid_remove_group(tag_key)
            if category is not None:
                fixed_removal_tags.add(entry)
                actionable_tags.add(tag_key)
                if isinstance(elem, RawDataElement):
                    # Presence and encoded length are enough for the audit. A
                    # fixed rule deletes the whole element, so materialising a
                    # deferred SQ or binary payload would add cost and could
                    # expose content that is about to be pruned.
                    populated = bool(elem.length and elem.length > 0)
                else:
                    populated = elem is not None and _has_value(elem)
                if populated:
                    groups.setdefault(category, set()).add(entry)
                # The writer deletes a configured SQ as one unit, so report it
                # once without reading or exposing its children.
                continue

            if isinstance(elem, RawDataElement):
                if tag.is_private:
                    private_tag_count += 1
                    if elem.length and elem.length > 0:
                        uninspected_private_tags.setdefault(
                            tag_key,
                            f"{entry} VR={vr or '?'} length={elem.length}",
                        )
                    # A deferred private value may be arbitrarily large and its
                    # schema is unknown. Never materialise it for a QC report.
                    continue
                if vr == "SQ" and elem.length > 0 and tag_key in recipe_tags:
                    if tag_key in allowed:
                        allowed_present.add(entry)
                    else:
                        supplementary_recipe_tags.add(tag_key)
                        actionable_tags.add(tag_key)
                        continue
                if not tag.is_private and vr in _PUBLIC_BINARY_VRS:
                    if elem.length > 0 and tag_key in recipe_tags:
                        if tag_key in allowed:
                            allowed_present.add(entry)
                        else:
                            supplementary_recipe_tags.add(tag_key)
                            actionable_tags.add(tag_key)
                    continue
                elem = ds[tag]
                vr = getattr(elem, "VR", vr)
            if elem is None:
                continue

            if tag.is_private:
                private_tag_count += 1
                if vr == "SQ":
                    for item in elem.value or ():
                        audit_dataset(item)
                elif _has_value(elem):
                    text = _private_tag_text(elem)
                    if text:
                        private_text.setdefault(tag_key, text)
                continue

            if vr == "SQ":
                if _has_value(elem) and tag_key in recipe_tags:
                    if tag_key in allowed:
                        allowed_present.add(entry)
                    else:
                        supplementary_recipe_tags.add(tag_key)
                        actionable_tags.add(tag_key)
                        continue
                for item in elem.value or ():
                    audit_dataset(item)
                continue
            if vr in _PUBLIC_BINARY_VRS:
                if _has_value(elem) and tag_key in recipe_tags:
                    if tag_key in allowed:
                        allowed_present.add(entry)
                    else:
                        supplementary_recipe_tags.add(tag_key)
                        actionable_tags.add(tag_key)
                continue
            if not _has_value(elem):
                continue

            # Remapping and shifting replace a value in place, so allowed_tags
            # cannot exempt them and they are not blank/remove actions.
            if vr == "UI":
                if _uid_carries_source_identity(tag_key, elem.value):
                    original_uid_entries.add(entry)
                continue
            if vr in SHIFTED_DATE_VRS:
                date_time_entries.add(entry)
                for value in _element_values(elem.value):
                    parsed = date_time_value_date(value, vr)
                    if parsed is not None and (
                        earliest_date is None or parsed < earliest_date
                    ):
                        earliest_date = parsed
                continue

            if tag_key in allowed:
                allowed_present.add(entry)
                continue
            if tag_key in recipe_tags:
                supplementary_recipe_tags.add(tag_key)
                actionable_tags.add(tag_key)

    for header in headers:
        audit_dataset(header)

    # Normalisation moves a study's earliest surviving date onto the anchor, so
    # any other earliest date means these values still carry their real dates.
    dates_normalised = earliest_date is None or earliest_date == anchor_date
    if original_uid_entries:
        groups["original_uids"] = original_uid_entries
    if date_time_entries and not dates_normalised:
        groups["unnormalised_dates"] = date_time_entries

    additional_by_deid = sorted(_tag_name(tag) for tag in supplementary_recipe_tags)

    accession_echo_tags: List[DicomTag] = []
    acc = next(
        (
            str(_value_at_tag(header, DEFAULT_DEID_ACCESSION_NUMBER_TAG) or "")
            for header in headers
            if _value_at_tag(header, DEFAULT_DEID_ACCESSION_NUMBER_TAG)
        ),
        "",
    )
    if acc:
        for tag in DEFAULT_DEID_ACCESSION_ECHO_TAGS:
            if any(
                acc and acc in str(_value_at_tag(header, tag) or "")
                for header in headers
            ):
                accession_echo_tags.append(tag)
                actionable_tags.add(tag)
    accession_echo = sorted(_tag_name(tag) for tag in accession_echo_tags)

    possible_nhs = any(
        _NHS_RE.search(str(_value_at_tag(header, tag) or ""))
        for header in headers
        for tag in DEFAULT_DEID_NHS_IDENTIFIER_TAGS
    ) or any(_NHS_RE.search(text) for text in private_text.values())
    burned_in = any(
        str(_value_at_tag(header, BURNED_IN_ANNOTATION_TAG) or "").upper()
        == "YES"
        for header in headers
    )
    identity_removed = next(
        (
            str(_value_at_tag(header, PATIENT_IDENTITY_REMOVED_TAG)).upper()
            for header in headers
            if _value_at_tag(header, PATIENT_IDENTITY_REMOVED_TAG)
        ),
        None,
    )

    # A pseudonym tag holds the study identifier on purpose, so the
    # supplementary recipe flagging it is not a finding — but only in a file
    # that declares this profile. Without that declaration the value is an
    # ordinary residual identifier and must still be reported, or the audit
    # would pass raw data whose PatientID was never touched.
    def _declares_profile(header: Any) -> bool:
        value = _value_at_tag(header, DEIDENTIFICATION_METHOD_TAG)
        if value is None:
            return False
        # DeidentificationMethod is multi-valued whenever the source already
        # declared a method and this profile was appended to it. pydicom
        # returns a MultiValue, which is a sequence but not a list or tuple.
        if isinstance(value, (str, bytes)):
            values = [value]
        else:
            try:
                values = list(value)
            except TypeError:
                values = [value]
        return DEFAULT_DEIDENTIFICATION_PROFILE_ID in [str(v) for v in values]

    profile_declared = (
        identity_removed == PATIENT_IDENTITY_REMOVED_VALUE
        and all(_declares_profile(header) for header in headers)
    )
    # Presence is not enough: the value must be one this pipeline emits. A
    # populated PatientID that is not an identifier is a residual value however
    # the file describes itself.
    pseudonym_tags_present: Dict[str, str] = {}
    if profile_declared:
        for tag in sorted(supplementary_recipe_tags & DEFAULT_DEID_PSEUDONYM_TAGS):
            forms = {
                identifier_form(_value_at_tag(header, tag))
                for header in headers
                if _value_at_tag(header, tag) is not None
            }
            if forms and None not in forms and len(forms) == 1:
                pseudonym_tags_present[_tag_name(tag)] = forms.pop()
        additional_by_deid = [
            name for name in additional_by_deid
            if name not in pseudonym_tags_present
        ]

    present = {g: sorted(v) for g, v in groups.items()}
    return {
        "identifiers_present": present,
        "fixed_removal_tags_present": sorted(fixed_removal_tags),
        "actionable_tags": sorted(actionable_tags),
        # This is intentionally scoped to the shared removal policy. A
        # stand-alone header audit cannot prove that dates were shifted or UIDs
        # were HMAC-remapped; the writer verifies those source/output mappings.
        "removal_policy_compliant": (
            not fixed_removal_tags if recipe_policy_available else None
        ),
        "allowed_present": sorted(allowed_present),
        "additional_flagged_by_deid": additional_by_deid,
        "pseudonym_tags_present": pseudonym_tags_present,
        "pseudonym_identifiers_weak": sorted(
            name for name, form in pseudonym_tags_present.items()
            if form == "hash_segment"
        ),
        "deid_recipe_loaded": recipe_loaded,
        "supplementary_policy_available": recipe_policy_available,
        "audit_complete": recipe_policy_available,
        "unresolved_deid_recipe_fields": list(unresolved_recipe_fields),
        "accession_number_echoed_in": accession_echo,
        "original_uids_present": bool(original_uid_entries),
        "dates_normalised": dates_normalised,
        "possible_nhs_number": possible_nhs,
        "burned_in_annotation": burned_in,
        "private_tag_count": private_tag_count,
        "private_tags_with_text": sorted(
            f"({_tag[0]:04x},{_tag[1]:04x}) {text}"
            for _tag, text in private_text.items()
        ),
        "private_text_tags": sorted(private_text),
        "uninspected_private_tag_details": sorted(
            uninspected_private_tags.values()
        ),
        "uninspected_private_tags": sorted(uninspected_private_tags),
        "patient_identity_removed_flag": identity_removed,
        "deidentified": (
            recipe_policy_available
            and not present
            and not additional_by_deid
            and not possible_nhs
            and not accession_echo
            and not private_text
            and not uninspected_private_tags
        ),
    }


def audit_deidentification_files(
    paths: Iterable[Any],
    allowed_tags: Iterable[DicomTag] = None,
    anchor_date: date = DEFAULT_ANCHOR_DATE,
) -> Dict[str, Any]:
    """Audit complete DICOM element streams while deferring bulk payloads.

    Header-only reads and extracted-metadata caches omit sequences, binary
    values, and elements serialized after Pixel Data. The QC pipeline therefore
    uses this file-backed entry point for a complete removal-policy scan.
    """
    datasets = []
    parse_failure_count = 0
    for path in paths:
        try:
            datasets.append(
                pydicom.dcmread(path, defer_size=DICOM_READ_DEFER_SIZE)
            )
        except Exception:
            parse_failure_count += 1

    result = audit_deidentification(
        datasets,
        allowed_tags=allowed_tags,
        anchor_date=anchor_date,
    )
    result["audit_complete"] = (
        parse_failure_count == 0
        and result["supplementary_policy_available"]
    )
    result["audit_parse_failure_count"] = parse_failure_count
    if not result["audit_complete"]:
        # Absence cannot be asserted from a partial scan or unavailable policy.
        # Do not include raw paths because they can themselves contain PHI.
        result["removal_policy_compliant"] = None
        result["deidentified"] = False
    return result
