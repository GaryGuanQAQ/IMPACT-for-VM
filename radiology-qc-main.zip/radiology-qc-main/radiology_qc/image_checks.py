from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np

from radiology_qc.anatomy import VOLUMETRIC_MODALITIES
from radiology_qc.settings import QCSettings


def evaluate_clipping(coverage: Optional[Dict[str, float]],
                      faces: List[str], threshold: float,
                      plane: Optional[str] = None,
                      valid_planes: Optional[List[str]] = None) -> Dict:
    """Flag configured faces whose body coverage exceeds the threshold."""
    if not coverage:
        return {"clipping_suspected": False, "clipped_faces": [], "coverage": None}
    cov = {k: round(v, 3) for k, v in coverage.items()}
    if valid_planes is not None and plane not in valid_planes:
        return {"clipping_suspected": False, "clipped_faces": [], "coverage": cov,
                "note": f"clipping not evaluated for {plane} acquisition (faces not air-bounded)"}
    clipped = [f for f in faces if coverage.get(f, 0.0) > threshold]
    return {"clipping_suspected": bool(clipped), "clipped_faces": clipped, "coverage": cov}


def validate_image_quality(body: Optional[Dict[str, Any]], *,
                           modality: str, is_derived: bool, decoded_slices: int,
                           plane: Optional[str], profile: Dict[str, Any],
                           settings: QCSettings) -> Dict[str, Any]:
    """Apply model-free image-quality thresholds."""
    non_volume = bool(modality in VOLUMETRIC_MODALITIES and not is_derived
                      and decoded_slices < settings.min_volume_slices)
    if body is None:
        return {
            "low_signal": False,
            "noise_suspected": False,
            "non_volume": non_volume,
            "clipping": {"clipping_suspected": False, "clipped_faces": [], "coverage": None},
        }
    ms = body["max_structure"]
    return {
        "low_signal": bool(body["max_foreground"] < settings.low_signal_max_foreground),
        "noise_suspected": bool(np.isfinite(ms) and ms < settings.min_spatial_structure),
        "non_volume": non_volume,
        "clipping": evaluate_clipping(
            body["faces"], profile["clipping_faces"], profile["clipping_threshold"],
            plane=plane, valid_planes=profile.get("clipping_planes")),
    }
