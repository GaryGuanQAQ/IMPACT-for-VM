import logging
from typing import Optional
import numpy as np
import pydicom

from radiology_qc.settings import DEFAULT_SETTINGS, QCSettings

logger = logging.getLogger(__name__)


def _reduce_to_2d(pixels: np.ndarray, settings: QCSettings) -> Optional[np.ndarray]:
    """Convert colour to luminance and reject unsupported frame shapes."""
    if pixels.ndim == 2:
        return pixels
    if pixels.ndim == 3 and pixels.shape[-1] in (3, 4):
        rgb = pixels[..., :3].astype(float)
        return rgb @ np.array(settings.luminance_weights)
    return None


def get_normalised_pixel_data(ds: pydicom.dataset.Dataset,
                              settings: Optional[QCSettings] = None) -> np.ndarray:
    """Return 0-1 grayscale pixels, or an empty array if unsupported."""
    settings = settings or DEFAULT_SETTINGS
    try:
        photometric = getattr(ds, "PhotometricInterpretation", "MONOCHROME2")
        pixels = _reduce_to_2d(ds.pixel_array, settings)
        if pixels is None:
            logger.warning(
                "Unsupported pixel geometry %s (%s) in %s; skipping image checks",
                getattr(ds, "pixel_array", np.array([])).shape,
                photometric,
                getattr(ds, "SOPInstanceUID", "UNKNOWN"),
            )
            return np.array([])
        pixels = pixels.astype(float)

        slope = float(getattr(ds, "RescaleSlope", 1))
        intercept = float(getattr(ds, "RescaleIntercept", 0))
        pixels = pixels * slope + intercept

        if photometric == "MONOCHROME1":
            pixels = np.max(pixels) - pixels

        p_min, p_max = np.min(pixels), np.max(pixels)
        if p_max == p_min:
            return np.zeros_like(pixels)

        return (pixels - p_min) / (p_max - p_min)

    except (AttributeError, ValueError, RuntimeError, ImportError):
        return np.array([])
