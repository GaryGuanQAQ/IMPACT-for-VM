from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import numpy as np
from skimage.exposure import equalize_hist
from skimage.filters import threshold_otsu
from skimage.measure import label
from skimage.morphology import convex_hull_image
from scipy.ndimage import binary_fill_holes

from radiology_qc.settings import DEFAULT_MIN_VOLUME_SLICES, DEFAULT_SETTINGS, QCSettings

logger = logging.getLogger(__name__)


def tissue_fraction(pixels: np.ndarray,
                    settings: Optional[QCSettings] = None) -> float:
    """Return the fraction above the robust background threshold."""
    settings = settings or DEFAULT_SETTINGS
    if pixels.size == 0:
        return 0.0
    median = np.median(pixels)
    mad = np.median(np.abs(pixels - median))
    if mad == 0:
        return float(np.mean(pixels > median))
    threshold = median + settings.tissue_sigma_multiplier * settings.mad_to_sigma * mad
    return float(np.mean(pixels > threshold))


def _foreground(img: np.ndarray):
    """Return MRQy foreground and background pixels."""
    try:
        h = equalize_hist(img) * 255
        oi = (img > threshold_otsu(img)).astype(np.uint8)
        oh = (h > threshold_otsu(h)).astype(np.uint8)
        nm = img.shape[0] * img.shape[1]
        w1, w2 = oi.sum() / nm, oh.sum() / nm
        combined = w1 * img + w2 * h
        ots = (combined > threshold_otsu(combined)).astype(np.uint8)
        ch = convex_hull_image(ots)
    except Exception:
        return img.ravel(), np.zeros(1)
    f, b = img[ch], img[~ch]
    if f.size == 0 or b.size == 0:
        return img.ravel(), np.zeros(1)
    return f, b


def _cjv(img: np.ndarray) -> float:
    f, b = _foreground(img)
    denom = abs(np.nanmean(f) - np.nanmean(b))
    if denom == 0:
        return float("nan")
    return float((np.nanstd(f) + np.nanstd(b)) / denom)


def _is_informative(img: np.ndarray, settings: QCSettings) -> bool:
    """Return whether a slice has enough signal for CJV."""
    if img.size == 0:
        return False
    med = np.median(img)
    mad = np.median(np.abs(img - med)) + 1e-9
    threshold = med + settings.tissue_sigma_multiplier * settings.mad_to_sigma * mad
    return bool((img > threshold).mean() >= settings.min_informative_fraction)


def series_cjv(slices: List[np.ndarray], min_slices: int = DEFAULT_MIN_VOLUME_SLICES,
               settings: Optional[QCSettings] = None) -> Dict:
    """Return mean CJV, or None when too few slices are informative."""
    settings = settings or DEFAULT_SETTINGS
    vals = [_cjv(s) for s in slices if _is_informative(s, settings)]
    vals = [v for v in vals if np.isfinite(v)]
    n = len(vals)
    return {
        "cjv": float(np.mean(vals)) if n >= min_slices else None,
        "n_informative": n,
    }


def body_mask(img: np.ndarray) -> np.ndarray:
    """Largest connected foreground component, holes filled -> body vs air."""
    if img.size == 0 or img.max() == img.min():
        return np.zeros_like(img, dtype=bool)
    try:
        fg = img > threshold_otsu(img)
    except Exception:
        return np.zeros_like(img, dtype=bool)
    lab = label(fg)
    if lab.max() == 0:
        return fg
    sizes = np.bincount(lab.ravel())
    sizes[0] = 0
    return binary_fill_holes(lab == sizes.argmax())


def spatial_autocorrelation(img: np.ndarray) -> float:
    """Return mean horizontal and vertical lag-1 autocorrelation."""
    if img.size < 4:
        return float("nan")

    def _corr(x, y):
        x = x - x.mean()
        y = y - y.mean()
        denom = np.sqrt((x * x).sum() * (y * y).sum())
        return (x * y).sum() / denom if denom > 0 else np.nan

    vals = [c for c in (_corr(img[:, :-1].ravel(), img[:, 1:].ravel()),
                        _corr(img[:-1, :].ravel(), img[1:, :].ravel())) if np.isfinite(c)]
    return float(np.mean(vals)) if vals else float("nan")


def analyse_body(sampled: List[np.ndarray],
                 first_slice: Optional[np.ndarray],
                 last_slice: Optional[np.ndarray]) -> Dict[str, Any]:
    """Derive face coverage, foreground, and structure from body masks."""
    masks = [body_mask(s) for s in sampled if s.size]
    masks = [m for m in masks if masks and m.shape == masks[0].shape]
    max_foreground = max((float(m.mean()) for m in masks), default=0.0)
    foreground_coverage = float(np.mean([m.mean() for m in masks])) if masks else None
    structures = [spatial_autocorrelation(s) for s in sampled if s.size]
    structures = [v for v in structures if np.isfinite(v)]
    max_structure = max(structures) if structures else float("nan")
    faces = None
    if masks:
        fm = body_mask(first_slice) if first_slice is not None and first_slice.size else None
        lm = body_mask(last_slice) if last_slice is not None and last_slice.size else None
        faces = {
            "top": float(np.mean([m[0, :].mean() for m in masks])),
            "bottom": float(np.mean([m[-1, :].mean() for m in masks])),
            "left": float(np.mean([m[:, 0].mean() for m in masks])),
            "right": float(np.mean([m[:, -1].mean() for m in masks])),
            "first_slice": float(fm.mean()) if fm is not None else 0.0,
            "last_slice": float(lm.mean()) if lm is not None else 0.0,
        }
    return {"faces": faces, "max_foreground": max_foreground,
            "foreground_coverage": foreground_coverage, "max_structure": max_structure}
