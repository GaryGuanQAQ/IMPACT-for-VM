import logging
from typing import Dict, List, Optional, Sequence, Any
import numpy as np
import pydicom

from radiology_qc.settings import DEFAULT_MANDATORY_TAGS

logger = logging.getLogger(__name__)


def _slice_normal(ds: Any) -> np.ndarray:
    """Return the unit slice normal, defaulting to the patient Z-axis."""
    iop = getattr(ds, "ImageOrientationPatient", None)
    if iop is not None and len(iop) == 6:
        row = np.array([float(x) for x in iop[:3]])
        col = np.array([float(x) for x in iop[3:]])
        normal = np.cross(row, col)
        norm = np.linalg.norm(normal)
        if norm > 0:
            return normal / norm
    return np.array([0.0, 0.0, 1.0])


def calculate_slice_gap(datasets: List[Any]) -> float:
    """Calculate mean spacing along the slice normal."""
    positions = []
    normals = []
    for ds in datasets:
        ipp = getattr(ds, "ImagePositionPatient", None)
        if ipp is None or len(ipp) < 3:
            continue
        try:
            positions.append(np.array([float(x) for x in ipp[:3]]))
            normals.append(_slice_normal(ds))
        except (TypeError, ValueError):
            continue

    if len(positions) < 2:
        return 0.0

    mean_normal = np.mean(normals, axis=0)
    norm = np.linalg.norm(mean_normal)
    mean_normal = mean_normal / norm if norm > 0 else np.array([0.0, 0.0, 1.0])

    projections = sorted(float(np.dot(p, mean_normal)) for p in positions)
    gaps = np.diff(projections)
    return float(np.abs(np.mean(gaps)))


def _is_populated(ds: Any, tag: str) -> bool:
    """A tag counts as valid only when present *and* carrying a non-empty value."""
    if tag not in ds:
        return False
    value = getattr(ds, tag, None)
    if value is None:
        return False
    if isinstance(value, (str, bytes)):
        return len(value.strip()) > 0 if isinstance(value, str) else len(value) > 0
    if isinstance(value, (list, tuple, pydicom.multival.MultiValue)):
        return len(value) > 0
    return True


def get_device_metadata(ds: pydicom.dataset.FileDataset) -> Dict[str, str]:
    """Return acquisition-device fields used for batch grouping."""
    def _s(tag: str, default: str = "UNKNOWN") -> str:
        value = getattr(ds, tag, None)
        if value is None:
            return default
        if isinstance(value, (list, tuple, pydicom.multival.MultiValue)):
            value = "/".join(str(v) for v in value)
        value = str(value).strip()
        return value if value else default

    return {
        "manufacturer": _s("Manufacturer"),
        "model": _s("ManufacturerModelName"),
        "station_name": _s("StationName"),
        "software_versions": _s("SoftwareVersions"),
        "magnetic_field_strength": _s("MagneticFieldStrength", "N/A"),
    }


def get_acquisition_parameters(headers: List[Any]) -> Dict[str, Any]:
    """Return populated series parameters and mark values that vary."""
    def _one(tag: str):
        seen: List[str] = []
        for h in headers:
            v = getattr(h, tag, None)
            if v is None:
                continue
            if isinstance(v, (list, tuple, pydicom.multival.MultiValue)):
                v = "/".join(str(x) for x in v)
            s = str(v).strip()
            if s and s not in seen:
                seen.append(s)
        if not seen:
            return None
        return seen[0] if len(seen) == 1 else {"variable": sorted(seen)}

    fields = {
        "pixel_spacing_mm": _one("PixelSpacing") or _one("ImagerPixelSpacing"),
        "slice_thickness_mm": _one("SliceThickness"),
        "spacing_between_slices_mm": _one("SpacingBetweenSlices"),
        "convolution_kernel": _one("ConvolutionKernel"),
        "kvp": _one("KVP"),
        "echo_time_ms": _one("EchoTime"),
        "repetition_time_ms": _one("RepetitionTime"),
        "inversion_time_ms": _one("InversionTime"),
        "flip_angle_deg": _one("FlipAngle"),
        "magnetic_field_strength_T": _one("MagneticFieldStrength"),
    }
    return {k: v for k, v in fields.items() if v is not None}


def validate_mandatory_tags(
    ds: pydicom.dataset.FileDataset,
    mandatory_tags: Optional[Sequence[str]] = None,
) -> Dict[str, bool]:
    """Check that required DICOM tags are present and populated."""
    tags = DEFAULT_MANDATORY_TAGS if mandatory_tags is None else mandatory_tags
    return {tag: _is_populated(ds, tag) for tag in tags}


def validate_clinical_context(ds: pydicom.dataset.FileDataset) -> Dict[str, bool]:
    """Validate laterality and modality-specific view positions."""
    results = {
        "laterality_valid": False,
        "view_position_valid": True
    }

    laterality = getattr(ds, "ImageLaterality", None)
    if laterality in ["L", "R", "B"]:
        results["laterality_valid"] = True

    if getattr(ds, "Modality", None) == "MG":
        view = getattr(ds, "ViewPosition", None)
        results["view_position_valid"] = view in ["CC", "MLO"]

    return results


POSITIONED_STACK = "POSITIONED_STACK"
MULTIFRAME = "MULTIFRAME"
CAPTURE_SET = "CAPTURE_SET"

# Why a gap in the InstanceNumber sequence does or does not mean a lost image.
INSTANCE_ORDERING_REASONS: Dict[str, str] = {
    POSITIONED_STACK: "positioned stack, so a gap is a missing image",
    MULTIFRAME: "multi-frame objects, so instances are loops rather than samples",
    CAPTURE_SET: "independent captures, so a gap is usually a deleted image",
}


def classify_instance_ordering(instances: List[Any]) -> str:
    """Decide whether InstanceNumber is this series' sampling axis.

    Only then is a gap evidence of a lost image. Modality is deliberately not
    consulted: it would class a position-tracked ultrasound sweep, which is a
    stack of images like any volume, with a gallery of unrelated stills.
    """
    for ds in instances:
        try:
            if int(getattr(ds, "NumberOfFrames", 1) or 1) > 1:
                # Tested first: an Enhanced US Volume carries position in
                # per-frame functional groups, not top-level ImagePositionPatient.
                return MULTIFRAME
        except (TypeError, ValueError):
            continue

    positioned = 0
    for ds in instances:
        ipp = getattr(ds, "ImagePositionPatient", None)
        if ipp is None or len(ipp) < 3:
            continue
        try:
            [float(x) for x in ipp[:3]]
        except (TypeError, ValueError):
            continue
        positioned += 1

    return POSITIONED_STACK if positioned >= 2 else CAPTURE_SET


def validate_series_integrity(instances: List[pydicom.dataset.FileDataset]) -> Dict[str, Any]:
    """Check instance counts and InstanceNumber continuity.

    `contiguity_valid` is tri-state; None means the check could not run, not
    that it failed. Continuity spans the numbers actually present, since DICOM
    does not require a series to start at 1.
    """
    if not instances:
        return {
            "completeness_valid": False,
            "contiguity_valid": None,
            "instance_ordering": CAPTURE_SET,
            "instance_number_range": None,
            "expected_instances": "MISSING",
            "actual_instances": 0,
            "missing_instance_numbers": 0,
        }

    instance_numbers = []
    missing_instance_numbers = 0
    for ds in instances:
        raw = getattr(ds, "InstanceNumber", None)
        if raw is None or str(raw).strip() == "":
            missing_instance_numbers += 1
            continue
        try:
            instance_numbers.append(int(raw))
        except (ValueError, TypeError):
            missing_instance_numbers += 1

    instance_numbers.sort()

    # None rather than False when unnumbered instances leave nothing to assess.
    is_contiguous: Optional[bool] = None
    number_range = None
    if instance_numbers:
        number_range = [instance_numbers[0], instance_numbers[-1]]
        if missing_instance_numbers == 0:
            expected_sequence = list(range(number_range[0], number_range[1] + 1))
            is_contiguous = instance_numbers == expected_sequence

    expected_count_raw = getattr(instances[0], "NumberOfSeriesRelatedInstances", None)
    actual_count = len(instances)

    expected_instances: Any = "MISSING"
    if expected_count_raw is not None:
        try:
            expected_instances = int(expected_count_raw)
            completeness_valid = (actual_count == expected_instances)
        except (ValueError, TypeError):
            # Present but unparseable: no expectation to compare against.
            completeness_valid = False
    else:
        completeness_valid = is_contiguous is True

    return {
        "completeness_valid": completeness_valid,
        "contiguity_valid": is_contiguous,
        "instance_ordering": classify_instance_ordering(instances),
        "instance_number_range": number_range,
        "expected_instances": expected_instances,
        "actual_instances": actual_count,
        "missing_instance_numbers": missing_instance_numbers,
    }


def validate_geometry(ds: pydicom.dataset.FileDataset) -> Dict[str, Any]:
    """Check PixelAspectRatio for geometric distortion."""
    aspect_ratio = getattr(ds, "PixelAspectRatio", [1, 1])
    spacing = getattr(ds, "PixelSpacing", [1.0, 1.0])

    ratio = float(aspect_ratio[0]) / float(aspect_ratio[1])

    return {
        "pixel_aspect_ratio": [int(a) for a in aspect_ratio],
        "pixel_spacing": [float(s) for s in spacing],
        "is_geometrically_distorted": not np.isclose(ratio, 1.0, atol=1e-3)
    }
