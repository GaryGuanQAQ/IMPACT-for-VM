from collections import Counter, defaultdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Mapping, Optional

import numpy as np

from radiology_qc.metadata_checks import INSTANCE_ORDERING_REASONS, POSITIONED_STACK
from radiology_qc.settings import (
    DEFAULT_QC_SCOPE,
    DEFAULT_SEVERITY_WEIGHTS, SEVERITY_TIERS, QCSettings,
)

SEVERITY_ORDER = list(SEVERITY_TIERS)
SEVERITY_WEIGHTS = DEFAULT_SEVERITY_WEIGHTS


def _issue(code: str, severity: str, scope: str, detail: str) -> Dict[str, str]:
    return {"code": code, "severity": severity, "scope": scope, "detail": detail}


def _worse(a: str, b: str) -> str:
    return a if SEVERITY_ORDER.index(a) >= SEVERITY_ORDER.index(b) else b


def assess_study(report: Dict[str, Any],
                 settings: Optional[QCSettings] = None,
                 scope: str = DEFAULT_QC_SCOPE) -> Dict[str, Any]:
    """Derive a prioritised list of issues + an overall tier/score for one study.

    `scope` decides what residual identifiers mean. Before de-identification
    they are the expected starting condition and are reported as an inventory;
    in an export they are a release blocker.
    """
    settings = settings or QCSettings()
    issues: List[Dict[str, str]] = []

    unreadable = report.get("unreadable_files", [])
    if unreadable:
        issues.append(_issue(
            "UNREADABLE_FILES", "CRITICAL", "study",
            f"{len(unreadable)} file(s) could not be parsed as DICOM"))

    deid = report.get("deidentification", {}) or {}
    if deid and not deid.get("deidentified", True):
        why = []
        identifiers_present = deid.get("identifiers_present", {})
        if identifiers_present.get("patient"):
            why.append("patient identifier(s)")
        if identifiers_present.get("original_uids"):
            why.append("original UID(s)")
        if identifiers_present.get("unnormalised_dates"):
            why.append("un-normalised date(s)")
        if deid.get("possible_nhs_number"):
            why.append("possible NHS number")
        if deid.get("accession_number_echoed_in"):
            why.append("accession number echoed in workflow IDs")
        if scope == "internal":
            # Pre-de-identification this is what the writer is for, not a defect.
            issues.append(_issue(
                "PRE_DEID_IDENTIFIERS", "LOW", "study",
                f"identifiers present, to be removed by de-identification: "
                f"{', '.join(why) or 'residual identifiers present'}"))
        else:
            issues.append(_issue(
                "RESIDUAL_PHI", "CRITICAL", "study",
                f"not de-identified: {', '.join(why) or 'residual identifiers present'}"))

    proto = report.get("protocol_validation", {}) or {}
    if not proto.get("is_diagnostic_complete", True):
        missing = proto.get("missing_elements", [])
        issues.append(_issue(
            "PROTOCOL_INCOMPLETE", "HIGH", "study",
            f"missing required element(s): {missing}"))

    for s in report.get("series", []):
        sd = s.get("series_description", "?")
        integ = s.get("series_integrity", {}) or {}

        if s.get("failed_image_reads"):
            issues.append(_issue(
                "PIXEL_DECODE_FAILURE", "CRITICAL", "series",
                f"{sd}: {len(s['failed_image_reads'])} slice(s) with undecodable pixels"))

        expected, actual = integ.get("expected_instances"), integ.get("actual_instances")
        if isinstance(expected, int) and isinstance(actual, int) and actual != expected:
            severity = "CRITICAL" if actual < expected else "HIGH"
            issues.append(_issue(
                "SLICE_COUNT_MISMATCH", severity, "series",
                f"{sd}: {actual} instances present vs {expected} expected"))

        ordering = integ.get("instance_ordering", POSITIONED_STACK)
        if integ.get("missing_instance_numbers", 0) > 0:
            issues.append(_issue(
                "MISSING_INSTANCE_NUMBERS", "HIGH", "series",
                f"{sd}: {integ['missing_instance_numbers']} slice(s) without InstanceNumber"))
        elif integ.get("contiguity_valid") is False:
            # `is False` deliberately: None means the check could not run.
            # Only a positioned stack loses data when its numbering breaks;
            # elsewhere a gap is normal, so it is reported without blocking.
            reason = INSTANCE_ORDERING_REASONS.get(ordering, ordering)
            issues.append(_issue(
                "BROKEN_CONTIGUITY",
                "HIGH" if ordering == POSITIONED_STACK else "LOW", "series",
                f"{sd}: InstanceNumber sequence is not contiguous ({reason})"))

        missing_tags = [t for t, ok in (s.get("mandatory_tags", {}) or {}).items() if not ok]
        if missing_tags:
            issues.append(_issue(
                "MISSING_MANDATORY_TAG", "HIGH", "series",
                f"{sd}: unpopulated identity tag(s) {missing_tags}"))

        iq = s.get("image_quality", {}) or {}
        analysed = iq.get("slices_analysed", 0)
        if iq.get("low_signal"):
            issues.append(_issue(
                "LOW_SIGNAL_IMAGE", "MEDIUM", "series",
                f"{sd}: almost no coherent image content (blank / near-empty acquisition)"))
        elif iq.get("noise_suspected"):
            issues.append(_issue(
                "NOISE_SUSPECTED", "MEDIUM", "series",
                f"{sd}: no coherent spatial structure (noise / corruption)"))
        if iq.get("non_volume"):
            issues.append(_issue(
                "NON_VOLUME_SERIES", "LOW", "series",
                f"{sd}: only {analysed} decoded slice(s) — likely secondary capture / report image"))
        elif (analysed >= settings.min_volume_slices
                and iq.get("blank_slices", 0) >= settings.mostly_blank_fraction * analysed):
            issues.append(_issue(
                "MOSTLY_BLANK_SERIES", "LOW", "series",
                f"{sd}: {iq['blank_slices']}/{analysed} slices are essentially blank"))

        clip = iq.get("clipping", {}) or {}
        if clip.get("clipping_suspected"):
            issues.append(_issue(
                "ANATOMICAL_CLIPPING", "MEDIUM", "series",
                f"{sd}: tissue reaches FOV boundary ({', '.join(clip.get('clipped_faces', []))})"))
        organs = (iq.get("segmentation_clipping", {}) or {}).get("organs", {}) or {}
        for organ, r in organs.items():
            if isinstance(r, dict) and r.get("clipped"):
                issues.append(_issue(
                    "ORGAN_CLIPPING", "MEDIUM", "series",
                    f"{sd}: {organ} truncated at {', '.join(r.get('faces_touched', []))}"))

        if (integ.get("geometry", {}) or {}).get("is_geometrically_distorted"):
            issues.append(_issue(
                "GEOMETRIC_DISTORTION", "MEDIUM", "series",
                f"{sd}: non-square pixel aspect ratio"))

        duplicates = sum(1 for i in s.get("instances", []) if i.get("is_duplicate"))
        if duplicates:
            issues.append(_issue(
                "DUPLICATE_INSTANCES", "MEDIUM", "series",
                f"{sd}: {duplicates} duplicate SOPInstanceUID(s)"))

        std = s.get("standardisation", {}) or {}
        cc = s.get("clinical_context", {}) or {}
        if std.get("modality") == "MG" and not cc.get("view_position_valid", True):
            issues.append(_issue(
                "VIEW_POSITION_INVALID", "MEDIUM", "series",
                f"{sd}: non-standard mammography view position"))

        if std.get("plane_description_mismatch"):
            issues.append(_issue(
                "PLANE_LABEL_MISMATCH", "LOW", "series",
                f"{sd}: geometry={std.get('acquisition_plane')} vs description={std.get('plane_description_hint')}"))

        if std.get("acquisition_plane") == "UNKNOWN" or std.get("sequence_type") in ("UNKNOWN_MRI_SEQ",):
            issues.append(_issue(
                "UNCLASSIFIED", "LOW", "series",
                f"{sd}: acquisition plane/sequence could not be resolved"))

    return _finalise(issues, settings.severity_weights)


def _finalise(issues: List[Dict[str, str]],
              weights: Optional[Mapping[str, int]] = None) -> Dict[str, Any]:
    """Roll a list of issues up into tier (worst issue) + score (sum of weights)."""
    weights = weights or SEVERITY_WEIGHTS
    tier = "OK"
    for i in issues:
        tier = _worse(tier, i["severity"])
    issues.sort(key=lambda i: -weights[i["severity"]])
    return {
        "priority_tier": tier,
        "priority_score": sum(weights[i["severity"]] for i in issues),
        "issue_count": len(issues),
        "issues": issues,
    }


def flag_cohort_iqm_outliers(series_list: List[Dict[str, Any]],
                             z_thresh: float = 3.5,
                             min_cohort: int = 5) -> List[Dict[str, Any]]:
    """Flag high-CJV source volumes within each modality/sequence cohort."""
    cohorts: Dict[Any, List[Dict[str, Any]]] = defaultdict(list)
    for r in series_list:
        cjv = r.get("cjv")
        if r.get("is_derived") or r.get("non_volume") or cjv is None or not np.isfinite(cjv):
            continue
        cohorts[(r.get("modality"), r.get("sequence"))].append(r)

    outliers = []
    for members in cohorts.values():
        if len(members) < min_cohort:
            continue
        vals = np.array([m["cjv"] for m in members], float)
        med = float(np.median(vals))
        mad = float(np.median(np.abs(vals - med))) + 1e-9
        for m in members:
            z = 0.6745 * (m["cjv"] - med) / mad
            if z > z_thresh:
                outliers.append({
                    "study_name": m.get("study_name"), "study_uid": m.get("study_uid"),
                    "series_desc": m.get("series_desc"), "modality": m.get("modality"),
                    "sequence": m.get("sequence"), "cjv": round(float(m["cjv"]), 3),
                    "cjv_z": round(float(z), 2), "cohort_median_cjv": round(med, 3),
                })
    return sorted(outliers, key=lambda o: -o["cjv_z"])


def _tier_sort_key(entry: Dict[str, Any]):
    a = entry["assessment"]
    return (SEVERITY_ORDER.index(a["priority_tier"]), a["priority_score"])


def _group(entries: List[Dict[str, Any]], key_fn) -> Dict[str, Any]:
    groups: Dict[str, Dict[str, Any]] = defaultdict(
        lambda: {"study_count": 0, "tier_counts": Counter(), "issue_counts": Counter()})
    for e in entries:
        g = groups[key_fn(e)]
        g["study_count"] += 1
        g["tier_counts"][e["assessment"]["priority_tier"]] += 1
        for issue in e["assessment"]["issues"]:
            g["issue_counts"][issue["code"]] += 1
    ordered = sorted(
        groups.items(),
        key=lambda kv: -(kv[1]["study_count"] - kv[1]["tier_counts"].get("OK", 0)))
    return {
        name: {
            "study_count": g["study_count"],
            "tier_counts": dict(g["tier_counts"]),
            "top_issues": dict(g["issue_counts"].most_common(5)),
        }
        for name, g in ordered
    }


def _issue_summary(entries: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Summarise issue frequency, ordered by severity then affected studies."""
    counts: Dict[str, Dict[str, Any]] = defaultdict(
        lambda: {"severity": None, "studies": 0, "occurrences": 0})
    for e in entries:
        seen: set = set()
        for i in e["assessment"]["issues"]:
            rec = counts[i["code"]]
            rec["severity"] = i["severity"]
            rec["occurrences"] += 1
            if i["code"] not in seen:
                rec["studies"] += 1
                seen.add(i["code"])
    return {
        code: {"severity": r["severity"], "studies": r["studies"], "occurrences": r["occurrences"]}
        for code, r in sorted(
            counts.items(),
            key=lambda kv: (-SEVERITY_ORDER.index(kv[1]["severity"]), -kv[1]["studies"]))
    }


def find_duplicate_studies(entries: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Studies sharing a patient, modality and study date.

    A repeat acquisition of the same modality for one patient on one day is
    usually a re-scan, a duplicated import, or a study split across two
    accessions — all worth a human look before the cohort is used.

    Only meaningful before de-identification: the writer anchors every study's
    dates independently, so afterwards all studies share one date and every
    same-patient pair would look like a same-day repeat.
    """
    groups: Dict[tuple, List[Dict[str, Any]]] = defaultdict(list)
    for e in entries:
        patient = e.get("patient_id")
        study_date = e.get("study_date")
        if not patient or not study_date:
            continue
        groups[(patient, e.get("primary_modality", "UNKNOWN"), study_date)].append(e)

    duplicates = []
    for (patient, modality, study_date), group in sorted(groups.items()):
        if len(group) < 2:
            continue
        duplicates.append({
            "patient_id": patient,
            "primary_modality": modality,
            "study_date": study_date,
            "study_count": len(group),
            "studies": [
                {
                    "study_name": g.get("study_name"),
                    "study_uid": g.get("study_uid"),
                    "report_path": g.get("report_path"),
                }
                for g in group
            ],
        })
    return duplicates


def build_batch_summary(entries: List[Dict[str, Any]],
                        cohort_iqm_outliers: List[Dict[str, Any]] = None,
                        severity_weights: Optional[Mapping[str, int]] = None,
                        scope: str = DEFAULT_QC_SCOPE) -> Dict[str, Any]:
    """Aggregate study assessments and inject batch-level CJV outliers."""
    cohort_iqm_outliers = cohort_iqm_outliers or []
    weights = severity_weights or SEVERITY_WEIGHTS
    by_uid: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for o in cohort_iqm_outliers:
        by_uid[o["study_uid"]].append(o)
    for e in entries:
        outs = by_uid.get(e.get("study_uid"))
        if not outs:
            continue
        issues = e["assessment"]["issues"]
        for o in outs:
            issues.append(_issue(
                "IQM_COHORT_OUTLIER", "MEDIUM", "series",
                f"{o['series_desc']}: CJV {o['cjv']} is {o['cjv_z']} MADs above the "
                f"{o['modality']}/{o['sequence']} cohort (noise/motion/inhomogeneity)"))
        e["assessment"].update(_finalise(issues, weights))

    duplicate_studies: List[Dict[str, Any]] = []
    if scope == "internal":
        duplicate_studies = find_duplicate_studies(entries)
        flagged = {
            s["study_uid"] for d in duplicate_studies for s in d["studies"]
        }
        for e in entries:
            if e.get("study_uid") not in flagged:
                continue
            issues = e["assessment"]["issues"]
            issues.append(_issue(
                "POSSIBLE_DUPLICATE_STUDY", "MEDIUM", "study",
                f"another {e.get('primary_modality', 'UNKNOWN')} study exists for "
                f"this patient on {e.get('study_date')}"))
            e["assessment"].update(_finalise(issues, weights))

    ranked = sorted(entries, key=_tier_sort_key, reverse=True)

    needs_review = [e for e in ranked if e["assessment"]["priority_tier"] != "OK"]
    review_queue = []
    for rank, e in enumerate(needs_review, start=1):
        a = e["assessment"]
        review_queue.append({
            "rank": rank,
            "study_name": e["study_name"],
            "study_uid": e.get("study_uid", "UNKNOWN"),
            "priority_tier": a["priority_tier"],
            "priority_score": a["priority_score"],
            "primary_modality": e.get("primary_modality", "UNKNOWN"),
            "manufacturer": e["device"].get("manufacturer", "UNKNOWN"),
            "model": e["device"].get("model", "UNKNOWN"),
            "issue_count": a["issue_count"],
            "issues": [f"[{i['severity']}] {i['code']}: {i['detail']}" for i in a["issues"]],
            "report_path": e.get("report_path"),
        })

    return {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "qc_scope": scope,
        "total_studies": len(entries),
        "studies_needing_review": len(needs_review),
        "tier_distribution": dict(Counter(e["assessment"]["priority_tier"] for e in entries)),
        "issue_summary": _issue_summary(entries),
        "review_queue": review_queue,
        "iqm_cohort_outliers": cohort_iqm_outliers,
        "possible_duplicate_studies": duplicate_studies,
        "duplicate_study_check": (
            "same patient, modality and study date"
            if scope == "internal"
            else "skipped: dates are anchored per study after de-identification, "
                 "so every same-patient pair would appear same-day"
        ),
        "by_modality": _group(entries, lambda e: e.get("primary_modality", "UNKNOWN")),
        "by_manufacturer": _group(entries, lambda e: e["device"].get("manufacturer", "UNKNOWN")),
        "by_scanner": _group(
            entries,
            lambda e: f"{e['device'].get('manufacturer', 'UNKNOWN')} / {e['device'].get('model', 'UNKNOWN')}"),
        "severity_model": {
            "weights": dict(weights),
            "note": "Study tier = worst single issue; score = sum of issue weights (tie-breaker).",
        },
    }
