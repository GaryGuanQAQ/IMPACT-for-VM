import os
import argparse
import base64
import csv
import json
import logging
import pydicom
import numpy as np
from pathlib import Path
from typing import Dict, Any, List, Set, Optional, Tuple
from collections import defaultdict, Counter

from radiology_qc.basic_checks import calculate_md5, validate_dicom_parse
from radiology_qc.metadata_checks import (
    validate_mandatory_tags,
    validate_clinical_context,
    validate_series_integrity,
    validate_geometry,
    calculate_slice_gap,
    get_device_metadata,
    get_acquisition_parameters,
)
from radiology_qc.standardisation import validate_standardisation, validate_protocol_completeness
from radiology_qc.deidentification import audit_deidentification_files
from radiology_qc.image_preprocessing import get_normalised_pixel_data
from radiology_qc.image_quality import series_cjv, analyse_body, tissue_fraction
from radiology_qc.image_checks import validate_image_quality
from radiology_qc.anatomy import infer_body_part, resolve_profile, VOLUMETRIC_MODALITIES
from radiology_qc.prioritisation import assess_study, build_batch_summary, flag_cohort_iqm_outliers
from radiology_qc.settings import (
    DEFAULT_QC_SCOPE,
    DEFAULT_SETTINGS,
    QC_SCOPES,
    QCSettings,
    discover_dicom_files,
)
from radiology_qc.utils import NumpyEncoder
from extract_metadata.extract_metadata import (
    DEFAULT_OUTPUT_FILENAME,
    PRIVATE_TAG_COUNT_KEY,
    find_metadata_files,
    load_metadata_file,
    parse_private_tag_key,
)

logger = logging.getLogger(__name__)

def get_series_mode(metadata_list: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Calculate the mode for each key in a list of dictionaries."""
    if not metadata_list:
        return {}
    mode_result = {}
    keys = metadata_list[0].keys()
    for key in keys:
        values = [json.dumps(d.get(key), sort_keys=True) if isinstance(d.get(key), (dict, list)) 
                  else d.get(key) for d in metadata_list]
        try:
            most_common = Counter(values).most_common(1)[0][0]
            mode_result[key] = json.loads(most_common) if isinstance(most_common, str) and \
                               (most_common.startswith('{') or most_common.startswith('[')) else most_common
        except (IndexError, TypeError, json.JSONDecodeError):
            continue
    return mode_result

def _count_blank_slices(tissue_fractions: List[float], rel_threshold: float,
                        min_slices: int) -> int:
    """Count slices below a fraction of median series tissue content."""
    if len(tissue_fractions) < min_slices:
        return 0
    median = float(np.median(tissue_fractions))
    if median <= 0:
        return 0
    return int(sum(1 for f in tissue_fractions if f < rel_threshold * median))


def _build_segmenter():
    """Build the required container-backed segmenter for full mode."""
    from radiology_qc.segmentation import TotalSegmentatorClipping
    return TotalSegmentatorClipping()


def _write_review_csv(review_queue, path):
    """Flat CSV of the review queue for sorting/filtering in a spreadsheet."""
    cols = ["rank", "priority_tier", "priority_score", "primary_modality",
            "manufacturer", "model", "study_name", "issue_count", "issues", "report_path"]
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for e in review_queue:
            row = dict(e, issues=" | ".join(e.get("issues", [])))
            w.writerow([row.get(c, "") for c in cols])


def _prefer_presentation(entries):
    """Prefer presentation images for matching view/laterality pairs."""
    presented = {
        (getattr(h, "ViewPosition", None), getattr(h, "ImageLaterality", None))
        for _, h in entries
        if str(getattr(h, "PresentationIntentType", "")).upper() == "FOR PRESENTATION"
    }
    kept = [
        (p, h) for p, h in entries
        if not (str(getattr(h, "PresentationIntentType", "")).upper() == "FOR PROCESSING"
                and (getattr(h, "ViewPosition", None), getattr(h, "ImageLaterality", None)) in presented)
    ]
    if len(kept) < len(entries):
        logger.info("Preferred FOR PRESENTATION: dropped %d redundant FOR PROCESSING image(s)",
                    len(entries) - len(kept))
    return kept


def _software_versions(qc_mode: str, segmenter=None) -> Dict[str, Any]:
    """Return package, dependency, and model provenance."""
    import importlib.metadata as md
    from radiology_qc import __version__

    def _v(dist: str):
        try:
            return md.version(dist)
        except Exception:
            return None

    versions: Dict[str, Any] = {
        "radiology_qc": __version__,
        "pydicom": _v("pydicom"), "numpy": _v("numpy"),
        "scipy": _v("scipy"), "scikit-image": _v("scikit-image"),
    }
    if qc_mode == "full" and segmenter is not None:
        versions.update(segmenter.provenance())
    return {k: v for k, v in versions.items() if v is not None}


def _first_value(entries: List[Tuple[Path, Any]], keyword: str) -> Optional[Any]:
    """The first populated value of `keyword` across a study's headers."""
    for _, header in entries:
        value = getattr(header, keyword, None)
        if value is not None and str(value).strip():
            return value
    return None


def _safe_instance_number(ds: Any) -> Optional[int]:
    """Return InstanceNumber as int, or None when absent/unparseable (not 0)."""
    raw = getattr(ds, "InstanceNumber", None)
    if raw is None or str(raw).strip() == "":
        return None
    try:
        return int(raw)
    except (ValueError, TypeError):
        return None


def _dataset_from_extracted_tags(tags: Dict[str, Any]) -> pydicom.dataset.Dataset:
    """Build a pydicom Dataset from flattened extracted tags."""
    ds = pydicom.dataset.Dataset()
    tags = dict(tags)
    tags.pop(PRIVATE_TAG_COUNT_KEY, None)
    for key, value in tags.items():
        private_tag = parse_private_tag_key(key)
        if private_tag is not None:
            group, element = private_tag
            vr = value.get("vr", "UN") if isinstance(value, dict) else "UN"
            raw = value.get("value") if isinstance(value, dict) else value
            if isinstance(raw, dict) and "base64" in raw:
                raw = base64.b64decode(raw["base64"])
            try:
                ds.add_new(pydicom.tag.Tag(group, element), vr, raw)
            except Exception as e:
                logger.debug("Skipping unassignable private tag %s: %s", key, e)
            continue
        try:
            setattr(ds, key, value)
        except Exception as e:
            logger.debug("Skipping unassignable extracted tag %s: %s", key, e)
    return ds


def _metadata_search_dirs(dcm_files: List[Path], root_path: Path) -> Set[Path]:
    """Directories that may hold a metadata file for `dcm_files`.

    A study's metadata is written to the common parent of its instances, which
    is an ancestor of the per-series subdirectories the instances live in, so
    search each file's directory and every ancestor up to the scan root.
    """
    search_dirs: Set[Path] = set()
    for directory in {f.parent for f in dcm_files}:
        current = directory
        while current not in search_dirs:
            search_dirs.add(current)
            if current == root_path or not current.is_relative_to(root_path):
                break
            current = current.parent
    return search_dirs


def _headers_from_metadata_file(metadata_path: Path) -> Dict[Path, pydicom.dataset.Dataset]:
    """Build synthetic per-instance headers from a tiered metadata JSON, keyed by original file path."""
    metadata = load_metadata_file(metadata_path)
    study_tags = metadata.get("tags", {})
    headers: Dict[Path, pydicom.dataset.Dataset] = {}
    for series in metadata.get("series", {}).values():
        series_tags = series.get("tags", {})
        for instance in series.get("instances", {}).values():
            merged = {**study_tags, **series_tags, **instance.get("tags", {})}
            headers[Path(instance["file_path"])] = _dataset_from_extracted_tags(merged)
    return headers


def run_study_qc(
    entries: List[Tuple[Path, Any]],
    study_name: str,
    unreadable_files: Optional[List[Dict[str, Any]]] = None,
    study_uid: str = "UNKNOWN",
    protocol_requirements: Optional[Dict[str, Any]] = None,
    qc_mode: str = "light",
    segmenter=None,
    settings: Optional[QCSettings] = None,
    mask_root: Optional[Path] = None,
) -> Dict[str, Any]:
    """Run QC for entries sharing a StudyInstanceUID."""
    settings = settings or QCSettings()
    logger.info(f"Step 1: Parsing metadata for {len(entries)} files in study {study_name}")
    seen_sop_uids = set()
    series_data_map = {}
    study_devices = []

    for dcm_path, ds in entries:
        uid = getattr(ds, "SOPInstanceUID", "UNKNOWN")
        instance_data = {
            "file_name": dcm_path.name,
            "md5_checksum": calculate_md5(dcm_path),
            "is_duplicate": uid in seen_sop_uids,
            "sop_instance_uid": uid
        }
        seen_sop_uids.add(uid)

        s_uid = getattr(ds, "SeriesInstanceUID", "UNKNOWN")
        if s_uid not in series_data_map:
            series_data_map[s_uid] = {
                "file_paths": [], "headers": [], "instances": [], "instance_numbers": [],
                "temp_mandatory": [], "temp_clinical": [], "temp_std": [], "temp_geometry": [],
                "temp_device": [], "image_types": [], "body_parts": [],
                "series_directory": dcm_path.parent.name
            }

        device = get_device_metadata(ds)
        study_devices.append(device)

        s_info = series_data_map[s_uid]
        s_info["file_paths"].append(dcm_path)
        s_info["headers"].append(ds)
        s_info["instances"].append(instance_data)
        s_info["instance_numbers"].append(_safe_instance_number(ds))
        s_info["temp_mandatory"].append(validate_mandatory_tags(ds, settings.mandatory_tags))
        s_info["temp_clinical"].append(validate_clinical_context(ds))
        s_info["temp_std"].append(validate_standardisation(ds, settings))
        s_info["temp_geometry"].append(validate_geometry(ds))
        s_info["temp_device"].append(device)
        image_type = [str(v).upper() for v in getattr(ds, "ImageType", [])]
        s_info["image_types"].append(image_type[0] if image_type else "UNKNOWN")
        s_info["body_parts"].append(str(getattr(ds, "BodyPartExamined", "") or "").upper())

    final_series_list = []
    all_series_summaries = []

    for s_uid, s_info in series_data_map.items():
        std_mode = get_series_mode(s_info["temp_std"])
        geom_mode = get_series_mode(s_info["temp_geometry"])
        mandatory_mode = get_series_mode(s_info["temp_mandatory"])
        clinical_mode = get_series_mode(s_info["temp_clinical"])
        headers = s_info["headers"]

        order = sorted(
            zip(s_info["file_paths"], s_info["instances"], headers, s_info["instance_numbers"]),
            key=lambda t: (t[3] is None, t[3] if t[3] is not None else 0)
        )

        series_desc = getattr(order[0][2], "SeriesDescription", "No Description")
        modality = std_mode.get("modality", "UNKNOWN")

        image_type_mode = Counter(s_info["image_types"]).most_common(1)[0][0]
        body_part_raw = Counter(s_info["body_parts"]).most_common(1)[0][0]
        is_derived = image_type_mode == "DERIVED"
        body_part = infer_body_part(body_part_raw, series_desc, study_name)
        profile = resolve_profile(modality, body_part)

        n_order = len(order)
        sample_idx = set(np.linspace(
            0, n_order - 1, min(settings.iqm_sample_slices, n_order)
        ).astype(int)) if n_order else set()

        tissue_fractions = []
        decoded_slices = 0
        failed_image_reads = []
        sampled_pixels, first_pixels, last_pixels = [], None, None

        for i, (path, inst_dict, _hdr, _num) in enumerate(order):
            try:
                full_ds = pydicom.dcmread(path)
            except Exception as e:
                failed_image_reads.append({"file_name": path.name, "error": f"{type(e).__name__}: {e}"})
                continue
            pixels = get_normalised_pixel_data(full_ds, settings)
            if pixels.size == 0:
                continue
            decoded_slices += 1
            tissue_fractions.append(tissue_fraction(pixels, settings))
            if not is_derived:
                if i == 0:
                    first_pixels = pixels
                if i == n_order - 1:
                    last_pixels = pixels
                if i in sample_idx:
                    sampled_pixels.append(pixels)

        blank_slices = _count_blank_slices(
            tissue_fractions, settings.blank_slice_rel_threshold, settings.min_volume_slices)

        image_quality = {
            "slices_analysed": decoded_slices,
            "blank_slices": blank_slices,
            "undecodable_slices": len(failed_image_reads),
            "is_derived": is_derived,
            "body_part": body_part,
            "anatomy_profile": profile["profile_key"],
            "non_volume": bool(modality in VOLUMETRIC_MODALITIES and not is_derived
                               and decoded_slices < settings.min_volume_slices),
            "cjv": None,
            "low_signal": False,
            "noise_suspected": False,
            "foreground_coverage": None,
            "clipping": {"clipping_suspected": False, "clipped_faces": [], "coverage": None},
        }
        if not is_derived and sampled_pixels:
            body = analyse_body(sampled_pixels, first_pixels, last_pixels)
            cjv_min = settings.min_volume_slices if modality in VOLUMETRIC_MODALITIES else 1
            image_quality["cjv"] = series_cjv(
                sampled_pixels, min_slices=cjv_min, settings=settings)["cjv"]
            image_quality["foreground_coverage"] = body["foreground_coverage"]
            image_quality.update(validate_image_quality(
                body, modality=modality, is_derived=is_derived,
                decoded_slices=decoded_slices, plane=std_mode.get("acquisition_plane"),
                profile=profile, settings=settings))

        needs_seg = profile.get("body_task") or profile.get("organ_task")
        if qc_mode == "full" and segmenter is not None and needs_seg and not is_derived:
            mask_dir = mask_root / study_name / s_uid if mask_root else None
            try:
                image_quality["segmentation_clipping"] = segmenter(
                    [p for (p, _, _, _) in order], modality, profile, mask_dir=mask_dir)
            except Exception as e:
                logger.warning("Segmentation clipping failed for %s: %s", series_desc, e)
                image_quality["segmentation_clipping"] = {"error": f"{type(e).__name__}: {e}"}

        series_integrity = validate_series_integrity(headers)
        series_integrity["slice_gap_mm"] = calculate_slice_gap(headers)
        series_integrity["geometry"] = geom_mode

        s_summary = {
            "series_uid": s_uid,
            "series_description": series_desc,
            "series_directory": s_info["series_directory"],
            "device": get_series_mode(s_info["temp_device"]),
            "standardisation": std_mode,
            "mandatory_tags": mandatory_mode,
            "clinical_context": clinical_mode,
            "acquisition_parameters": get_acquisition_parameters(headers),
            "series_integrity": series_integrity,
            "image_quality": image_quality,
            "failed_image_reads": failed_image_reads,
            "instances": [item[1] for item in order]
        }
        all_series_summaries.append(s_summary["standardisation"])
        final_series_list.append(s_summary)

    return {
        "study_name": study_name,
        "study_uid": study_uid,
        "device_summary": get_series_mode(study_devices),
        "metric_definitions": settings.metric_definitions(),
        "protocol_validation": validate_protocol_completeness(all_series_summaries, protocol_requirements),
        "deidentification": audit_deidentification_files(
            path for path, _ in entries
        ),
        "unreadable_files": unreadable_files or [],
        "series": final_series_list
    }

def _report_path(default_dir: Path, root_path: Path, output_root: Optional[Path],
                 filename: str) -> Path:
    """Place a report beside data or in the mirrored output path."""
    if output_root is None:
        return default_dir / filename
    try:
        relative = default_dir.relative_to(root_path)
    except ValueError:
        relative = Path()
    destination = output_root / relative
    destination.mkdir(parents=True, exist_ok=True)
    return destination / filename


def main(config_path: Path) -> None:
    """Identify studies by StudyInstanceUID and run batch QC."""
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
    except FileNotFoundError:
        if not os.environ.get("RADQC_ROOT_DIR"):
            logger.error(f"Config not found: {config_path}")
            return
        logger.info(f"No config at {config_path}; using defaults")
        config = {}
    except Exception as e:
        logger.error(f"Config error: {e}")
        return

    root_dir = (os.environ.get("RADQC_ROOT_DIR")
                or config.get("root_directory") or config.get("study_directory"))
    if not root_dir:
        logger.error("Set RADQC_ROOT_DIR or 'root_directory' (the DICOM scan root).")
        return
    root_path = Path(root_dir)
    settings = DEFAULT_SETTINGS
    qc_mode = os.environ.get("RADQC_MODE") or config.get("qc_mode", "light")
    if qc_mode not in {"light", "full"}:
        raise ValueError(f"qc_mode must be 'light' or 'full', got {qc_mode!r}")
    qc_scope = (os.environ.get("RADQC_SCOPE")
                or config.get("qc_scope", DEFAULT_QC_SCOPE))
    if qc_scope not in QC_SCOPES:
        raise ValueError(
            f"qc_scope must be one of {list(QC_SCOPES)}, got {qc_scope!r}")
    output_dir = os.environ.get("RADQC_OUTPUT_DIR") or config.get("output_directory")
    output_root = Path(output_dir) if output_dir else None
    if output_root is not None:
        output_root.mkdir(parents=True, exist_ok=True)
        logger.info(f"Reports -> {output_root}")
    mask_root = None
    if os.environ.get("RADQC_SAVE_MASKS", "").lower() in ("1", "true", "yes"):
        if output_root is None:
            logger.warning("RADQC_SAVE_MASKS set but no output_directory; masks not written.")
        else:
            mask_root = output_root / "segmentation_masks"
            logger.info(f"Segmentation masks -> {mask_root}")
    segmenter = None
    if qc_mode == "full":
        segmenter = _build_segmenter()
    versions = _software_versions(qc_mode, segmenter)
    logger.info(f"QC mode: {qc_mode}, scope: {qc_scope}")
    if qc_scope == "internal":
        logger.warning(
            "Internal scope: residual identifiers are reported as an inventory "
            "rather than a release blocker, and reports may name patient "
            "identifiers. Keep this output in the source security zone.")
    all_dcm_files = discover_dicom_files(root_path, settings)
    if not all_dcm_files:
        logger.error(
            f"No DICOM files found under {root_path} "
            f"(patterns={list(settings.file_patterns)}, "
            f"scan_extensionless={settings.scan_extensionless}).")
        return

    use_extracted_env = os.environ.get("RADQC_USE_EXTRACTED_METADATA")
    use_extracted_metadata = (
        use_extracted_env.lower() in ("1", "true", "yes")
        if use_extracted_env is not None
        else bool(config.get("use_extracted_metadata", False))
    )
    metadata_filename = (
        os.environ.get("RADQC_METADATA_FILENAME")
        or config.get("metadata_filename", DEFAULT_OUTPUT_FILENAME)
    )
    extracted_headers: Dict[Path, pydicom.dataset.Dataset] = {}
    if use_extracted_metadata:
        for directory in _metadata_search_dirs(all_dcm_files, root_path):
            # A directory may hold several studies, so several metadata files.
            for metadata_path in find_metadata_files(directory, metadata_filename):
                extracted_headers.update(_headers_from_metadata_file(metadata_path))
        logger.info(
            f"Loaded extracted metadata for {len(extracted_headers)} of "
            f"{len(all_dcm_files)} files; the rest will be parsed directly.")

    study_groups: Dict[str, List[Tuple[Path, Any]]] = defaultdict(list)
    unreadable_files: List[Tuple[Path, str]] = []
    logger.info(f"Scanning {len(all_dcm_files)} files for Study IDs...")

    for f in all_dcm_files:
        hdr = extracted_headers.get(f)
        if hdr is None:
            hdr, error = validate_dicom_parse(f, stop_before_pixels=True)
            if hdr is None:
                # Keep unreadable files even though they cannot be grouped by UID.
                unreadable_files.append((f, error))
                continue
        uid = getattr(hdr, "StudyInstanceUID", "UNKNOWN_STUDY")
        study_groups[uid].append((f, hdr))

    assigned_unreadable = set()
    written_reports: Set[Path] = set()
    summary_entries = []
    all_series_iqm = []
    for uid, entries in study_groups.items():
        try:
            entries = _prefer_presentation(entries)
            paths = [p for p, _ in entries]
            common_parent = Path(os.path.commonpath([str(p.parent) for p in paths]))
            study_name = common_parent.name

            study_unreadable = []
            for p, err in unreadable_files:
                if p.is_relative_to(common_parent):
                    study_unreadable.append({"file_name": p.name, "error": err})
                    assigned_unreadable.add(p)

            logger.info(f"--- Processing Study UID: {uid} (Folder: {study_name}) ---")
            results = run_study_qc(entries, study_name, study_unreadable, study_uid=uid,
                                   qc_mode=qc_mode,
                                   segmenter=segmenter,
                                   settings=settings, mask_root=mask_root)
            results["software_versions"] = versions
            results["qc_scope"] = qc_scope

            output_path = _report_path(common_parent, root_path, output_root,
                                       f"{study_name}_qc_report.json")
            if output_path in written_reports:
                # Another study shares this folder; qualify so neither is overwritten.
                output_path = _report_path(common_parent, root_path, output_root,
                                           f"{study_name}_{uid}_qc_report.json")
            written_reports.add(output_path)
            with open(output_path, "w") as out:
                json.dump(results, out, indent=4, cls=NumpyEncoder)
            logger.info(f"Report saved: {output_path}")

            summary_entries.append({
                "study_name": study_name,
                "study_uid": uid,
                "primary_modality": results["protocol_validation"].get("primary_modality", "UNKNOWN"),
                "device": results["device_summary"],
                "report_path": str(output_path),
                "assessment": assess_study(results, settings, scope=qc_scope),
                # Only collected for the internal scope, where dates are real
                # and a patient identifier still exists to group by.
                "patient_id": (
                    str(_first_value(entries, "PatientID") or "") or None
                    if qc_scope == "internal" else None
                ),
                "study_date": (
                    str(_first_value(entries, "StudyDate") or "") or None
                    if qc_scope == "internal" else None
                ),
            })
            for s in results["series"]:
                iq = s.get("image_quality", {})
                std = s.get("standardisation", {})
                all_series_iqm.append({
                    "study_name": study_name, "study_uid": uid,
                    "series_desc": s.get("series_description"),
                    "modality": std.get("modality"), "sequence": std.get("sequence_type"),
                    "cjv": iq.get("cjv"), "is_derived": iq.get("is_derived"),
                    "non_volume": iq.get("non_volume"),
                })
        except Exception as e:
            logger.error(f"Failed study {uid}: {e}")

    leftover = [
        {"file_name": p.name, "error": err}
        for p, err in unreadable_files if p not in assigned_unreadable
    ]
    if leftover:
        output_path = _report_path(root_path, root_path, output_root,
                                   "unreadable_files_qc_report.json")
        with open(output_path, "w") as out:
            json.dump({"unreadable_files": leftover}, out, indent=4, cls=NumpyEncoder)
        logger.warning(f"{len(leftover)} unreadable file(s) reported: {output_path}")

    cohort_outliers = flag_cohort_iqm_outliers(
        all_series_iqm, z_thresh=settings.cohort_outlier_z,
        min_cohort=settings.min_cohort_size)
    if cohort_outliers:
        logger.info(f"IQM cohort outliers: {len(cohort_outliers)} series")

    if summary_entries:
        summary = build_batch_summary(summary_entries,
                                      scope=qc_scope,
                                      cohort_iqm_outliers=cohort_outliers,
                                      severity_weights=settings.severity_weights)
        summary_path = _report_path(root_path, root_path, output_root,
                                    "batch_qc_summary.json")
        with open(summary_path, "w") as out:
            json.dump(summary, out, indent=4, cls=NumpyEncoder)
        _write_review_csv(summary["review_queue"], summary_path.with_name("review_queue.csv"))
        logger.info(
            f"Batch summary saved: {summary_path} ({summary['total_studies']} studies, "
            f"{summary['studies_needing_review']} need review, tiers={summary['tier_distribution']})")
        for item in summary["review_queue"][:10]:
            logger.info(
                f"  #{item['rank']} [{item['priority_tier']}] {item['study_name']} "
                f"({item['manufacturer']}/{item['model']}) score={item['priority_score']} "
                f"issues={item['issue_count']}")
        if summary["studies_needing_review"] > 10:
            logger.info(f"  … and {summary['studies_needing_review'] - 10} more "
                        f"(full list in {summary_path.name} / review_queue.csv)")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    parser = argparse.ArgumentParser(description="Run radiology DICOM QC over a scan root.")
    parser.add_argument(
        "config", nargs="?", type=Path,
        default=Path(__file__).resolve().parent.parent / "config.json",
        help="Path to config.json (default: alongside the repo root).")
    main(parser.parse_args().config)
