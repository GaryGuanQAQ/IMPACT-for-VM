from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from radiology_qc.image_checks import evaluate_clipping
from radiology_qc.settings import (
    DEFAULT_ANATOMY_PROFILES,
    DEFAULT_CLIPPING_THRESHOLD,
    DEFAULT_MIN_ORGAN_VOXELS,
    DEFAULT_SEGMENTATION_FAST,
    DEFAULT_SEGMENTATION_IMAGE,
    DEFAULT_SEGMENTATION_RUNTIME,
    DEFAULT_SEGMENTATION_USE_GPU,
)

logger = logging.getLogger(__name__)

# Fast inference uses separate weight bundles for these tasks.
_FAST_DOWNLOAD_TASK = {
    "body": "body_fast",
    "body_mr": "body_mr_fast",
    "total": "total_fast",
    "total_mr": "total_fast_mr",
}
_SUPPORTED_RUNTIMES = {"docker", "apptainer", "singularity"}


def required_download_tasks(profiles=None, fast=None):
    """Return the weight sets the configured anatomy profiles invoke."""
    profiles = DEFAULT_ANATOMY_PROFILES if profiles is None else profiles
    fast = DEFAULT_SEGMENTATION_FAST if fast is None else fast
    tasks = set()
    for profile in profiles.values():
        body = profile.get("body_task")
        if body:
            tasks.add(
                _FAST_DOWNLOAD_TASK[body]
                if fast and body in _FAST_DOWNLOAD_TASK
                else body
            )
        organ = profile.get("organ_task")
        if organ:
            tasks.add(
                _FAST_DOWNLOAD_TASK[organ]
                if fast and organ in _FAST_DOWNLOAD_TASK
                else organ
            )
    return tasks


_FACES = {
    "x-": lambda m: m[0, :, :], "x+": lambda m: m[-1, :, :],
    "y-": lambda m: m[:, 0, :], "y+": lambda m: m[:, -1, :],
    "z-": lambda m: m[:, :, 0], "z+": lambda m: m[:, :, -1],
}
_FACE_ALIAS = {
    "z-": "first_slice", "z+": "last_slice",
    "y-": "top", "y+": "bottom", "x-": "left", "x+": "right",
}


def _largest_component(mask):
    """Keep the largest 3D body component and discard isolated specks."""
    import numpy as np
    from scipy.ndimage import label

    if not mask.any():
        return mask
    labelled, count = label(mask)
    if count <= 1:
        return mask
    sizes = np.bincount(labelled.ravel())
    sizes[0] = 0
    return labelled == int(sizes.argmax())


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    if raw.lower() in {"1", "true", "yes"}:
        return True
    if raw.lower() in {"0", "false", "no"}:
        return False
    raise ValueError(f"{name} must be true or false, got {raw!r}")


class TotalSegmentatorClipping:
    """Run TotalSegmentator in its dedicated image and evaluate clipping."""

    def __init__(self) -> None:
        self.runtime = os.environ.get(
            "RADQC_TOTALSEG_RUNTIME", DEFAULT_SEGMENTATION_RUNTIME
        ).lower()
        self.image = os.environ.get(
            "RADQC_TOTALSEG_IMAGE", DEFAULT_SEGMENTATION_IMAGE
        )
        self.use_gpu = _env_bool(
            "RADQC_TOTALSEG_USE_GPU", DEFAULT_SEGMENTATION_USE_GPU
        )
        self.fast = DEFAULT_SEGMENTATION_FAST
        self.min_organ_voxels = DEFAULT_MIN_ORGAN_VOXELS

        if self.runtime not in _SUPPORTED_RUNTIMES:
            expected = ", ".join(sorted(_SUPPORTED_RUNTIMES))
            raise ValueError(
                f"unsupported RADQC_TOTALSEG_RUNTIME={self.runtime!r}; "
                f"expected one of: {expected}"
            )
        if shutil.which(self.runtime) is None:
            raise FileNotFoundError(f"{self.runtime} is not on PATH")
        if self.runtime != "docker" and "://" not in self.image:
            image_path = Path(self.image).expanduser()
            if not image_path.is_file():
                raise FileNotFoundError(f"model image does not exist: {image_path}")
            self.image = str(image_path.resolve())

        result = self._invoke(["--metadata"], capture_output=True)
        try:
            self.metadata = json.loads(result.stdout.strip().splitlines()[-1])
        except (IndexError, json.JSONDecodeError) as exc:
            raise RuntimeError(
                f"model image returned invalid metadata: {result.stdout!r}"
            ) from exc
        if not self.metadata.get("weights_present"):
            raise RuntimeError("model image does not contain its baked weights")

    def provenance(self) -> Dict[str, Any]:
        """Return the model/runtime identity recorded in QC reports."""
        return {
            "TotalSegmentator_image": self.image,
            "TotalSegmentator_runtime": self.runtime,
            **self.metadata,
        }

    def _invoke(
        self,
        adapter_args: List[str],
        input_dir: Optional[Path] = None,
        output_dir: Optional[Path] = None,
        capture_output: bool = False,
    ) -> subprocess.CompletedProcess:
        if self.runtime == "docker":
            command = [
                "docker", "run", "--rm", "--network", "none",
                "--read-only", "--tmpfs", "/tmp:rw,exec,size=32g",
                "--shm-size", "8g",
            ]
            if input_dir is not None and output_dir is not None:
                command += [
                    "--user", f"{os.getuid()}:{os.getgid()}",
                    "-e", "HOME=/tmp",
                    "-v", f"{input_dir}:/input:ro",
                    "-v", f"{output_dir}:/output:rw",
                ]
                if self.use_gpu:
                    command += ["--gpus", "all"]
            command += [self.image, *adapter_args]
        else:
            command = [
                self.runtime, "exec", "--cleanenv", "--contain",
                "--writable-tmpfs",
            ]
            if input_dir is not None and output_dir is not None:
                if self.use_gpu:
                    command.append("--nv")
                command += [
                    "-B", f"{input_dir}:/input:ro",
                    "-B", f"{output_dir}:/output:rw",
                ]
            command += [
                self.image, "python", "/opt/radqc-model/adapter.py",
                *adapter_args,
            ]

        try:
            return subprocess.run(
                command, check=True, text=True, capture_output=capture_output
            )
        except subprocess.CalledProcessError as exc:
            detail = (exc.stderr or exc.stdout or "").strip()
            if detail:
                raise RuntimeError(
                    f"TotalSegmentator container failed: {detail[-2000:]}"
                ) from exc
            raise

    def _segment(
        self, series_dir: Path, task: str, work_dir: Path
    ) -> Tuple[Any, Dict[str, str], Path]:
        import numpy as np

        output_name = task
        adapter_args = [
            "--input", "/input",
            "--output-base", f"/output/{output_name}",
            "--task", task,
        ]
        if self.fast and task in ("body", "body_mr", "total", "total_mr"):
            adapter_args.append("--fast")
        self._invoke(
            adapter_args,
            input_dir=series_dir.resolve(),
            output_dir=work_dir.resolve(),
            capture_output=True,
        )

        array_path = work_dir / f"{output_name}.npy"
        labels_path = work_dir / f"{output_name}.labels.json"
        nifti_path = work_dir / f"{output_name}.nii.gz"
        if not (array_path.is_file() and labels_path.is_file() and nifti_path.is_file()):
            raise RuntimeError("model image did not produce the expected output files")
        segmentation = np.load(array_path, allow_pickle=False)
        labels = json.loads(labels_path.read_text())
        return segmentation, labels, nifti_path

    def _run_task(
        self, series_dir: Path, task: str, mask_dir: Optional[Path]
    ) -> Tuple[Any, Dict[str, str]]:
        with tempfile.TemporaryDirectory(prefix="radqc-totalseg-") as tmp:
            segmentation, labels, nifti_path = self._segment(
                series_dir, task, Path(tmp)
            )
            if mask_dir is not None:
                mask_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(nifti_path, mask_dir / f"{task}.nii.gz")
            return segmentation, labels

    def __call__(
        self,
        paths: List[Path],
        modality: str,
        profile: Dict[str, Any],
        mask_dir: Optional[Path] = None,
    ) -> Dict[str, Any]:
        import numpy as np

        series_dir = Path(paths[0]).parent
        output: Dict[str, Any] = {}

        body_task = profile.get("body_task")
        if body_task:
            segmentation, _ = self._run_task(series_dir, body_task, mask_dir)
            body = _largest_component(segmentation > 0)
            coverage = {
                _FACE_ALIAS[name]: float(select(body).mean())
                for name, select in _FACES.items()
            }
            output["envelope"] = {
                "task": body_task,
                "body_coverage": float(body.mean()),
                **evaluate_clipping(
                    coverage,
                    profile.get("clipping_faces", []),
                    profile.get("clipping_threshold", DEFAULT_CLIPPING_THRESHOLD),
                ),
            }

        organ_task = profile.get("organ_task")
        targets = profile.get("organ_targets") or []
        if organ_task and targets:
            segmentation, labels = self._run_task(series_dir, organ_task, mask_dir)
            name_to_id = {name: int(label_id) for label_id, name in labels.items()}
            organs: Dict[str, Any] = {"task": organ_task}
            for target in targets:
                ids = [
                    label_id for name, label_id in name_to_id.items()
                    if target.lower() in name.lower()
                ]
                if not ids:
                    organs[target] = {"present": False, "note": "not in task map"}
                    continue
                mask = np.isin(segmentation, ids)
                if int(mask.sum()) < self.min_organ_voxels:
                    organs[target] = {
                        "present": False,
                        "voxels": int(mask.sum()),
                    }
                    continue
                touched = [
                    _FACE_ALIAS[name]
                    for name, select in _FACES.items()
                    if select(mask).any()
                ]
                organs[target] = {
                    "present": True,
                    "voxels": int(mask.sum()),
                    "clipped": bool(touched),
                    "faces_touched": touched,
                }
            output["organs"] = organs
        return output


if __name__ == "__main__":
    print(" ".join(sorted(required_download_tasks())))
