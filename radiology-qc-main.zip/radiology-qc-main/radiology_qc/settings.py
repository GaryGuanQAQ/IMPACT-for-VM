from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any, Dict, List, Tuple

# Backward-compatible import. De-identification policy is owned by
# deidentify.settings; values use canonical (group, element) integer tuples and
# new callers should import the constant from there.
from deidentify.settings import (
    DEFAULT_DEID_ALLOWED_TAGS as DEFAULT_DEID_ALLOWED_TAGS,
)

# QC runs in two positions with different questions to answer. Before
# de-identification the data is expected to hold PHI, so residual identifiers
# are an inventory of what the writer will strip; after it, the same finding is
# a release blocker. The default is the conservative position.
QC_SCOPES = ("internal", "release")
DEFAULT_QC_SCOPE = "release"

logger = logging.getLogger(__name__)

# Structural severity order; only the weights are site-tunable.
SEVERITY_TIERS: Tuple[str, ...] = ("OK", "LOW", "MEDIUM", "HIGH", "CRITICAL")

DEFAULT_SEVERITY_WEIGHTS: Dict[str, int] = {
    "CRITICAL": 100, "HIGH": 40, "MEDIUM": 15, "LOW": 5, "OK": 0,
}

DEFAULT_MANDATORY_TAGS: Tuple[str, ...] = (
    "StudyDate", "Modality",
)

DEFAULT_FILE_PATTERNS: Tuple[str, ...] = ("*.dcm", "*.DCM")

# Shared minimum for volume classification and volume metrics.
DEFAULT_MIN_VOLUME_SLICES = 5

DEFAULT_LOW_SIGNAL_MAX_FOREGROUND = 0.02

DEFAULT_MIN_SPATIAL_STRUCTURE = 0.5

# Site policy: use an empty mapping to disable protocol requirements.
DEFAULT_PROTOCOL_REQUIREMENTS: Dict[str, Dict[str, List[str]]] = {
    "MR": {"required_sequences": ["T2_WEIGHTED", "POST_CONTRAST_DCE"]},
    "MG": {"required_planes": ["CRANIOCAUDAL", "MEDIOLATERAL_OBLIQUE"]},
}


DEFAULT_CLIPPING_THRESHOLD = 0.5

# Coverage cannot exceed 1, so this disables face clipping.
NO_CLIPPING_THRESHOLD = 1.0

DEFAULT_SEGMENTATION_RUNTIME = "docker"
DEFAULT_SEGMENTATION_IMAGE = "ghcr.io/pharoskcl/totalsegmentator_2-15-0:latest"
DEFAULT_SEGMENTATION_USE_GPU = True
DEFAULT_SEGMENTATION_FAST = True

# Ignore small, likely spurious organ masks.
DEFAULT_MIN_ORGAN_VOXELS = 50

DEFAULT_ANATOMY_PROFILES: Dict[str, Dict[str, Any]] = {
    "MR/BREAST": {
        "clipping_faces": ["first_slice", "last_slice"],
        "clipping_threshold": DEFAULT_CLIPPING_THRESHOLD,
        # Other planes end at the chest wall or mediastinum.
        "clipping_planes": ["AXIAL"],
        # Breast MRI uses model-free clipping; see README.
        "body_task": None,
        "organ_task": None,
        "organ_targets": [],
    },
    "CT/CHEST": {
        "clipping_faces": ["left", "right", "top", "bottom"],
        "clipping_threshold": DEFAULT_CLIPPING_THRESHOLD,
        "body_task": "body",
        "organ_task": "total",
        "organ_targets": ["lung"],
    },
    "CT/LUNG": {
        "clipping_faces": ["left", "right", "top", "bottom"],
        "clipping_threshold": DEFAULT_CLIPPING_THRESHOLD,
        "body_task": "body",
        "organ_task": "total",
        "organ_targets": ["lung"],
    },
    "CT/ABDOMEN": {
        "clipping_faces": ["left", "right", "top", "bottom"],
        "clipping_threshold": DEFAULT_CLIPPING_THRESHOLD,
        "body_task": "body",
        "organ_task": "total",
        "organ_targets": ["pancreas", "liver"],
    },
    "US/BREAST": {
        "clipping_faces": [],
        "clipping_threshold": NO_CLIPPING_THRESHOLD,
        "clipping_planes": [],
        "body_task": None,
        "organ_task": None,
        "organ_targets": [],
    },
    "MG/BREAST": {
        "clipping_faces": [],
        "clipping_threshold": NO_CLIPPING_THRESHOLD,
        "body_task": None,
        "organ_task": None,
        "organ_targets": [],
    },
    "DEFAULT": {
        "clipping_faces": ["first_slice", "last_slice"],
        "clipping_threshold": DEFAULT_CLIPPING_THRESHOLD,
        "clipping_planes": ["AXIAL"],
        "body_task": None,
        "organ_task": None,
        "organ_targets": [],
    },
}

# Metric definitions are embedded in each report for comparability.
DEFAULT_OBLIQUE_TOLERANCE_DEGREES = 20.0

# ITU-R BT.601 luminance weights.
DEFAULT_LUMINANCE_WEIGHTS: Tuple[float, float, float] = (0.299, 0.587, 0.114)

DEFAULT_MAD_TO_SIGMA = 1.4826

DEFAULT_TISSUE_SIGMA_MULTIPLIER = 3.0

DEFAULT_MIN_INFORMATIVE_FRACTION = 0.01

# Fallback for unlabelled T2 sequences.
DEFAULT_T2_MIN_ECHO_TIME_MS = 60.0
DEFAULT_T2_MIN_REPETITION_TIME_MS = 2000.0

_FRACTION_FIELDS = (
    "blank_slice_rel_threshold",
    "mostly_blank_fraction",
    "low_signal_max_foreground",
    "min_spatial_structure",
    "min_informative_fraction",
)
_POSITIVE_INT_FIELDS = (
    "min_volume_slices",
    "iqm_sample_slices",
    "min_cohort_size",
    "max_review_queue",
)


@dataclass(frozen=True)
class QCSettings:
    """Site-tunable QC parameters."""

    # File discovery
    file_patterns: Tuple[str, ...] = DEFAULT_FILE_PATTERNS
    scan_extensionless: bool = True

    # Series geometry
    min_volume_slices: int = DEFAULT_MIN_VOLUME_SLICES
    iqm_sample_slices: int = 15

    # Image signal
    blank_slice_rel_threshold: float = 0.2
    mostly_blank_fraction: float = 0.9
    low_signal_max_foreground: float = DEFAULT_LOW_SIGNAL_MAX_FOREGROUND
    min_spatial_structure: float = DEFAULT_MIN_SPATIAL_STRUCTURE

    # Cohort outliers
    cohort_outlier_z: float = 3.5
    min_cohort_size: int = 5

    # Metadata
    mandatory_tags: Tuple[str, ...] = DEFAULT_MANDATORY_TAGS

    # Reporting
    severity_weights: Dict[str, int] = field(
        default_factory=lambda: dict(DEFAULT_SEVERITY_WEIGHTS))
    max_review_queue: int = 50

    # Metric definitions
    oblique_tolerance_degrees: float = DEFAULT_OBLIQUE_TOLERANCE_DEGREES
    luminance_weights: Tuple[float, float, float] = DEFAULT_LUMINANCE_WEIGHTS
    mad_to_sigma: float = DEFAULT_MAD_TO_SIGMA
    tissue_sigma_multiplier: float = DEFAULT_TISSUE_SIGMA_MULTIPLIER
    min_informative_fraction: float = DEFAULT_MIN_INFORMATIVE_FRACTION
    t2_min_echo_time_ms: float = DEFAULT_T2_MIN_ECHO_TIME_MS
    t2_min_repetition_time_ms: float = DEFAULT_T2_MIN_REPETITION_TIME_MS

    @property
    def oblique_cosine_threshold(self) -> float:
        """Dominant direction cosine below which a plane is labelled OBLIQUE."""
        return math.cos(math.radians(self.oblique_tolerance_degrees))

    def metric_definitions(self) -> Dict[str, Any]:
        """Return metric definitions stored with each report."""
        return {
            "oblique_tolerance_degrees": self.oblique_tolerance_degrees,
            "luminance_weights": list(self.luminance_weights),
            "mad_to_sigma": self.mad_to_sigma,
            "tissue_sigma_multiplier": self.tissue_sigma_multiplier,
            "min_informative_fraction": self.min_informative_fraction,
            "t2_min_echo_time_ms": self.t2_min_echo_time_ms,
            "t2_min_repetition_time_ms": self.t2_min_repetition_time_ms,
            "note": ("Definitions the reported metrics were computed under; "
                     "values from runs with differing definitions are not comparable."),
        }

    def __post_init__(self) -> None:
        for name in _FRACTION_FIELDS:
            value = getattr(self, name)
            if not isinstance(value, (int, float)) or not 0.0 <= float(value) <= 1.0:
                raise ValueError(f"'{name}' must be a fraction in [0, 1], got {value!r}")
        for name in _POSITIVE_INT_FIELDS:
            value = getattr(self, name)
            if not isinstance(value, int) or isinstance(value, bool) or value < 1:
                raise ValueError(f"'{name}' must be an integer >= 1, got {value!r}")
        if not isinstance(self.cohort_outlier_z, (int, float)) or self.cohort_outlier_z <= 0:
            raise ValueError(
                f"'cohort_outlier_z' must be a positive number, got {self.cohort_outlier_z!r}")
        if self.iqm_sample_slices < self.min_volume_slices:
            raise ValueError(
                f"'iqm_sample_slices' ({self.iqm_sample_slices}) must be >= "
                f"'min_volume_slices' ({self.min_volume_slices}), otherwise CJV can "
                f"never be computed for volumetric series.")
        if not self.file_patterns and not self.scan_extensionless:
            raise ValueError(
                "No DICOM discovery configured: set 'file_patterns' or enable "
                "'scan_extensionless', otherwise no files can ever be found.")
        missing = [tier for tier in SEVERITY_TIERS if tier not in self.severity_weights]
        if missing:
            raise ValueError(f"'severity_weights' is missing tier(s): {missing}")

        if not 0.0 < float(self.oblique_tolerance_degrees) < 90.0:
            raise ValueError(
                f"'oblique_tolerance_degrees' must be in (0, 90), got "
                f"{self.oblique_tolerance_degrees!r}")
        if len(self.luminance_weights) != 3 or any(w < 0 for w in self.luminance_weights):
            raise ValueError(
                f"'luminance_weights' must be three non-negative R,G,B weights, got "
                f"{self.luminance_weights!r}")
        if not math.isclose(sum(self.luminance_weights), 1.0, abs_tol=1e-3):
            raise ValueError(
                f"'luminance_weights' must sum to 1.0, got "
                f"{sum(self.luminance_weights)!r} from {self.luminance_weights!r}")
        if self.mad_to_sigma <= 0:
            raise ValueError(f"'mad_to_sigma' must be positive, got {self.mad_to_sigma!r}")
        if self.tissue_sigma_multiplier < 0:
            raise ValueError(
                f"'tissue_sigma_multiplier' must be >= 0, got "
                f"{self.tissue_sigma_multiplier!r}")
        for name in ("t2_min_echo_time_ms", "t2_min_repetition_time_ms"):
            value = getattr(self, name)
            if not isinstance(value, (int, float)) or value < 0:
                raise ValueError(f"'{name}' must be a non-negative number, got {value!r}")

DEFAULT_SETTINGS = QCSettings()


def _has_dicm_magic(path: Path) -> bool:
    """True when the file carries the 'DICM' magic at offset 128 (Part-10 preamble)."""
    try:
        with open(path, "rb") as f:
            return f.read(132)[128:132] == b"DICM"
    except OSError:
        return False


def discover_dicom_files(root: Path, settings: QCSettings) -> List[Path]:
    """Find configured suffixes plus extensionless files with DICM magic."""
    found: Dict[Path, None] = {}
    for pattern in settings.file_patterns:
        for path in root.rglob(pattern):
            if path.is_file():
                found[path] = None
    n_by_pattern = len(found)

    if settings.scan_extensionless:
        for path in root.rglob("*"):
            if path not in found and not path.suffix and path.is_file() \
                    and _has_dicm_magic(path):
                found[path] = None

    n_extensionless = len(found) - n_by_pattern
    if n_extensionless:
        logger.info("Discovered %d extensionless DICOM file(s) via DICM magic",
                    n_extensionless)
    return sorted(found)
