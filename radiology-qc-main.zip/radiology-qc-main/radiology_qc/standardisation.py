import logging
from typing import Dict, Any, List, Set, Optional
import pydicom
import numpy as np

from radiology_qc.settings import (
    DEFAULT_PROTOCOL_REQUIREMENTS,
    DEFAULT_SETTINGS,
    QCSettings,
)

logger = logging.getLogger(__name__)


def get_mri_ct_plane(ds: pydicom.dataset.Dataset,
                     settings: Optional[QCSettings] = None) -> str:
    """Determine the acquisition plane from direction cosines."""
    settings = settings or DEFAULT_SETTINGS
    try:
        orientation = getattr(ds, "ImageOrientationPatient", None)
        if not orientation or len(orientation) != 6:
            return "UNKNOWN"

        row_cosine = np.array(orientation[:3])
        col_cosine = np.array(orientation[3:])
        normal = np.abs(np.cross(row_cosine, col_cosine))

        max_val = np.max(normal)
        max_idx = np.argmax(normal)

        if max_val < settings.oblique_cosine_threshold:
            return "OBLIQUE"

        return {0: "SAGITTAL", 1: "CORONAL", 2: "AXIAL"}.get(max_idx, "UNKNOWN")
    except (AttributeError, ValueError, TypeError, np.linalg.LinAlgError):
        return "UNKNOWN"


def get_plane_description_hint(ds: pydicom.dataset.Dataset) -> str:
    """Parse a secondary plane hint from SeriesDescription."""
    desc = str(getattr(ds, "SeriesDescription", "")).upper()
    if "SAG" in desc:
        return "SAGITTAL"
    if "COR" in desc:
        return "CORONAL"
    if "AX" in desc:
        return "AXIAL"
    return "NONE"


def get_mammography_details(ds: pydicom.dataset.Dataset) -> Dict[str, str]:
    """Identify Mammography view and presentation intent."""
    view = str(getattr(ds, "ViewPosition", "")).upper()
    intent_raw = str(getattr(ds, "PresentationIntentType", "")).upper()
    
    view_map = {
        "CC": "CRANIOCAUDAL",
        "MLO": "MEDIOLATERAL_OBLIQUE",
        "ML": "MEDIOLATERAL",
        "LM": "LATEROMEDIAL"
    }
    
    presentation_intent = "UNKNOWN_INTENT"
    if "PROCESSING" in intent_raw:
        presentation_intent = "FOR_PROCESSING"
    elif "PRESENTATION" in intent_raw:
        presentation_intent = "FOR_PRESENTATION"

    return {
        "view": view_map.get(view, view if view else "UNKNOWN_VIEW"),
        "intent": presentation_intent
    }


def get_ultrasound_plane(ds: pydicom.dataset.Dataset) -> str:
    """Identify Ultrasound scan plane via ViewCode or SeriesDescription."""
    view_seq = getattr(ds, "ViewCodeSequence", None)
    if view_seq and len(view_seq) > 0:
        meaning = str(getattr(view_seq[0], "CodeMeaning", "")).upper()
        if meaning:
            return meaning

    desc = str(getattr(ds, "SeriesDescription", "")).upper()
    if any(key in desc for key in ["LONG", "LS"]):
        return "LONGITUDINAL"
    if any(key in desc for key in ["TRANS", "TS"]):
        return "TRANSVERSE"
    
    return "UNKNOWN_US_PLANE"


def identify_mri_sequence(ds: pydicom.dataset.Dataset,
                          settings: Optional[QCSettings] = None) -> str:
    """Identify MRI sequence type including Localisers and technical scans."""
    settings = settings or DEFAULT_SETTINGS
    try:
        image_type = [str(val).upper() for val in getattr(ds, "ImageType", [])]
        
        if any("LOCALIZER" in val for val in image_type):
            return "LOCALISER"

        desc = str(getattr(ds, "SeriesDescription", "")).upper()
        protocol = str(getattr(ds, "ProtocolName", "")).upper()
        
        if any(word in desc or word in protocol for word in ["LOC", "SCOUT", "SURVEY"]):
            return "LOCALISER"

        if any("ADC" in val for val in image_type):
            return "ADC_MAP"

        if (0x0018, 0x9087) in ds or getattr(ds, "DiffusionBValue", None) is not None:
            return "DWI"

        contrast_agent = str(getattr(ds, "ContrastBolusAgent", "")).upper()
        if contrast_agent and contrast_agent not in ["", "NONE"]:
            return "POST_CONTRAST_DCE"

        scanning_seq = getattr(ds, "ScanningSequence", "")
        if isinstance(scanning_seq, (list, tuple, pydicom.multival.MultiValue)):
            scanning_seq = " ".join(str(x) for x in scanning_seq)
        scanning_seq = str(scanning_seq).upper()
        try:
            inversion_time = float(getattr(ds, "InversionTime", 0) or 0)
        except (ValueError, TypeError):
            inversion_time = 0.0
        is_inversion_recovery = "IR" in scanning_seq.split() or inversion_time > 0

        desc_protocol = f"{desc} {protocol}"
        te = float(getattr(ds, "EchoTime", 0) or 0)
        tr = float(getattr(ds, "RepetitionTime", 0) or 0)

        if ("STIR" in desc_protocol or "T2" in desc_protocol
                or is_inversion_recovery
                or (te > settings.t2_min_echo_time_ms
                    and tr > settings.t2_min_repetition_time_ms)):
            return "T2_WEIGHTED"

        return "OTHER_MRI"

    except (ValueError, TypeError):
        return "UNKNOWN_MRI_SEQ"


def validate_protocol_completeness(
    std_data_list: List[Dict[str, Any]],
    requirements: Optional[Dict[str, Dict[str, List[str]]]] = None,
) -> Dict[str, Any]:
    """Check a study against modality-specific protocol requirements."""
    if not std_data_list:
        return {"is_complete": False, "reason": "No data provided"}

    requirements = DEFAULT_PROTOCOL_REQUIREMENTS if requirements is None else requirements

    modalities = {item.get("modality") for item in std_data_list if item.get("modality")}
    primary_modality = list(modalities)[0] if len(modalities) == 1 else "MIXED"

    found_sequences: Set[str] = {item.get("sequence_type", "").upper() for item in std_data_list}
    found_planes: Set[str] = {item.get("acquisition_plane", "").upper() for item in std_data_list}

    report: Dict[str, Any] = {
        "primary_modality": primary_modality,
        "is_diagnostic_complete": True,
        "missing_elements": []
    }

    req = requirements.get(primary_modality, {})
    missing = [seq for seq in req.get("required_sequences", []) if seq not in found_sequences]
    missing += [plane for plane in req.get("required_planes", []) if plane not in found_planes]
    report["missing_elements"] = missing
    report["is_diagnostic_complete"] = len(missing) == 0

    if primary_modality == "MR":
        report["has_diffusion_data"] = "DWI" in found_sequences or "ADC_MAP" in found_sequences

    return report


def validate_standardisation(ds: pydicom.dataset.Dataset,
                             settings: Optional[QCSettings] = None) -> Dict[str, Any]:
    """Orchestrate standardisation based on modality."""
    settings = settings or DEFAULT_SETTINGS
    modality = str(getattr(ds, "Modality", "")).upper()
    
    results = {
        "modality": modality,
        "acquisition_plane": "UNKNOWN",
        "sequence_type": "N/A"
    }

    if modality in ["MR", "CT", "PT"]:
        plane = get_mri_ct_plane(ds, settings)
        hint = get_plane_description_hint(ds)
        results["acquisition_plane"] = plane
        results["plane_description_hint"] = hint
        results["plane_description_mismatch"] = bool(
            hint != "NONE" and plane not in ("OBLIQUE", "UNKNOWN") and hint != plane
        )
        if modality == "MR":
            results["sequence_type"] = identify_mri_sequence(ds, settings)
    elif modality == "MG":
        details = get_mammography_details(ds)
        results["acquisition_plane"] = details["view"]
        results["presentation_intent"] = details["intent"]
    elif modality == "US":
        results["acquisition_plane"] = get_ultrasound_plane(ds)
        
    return results
