@echo off
title Thorax Data Structure Scanner

echo ============================================================
echo          THORAX DATA STRUCTURE SCANNER
echo ============================================================
echo.
echo Scanning Z:\thorax_data ...
echo.

python "%~dp0thorax_data_scanner.py"

if errorlevel 1 (
    echo.
    echo The scanner returned an error.
)

pause
