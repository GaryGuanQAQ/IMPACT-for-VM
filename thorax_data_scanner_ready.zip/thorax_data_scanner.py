import os
import csv
from pathlib import Path
from datetime import datetime

# ============================================================
# Thorax Data Structure Scanner
#
# Expected structure:
# Z:\thorax_data\<category>\<patient_id>\<scan_dir>\*.dcm
#
# Example:
# Z:\thorax_data\haemothorax\000002\000031\000002.dcm
#
# Output:
# Z:\thorax_data\thorax_data_summary.csv
# ============================================================

ROOT = Path(r"Z:\thorax_data")
OUTPUT = ROOT / "thorax_data_summary.csv"

# Categories you currently have.
EXPECTED_CATEGORIES = {
    "haemothorax",
    "joint",
    "pneumothorax",
}


def scan_directory():
    rows = []
    category_summary = {}
    status_summary = {
        "SINGLE_DCM": 0,
        "MULTIPLE_DCM": 0,
        "NO_DCM": 0,
        "NESTED_DCM": 0,
    }

    if not ROOT.exists():
        print(f"ERROR: Cannot find {ROOT}")
        print("Please make sure the Z: drive is connected.")
        input("\nPress Enter to close...")
        return

    print("=" * 70)
    print("THORAX DATA STRUCTURE SCANNER")
    print("=" * 70)
    print(f"Root: {ROOT}")
    print()

    # Each category folder
    category_dirs = [
        p for p in ROOT.iterdir()
        if p.is_dir() and not p.name.startswith(".")
    ]

    # Process expected categories first, then any unexpected categories.
    category_dirs.sort(key=lambda p: (p.name.lower() not in EXPECTED_CATEGORIES,
                                      p.name.lower()))

    for category_dir in category_dirs:
        category = category_dir.name
        patient_count = 0
        scan_count = 0

        # category -> patient
        patient_dirs = [
            p for p in category_dir.iterdir()
            if p.is_dir() and not p.name.startswith(".")
        ]
        patient_dirs.sort(key=lambda p: p.name)

        for patient_dir in patient_dirs:
            patient_id = patient_dir.name
            patient_count += 1

            # patient -> scan_dir
            scan_dirs = [
                p for p in patient_dir.iterdir()
                if p.is_dir() and not p.name.startswith(".")
            ]
            scan_dirs.sort(key=lambda p: p.name)

            for scan_dir in scan_dirs:
                scan_count += 1

                # Only count DICOM files directly inside scan_dir.
                direct_dcm = [
                    p for p in scan_dir.iterdir()
                    if p.is_file() and p.suffix.lower() == ".dcm"
                ]

                # Detect DICOM files deeper than scan_dir.
                nested_dcm = [
                    p for p in scan_dir.rglob("*")
                    if p.is_file()
                    and p.suffix.lower() == ".dcm"
                    and p.parent != scan_dir
                ]

                dcm_count = len(direct_dcm)

                if dcm_count == 0 and nested_dcm:
                    status = "NESTED_DCM"
                elif dcm_count == 0:
                    status = "NO_DCM"
                elif dcm_count == 1:
                    status = "SINGLE_DCM"
                else:
                    status = "MULTIPLE_DCM"

                status_summary[status] += 1

                category_summary.setdefault(category, {
                    "patients": 0,
                    "scan_dirs": 0,
                    "single": 0,
                    "multiple": 0,
                    "no_dcm": 0,
                    "nested": 0,
                })

                category_summary[category]["scan_dirs"] += 1
                category_summary[category][{
                    "SINGLE_DCM": "single",
                    "MULTIPLE_DCM": "multiple",
                    "NO_DCM": "no_dcm",
                    "NESTED_DCM": "nested",
                }[status]] += 1

                # Relative path makes the CSV easier to inspect.
                try:
                    relative_path = str(scan_dir.relative_to(ROOT))
                except ValueError:
                    relative_path = str(scan_dir)

                rows.append({
                    "category": category,
                    "patient_id": patient_id,
                    "scan_dir": scan_dir.name,
                    "dcm_count": dcm_count,
                    "nested_dcm_count": len(nested_dcm),
                    "status": status,
                    "relative_path": relative_path,
                    "full_path": str(scan_dir),
                })

        category_summary.setdefault(category, {
            "patients": 0,
            "scan_dirs": 0,
            "single": 0,
            "multiple": 0,
            "no_dcm": 0,
            "nested": 0,
        })
        category_summary[category]["patients"] = patient_count

    # Write CSV
    fieldnames = [
        "category",
        "patient_id",
        "scan_dir",
        "dcm_count",
        "nested_dcm_count",
        "status",
        "relative_path",
        "full_path",
    ]

    with OUTPUT.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    # Console summary
    print("SCAN COMPLETE")
    print("-" * 70)
    print(f"Total scan_dirs: {len(rows)}")
    print()

    print("CATEGORY SUMMARY")
    print("-" * 70)
    print(f"{'Category':<20} {'Patients':>10} {'Scan dirs':>12} {'Single':>10} {'Multiple':>10}")
    print("-" * 70)

    for category in sorted(category_summary):
        s = category_summary[category]
        print(
            f"{category:<20} "
            f"{s['patients']:>10} "
            f"{s['scan_dirs']:>12} "
            f"{s['single']:>10} "
            f"{s['multiple']:>10}"
        )

    print()
    print("STATUS SUMMARY")
    print("-" * 70)
    for status, count in status_summary.items():
        print(f"{status:<20}: {count}")

    print()
    print(f"CSV created:")
    print(OUTPUT)
    print()

    # Highlight the important cases
    single_rows = [r for r in rows if r["status"] == "SINGLE_DCM"]
    nested_rows = [r for r in rows if r["status"] == "NESTED_DCM"]
    empty_rows = [r for r in rows if r["status"] == "NO_DCM"]

    print("=" * 70)
    print("IMPORTANT")
    print("=" * 70)
    print(f"Single .dcm scan_dirs : {len(single_rows)}")
    print(f"Multiple .dcm         : {status_summary['MULTIPLE_DCM']}")
    print(f"No .dcm               : {len(empty_rows)}")
    print(f"Nested .dcm           : {len(nested_rows)}")
    print()
    print("Open the CSV in Excel to filter STATUS = SINGLE_DCM.")
    print("=" * 70)

    input("\nPress Enter to close...")


if __name__ == "__main__":
    try:
        scan_directory()
    except Exception as e:
        print()
        print("=" * 70)
        print("ERROR")
        print("=" * 70)
        print(str(e))
        print()
        print("If the Z: drive is unavailable, reconnect it and run again.")
        input("Press Enter to close...")
